<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class napthe extends Model
{
    //
    Protected $table = "napthe";
    protected $fillable = [
        'id',
        'iduser',
        'idthe',
        'mathe',
        'seri',
        'menhgia',
        'trangthai'

    ];
    
    public function user(){
        return $this->belongsTo('App\User','iduser','id');
    }
}
