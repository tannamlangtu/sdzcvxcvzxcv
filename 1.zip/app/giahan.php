<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class giahan extends Model
{
    //
    Protected $table = "giahan";
    protected $fillable = [
        'id',
        'iduser',
        'ngaydanh',
        'hethan'
        
    ];
    public function user(){
        return $this->belongsTo('App\User','iduser','id');
    }
}
