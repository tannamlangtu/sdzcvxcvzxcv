<?php
 
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Hash;
use App\User;
use App\somo;
use App\daycity;
use App\ketqua;
use App\city;
use App\kqxs;
use App\giaikqxs;
use App\Comment;
use App\loto;
use App\napthe;
use Image;
use Illuminate\Support\Facades\DB;
class PageController extends Controller
{

   
       
    //
    public function index(){
return view('page.index');
    }
       
public function ketquaxoso(){
return view('page.ketquaxoso');
    }
    public function getmienbac(){
 include('simple_html_dom.php');
$rmb = array();
$rmt = array();
$rmn = array();
$day = date("d-m-Y");
$plus = 1;

if( date( 'H' ) > 19 || ( isset( $day ) && $day !== date( 'd-m-Y' ) ) ) {
}
else {
    $day = date("d-m-Y",strtotime("$day -$plus day"));
}
$html = file_get_html("http://vesophuongtrang.com/ket-qua-xo-so/".$day.".html");
$inputmb = array(
    'rs_0_0' => '<img class="a1" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_1_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_2_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_2_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_3_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_3_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_3_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_3_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_3_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_3_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_5_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_5_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_5_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_5_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_5_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_5_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_6_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_6_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_6_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_7_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_7_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_7_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_7_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />'
);
$input = array(
    'rs_8_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_7_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_6_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_6_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_6_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_5_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_6' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_4_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_3_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_3_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_2_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_1_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
    'rs_0_0' => '<img class="a1" src="ketquaxoso/Clock.gif" width="20" />',
);

$ketquamb = $html->find("table.kqxsmienbac div.dayso");
if( date( 'H' ) > 19 || ( isset( $day ) && $day !== date( 'd-m-Y' ) ) ) {
    $i=0;
    foreach( $inputmb as $key => $value ){
$rmb[$key] = $ketquamb[$i]->innertext;
$i++;
    }
}
else {
    $rmb = $inputmb;
}
$thu = date('l', strtotime($day));
if($thu=="Sunday") $thu = 1;
if($thu=="Monday") $thu = 2;
if($thu=="Tuesday") $thu = 3;
if($thu=="Wednesday") $thu = 4;
if($thu=="Thursday") $thu = 5;
if($thu=="Friday") $thu = 6;
if($thu=="Saturday") $thu = 7;
$daycity = daycity::where('idday',$thu)->get();

 
$city2 = array();
$city3 = array();
foreach($daycity as $dci){
    $cityy = city::where([['id',$dci->idcity],['idarea',2]])->first();
    if(is_array($cityy) && count($cityy)>0){
$city2[] = $cityy;
    }
}
foreach($daycity as $dci){
    $cityy = city::where([['id',$dci->idcity],['idarea',3]])->first();
    if(is_array($cityy) && count($cityy)>0){
$city3[] = $cityy;
    }
}
$j=0;
$k=0;
foreach($city2 as $cty2){
    $ten = $cty2->name;
    $tinh = $html->find("table.kqxsdaicol td.tentinh a");
    for($i=0;$i<count($tinh);$i++){
if($cty2->name=="Hồ Chí Minh") $ten = "TP. HCM";
else if($cty2->name=="Thừa Thiên Huế") $ten = "Thừa T. Huế";
else if($cty2->name=="Lâm Đồng") $ten = "Đà Lạt";
else if($cty2->name=="Đắc Lắc") $ten = "Đắk Lắk";
else if($cty2->name=="Đà Nẵng"){
    if($thu == "Thứ tư")
    $ten = "Đà Nẵng";
    else if($thu == "Thứ bảy")
    $ten = "Đ.Nẵng";
}
else if($cty2->name=="Quảng Ngãi") $ten = "Q.Ngãi";
else if($cty2->name=="Đắc Nông") $ten = "Đ.Nông";
else if($cty2->name=="Long An") $ten = "L.An";
else if($cty2->name=="Hậu Giang") $ten = "H.Giang";
else if($cty2->name=="Bình Phước") $ten = "B.Phước";
if($tinh[$i]->innertext==$ten){
    $table = $html->find("table.kqxsdaicol",$i);
    $ketquamt = $table->find("div.dayso");
    break;
}
    }
    if( date( 'H' ) > 19 || ( isset( $day ) && $day !== date( 'd-m-Y' ) ) ) {
$i=0;
foreach( $input as $key => $value ){
    $rmt[$j][$key] = $ketquamt[$i]->innertext;
    $i++;
}
    }
    else {
$rmt[$j] = $input;
    }
    $j++;
}
foreach($city3 as $cty3){
    $ten = $cty3->name;
    $tinh = $html->find("table.kqxsdaicol td.tentinh a");
    for($i=0;$i<count($tinh);$i++){
if($cty2->name=="Hồ Chí Minh") $ten = "TP. HCM";
else if($cty3->name=="Thừa Thiên Huế") $ten = "Thừa T. Huế";
else if($cty3->name=="Lâm Đồng") $ten = "Đà Lạt";
else if($cty3->name=="Đắc Lắc") $ten = "Đắk Lắk";
else if($cty3->name=="Đà Nẵng"){
    if($thu == "Thứ tư")
    $ten = "Đà Nẵng";
    else if($thu == "Thứ bảy")
    $ten = "Đ.Nẵng";
}
else if($cty3->name=="Quảng Ngãi") $ten = "Q.Ngãi";
else if($cty3->name=="Đắc Nông") $ten = "Đ.Nông";
else if($cty3->name=="Long An") $ten = "L.An";
else if($cty3->name=="Hậu Giang") $ten = "H.Giang";
else if($cty3->name=="Bình Phước") $ten = "B.Phước";
if($tinh[$i]->innertext==$ten){
    $table = $html->find("table.kqxsdaicol",$i);
    $ketquamn = $table->find("div.dayso");
    break;
}
    }
    if( date( 'H' ) > 19 || ( isset( $day ) && $day !== date( 'd-m-Y' ) ) ) {
$i=0;
foreach( $input as $key => $value ){
    $rmn[$k][$key] = $ketquamn[$i]->innertext;
    $i++;
}
    }
    else {
$rmn[$k] = $input;
    }
    $k++;
}
$kqmb = array();
$kqmn = array();
$kqmt = array();
foreach($rmb as $kq){
    $kqmb[] = substr($kq,-2);
}
for($i=0;$i<count($rmn);$i++){
    foreach($rmn[$i] as $kq){
$kqmn[$i][] = substr($kq,-2);
    }
}
for($i=0;$i<count($rmt);$i++){
    foreach($rmt[$i] as $kq){
$kqmt[$i][] = substr($kq,-2);
    }
}  
return view('page.mienbac', [
    'rmb'=>$rmb,
    'rmt'=>$rmt,
    'rmn'=>$rmn,
    'city2'=>$city2,
    'city3'=>$city3,
    'kqmb'=>$kqmb,
    'kqmn'=>$kqmn,
    'kqmt'=>$kqmt,
    'day'=>$day]);
    }

    public function getdangky(){
     return view('page.dangky');
    }
    public function postdangky(Request $req){
$this->validate($req,
    [
'email'=>'email|unique:users,email',
'name'=>'unique:users,name',
'password'=>'min:6|max:20',
'repassword'=>'same:password',
'phone'=>'unique:users,phone|min:10|max:11'
    ],
    [
'email.email' => 'Không đúng định dạng email',
'email.unique' => 'Email đã có người sử dụng',
'password.min' => 'Mật khẩu phải có ít nhất 6 ký tự',
'password.max' => 'Mật khẩu tối đa 20 ký tự',
'repassword.same' => 'Mật khẩu không giống nhau',
'phone.min' => 'Nhập chưa đúng số điện thoại.',
'phone.max' => 'Nhập chưa đúng số điện thoại.',
'name.unique' => 'Nickname đã có người sử dụng',
'phone.unique' => 'Số điện thoại đã có người sử dụng',
    ]);
    

    
    $user = new User();
    $user->name = $req->name;
    $user->email = $req->email;
    $user->password = Hash::make($req->password);
    $user->phone = $req->phone;
    $user->diem = 0;
    $user->level = 0;
    $user->vip = 0;
    $user->image = "gosoicau.jpg";
    $user->save();
    return redirect()->route('dangky')->with('dangky','Tạo tài khoản thành công!');
    }

    public function getresetpassword(){
        if(Auth::check()){
    return view('page.resetpassword');
    }
    else return view('page.index');
    }

    public function postresetpassword(Request $req){
$this->validate($req,
    [
'password'=>'min:6|max:20',
'password_repeate'=>'same:password'
    ],
    [
'password.min' => 'Mật khẩu phải có ít nhất 6 ký tự',
'password.max' => 'Mật khẩu tối đa 20 ký tự',
'password_repeate.same' => 'Mật khẩu không giống nhau'
    ]);
if($req->password == $req->password_repeate){
    $user = User::where('id',Auth::user()->id)
    ->Update([
'password'=>hash::make($req->password)
    ]);
    return back()->with([
'reset'=>'Đổi mật khẩu thành công!',
'flag'=>'success'
    ]);
}
    }

    public function getdangnhap(){
     return view('page.dangnhap');
    }

    public function postdangnhap(Request $req){
session_start();
$credentials = array('phone'=>$req->phone,'password'=>$req->password);
if(Auth::attempt($credentials)){
     return view('page.checklogin');
    $_SESSION["member_id"] = Auth::user()->id;
    if(!empty($req->remember)) {
setcookie("member_login",$req->phone,time()+ (10 * 365 * 24 * 60 * 60));
setcookie("member_password",$req->password,time()+ (10 * 365 * 24 * 60 * 60));
    } 
    else {
if(isset($_COOKIE["member_login"])) {
    setcookie("member_login","");
}
if(isset($_COOKIE["member_password"])) {
    setcookie("member_password","");
}
    }
    return view('page.index');
    }
     else return redirect()->back()->with('dangnhap','Số điện thoại hoặc mật khẩu không chính xác!'); 
    }

    public function getDangXuat(){
Auth::logout();
     return view('page.index');
    }


    public function getketqua(){
     return view('admin.page.kqxs.index');
    }

    public function postketqua(Request $req){
if(strlen($req->giai_1)!=5 && strlen($req->giai_1)!=6){
    return redirect()->back()->with([
'flag'=>'danger',
'update'=>'Chưa có kết quả để cập nhật'
    ]);
}
$d = substr($req->date,0,2);
$m = substr($req->date,3,2);
$y = substr($req->date,6,4);
$date = $y."-".$m."-".$d;
$thu = date('l', strtotime($date));
if($thu=="Sunday") $thu = 1;
if($thu=="Monday") $thu = 2;
if($thu=="Tuesday") $thu = 3;
if($thu=="Wednesday") $thu = 4;
if($thu=="Thursday") $thu = 5;
if($thu=="Friday") $thu = 6;
if($thu=="Saturday") $thu = 7;
$daycity = daycity::where([
    ['idcity',$req->city],
    ['idday',$thu]
])->first();
$kqxs = kqxs::where([
    ['ngayxoso',$date],
    ['iddaycity',$daycity->id]
])->get();
if(count($kqxs)!=0){
    return redirect()->back()->with([
'flag'=>'danger',
'update'=>'Đài này đã cập nhật rồi!'
    ]);
}
$kqxs = new kqxs();
$kqxs->ngayxoso = $date;
$kqxs->iddaycity = $daycity->id;
$kqxs->save();
if($req->city == 1){
    $n = 9;
}else $n = 10;
for($i=1; $i<$n; $i++){
    $giaikqxs = new giaikqxs();
    $giaikqxs->idkqxs = $kqxs->id;
    $giaikqxs->idgiai = $i;
    $giaikqxs->save();
    
    $kq = "giai_".$i;
    $giai = $req->$kq;
    $array = explode(" - ",$giai);
    if(count($array)==1){
$array[0] = $req->$kq;
    }
    foreach($array as $key=>$value){
$ketqua = new ketqua();
$ketqua->ketqua = $value;
$ketqua->idgiaikqxs = $giaikqxs->id;
$ketqua->save();
    }
}
return redirect()->back()->with([
    'flag'=>'success',
    'update'=>'Cập nhật thành công!'
]);
    }

     public function getinbox(){
     return view('page.inbox');
    }

       public function napthe(){
         if(Auth::check()){
            $user = User::find(Auth::user()->id);
            $napthe = napthe::where('iduser',$user->id)->orderBy('created_at')->paginate(10,['*'],'napthe');
            return view('page.napthe',[
                'napthe'=>$napthe
            ]);
        }
       else return redirect('/')->with('errors','Bạn chưa đăng nhập. Vui lòng đăng nhập để thực hiện!');
    }
    

    public function chanledacbiet(){
     return view('page.chanledacbiet');
    }

       public function thongke0099(){
     return view('page.thongke0099');
     }

       public function getme(){
     return view('page.me');
    }

    public function getsomo(){
     return view('page.somo');
    }

    public function update_avatar(Request $request){
// Logic for user upload of avatar
if($request->hasFile('avatar')){
    $avatar = $request->file('avatar');
    $filename = $avatar->getClientOriginalName();
    Image::make($avatar)->resize(300, 300)->save( public_path('/uploads/avatars/' . $filename ) );
    $user = Auth::user();
    $user->image = $filename;
    $user->save();
    
}
       return view('page.me', [
        'user' => Auth::user(), ]);
    }
     
     public function thongke(){
     return view('page.thongke');
    }
     
     public function dacbiet(){
     return view('page.dacbiet');
     }
 
      public function soicau(){
     return view('page.soicau');
    }

    public function quaythu(){
     return view('page.quaythu');
      }
      public function getquenmatkhau(){
     return view('page.quenmatkhau');
      }

    public function getkqmb(){
     return view('page.ketquamienbac');
    }

    public function getkqmn(){
     return view('page.ketquamiennam');
    }
    public function getkqmt(){
     return view('page.ketquamientrung');
    }
  public function getloto(){ 
        $user = User::get();
        $loto = loto::get();
        return view('page.loto',[
        'loto' => $loto,
        'user' => $user]);
       } 
 
    public function postloto(Request $req){
 if(Auth::check()){
    if(Auth::user()->vip == 0){

    return redirect()->back()->with('errors','Vui lòng nâng cấp lên vip để tham gia chốt số!');
    }
date_default_timezone_set('Asia/Ho_Chi_Minh');
$hetgio = "18:00:00";
$today = date("Y-m-d");
$now = date("H:i:s");
if($_POST["number1"] == $_POST["number2"]){
    return redirect()->back()->with('errors','Vui lòng nhập các số không trùng nhau!');
}
else if($_POST["number2"] == $_POST["number3"]){
    return redirect()->back()->with('errors','Vui lòng nhập các số không trùng nhau!');
}
if($_POST["number1"] == $_POST["number3"]){
    return redirect()->back()->with('errors','Vui lòng nhập các số không trùng nhau!');
}

if($_POST["number1"] == 0){
$_POST["number1"] = "00";
}
if($_POST["number1"] == 1){
$_POST["number1"] = "01";
}
if($_POST["number1"] == 2){
$_POST["number1"] = "02";
}
if($_POST["number1"] == 3){
$_POST["number1"] = "03";
}
if($_POST["number1"] == 4){
$_POST["number1"] = "04";
}
if($_POST["number1"] == 5){
$_POST["number1"] = "05";
}
if($_POST["number1"] == 6){
$_POST["number1"] = "06";
}
if($_POST["number1"] == 7){
$_POST["number1"] = "07";
}
if($_POST["number1"] == 8){
$_POST["number1"] = "08";
}
if($_POST["number1"] == 9){
$_POST["number1"] = "09";
}

if($_POST["number2"] == 0){
$_POST["number2"] = "00";
}
if($_POST["number2"] == 1){
$_POST["number2"] = "01";
}
if($_POST["number2"] == 2){
$_POST["number2"] = "02";
}
if($_POST["number2"] == 3){
$_POST["number2"] = "03";
}
if($_POST["number2"] == 4){
$_POST["number2"] = "04";
}
if($_POST["number2"] == 5){
$_POST["number2"] = "05";
}
if($_POST["number2"] == 6){
$_POST["number2"] = "06";
}
if($_POST["number2"] == 7){
$_POST["number2"] = "07";
}
if($_POST["number2"] == 8){
$_POST["number2"] = "08";
}
if($_POST["number2"] == 9){
$_POST["number2"] = "09";
}
if($_POST["number3"] == 0){
$_POST["number3"] = "00";
}
if($_POST["number3"] == 1){
$_POST["number3"] = "01";
}
if($_POST["number3"] == 2){
$_POST["number3"] = "02";
}
if($_POST["number3"] == 3){
$_POST["number3"] = "03";
}
if($_POST["number3"] == 4){
$_POST["number3"] = "04";
}
if($_POST["number3"] == 5){
$_POST["number3"] = "05";
}
if($_POST["number3"] == 6){
$_POST["number3"] = "06";
}
if($_POST["number3"] == 7){
$_POST["number3"] = "07";
}
if($_POST["number3"] == 8){
$_POST["number3"] = "08";
}
if($_POST["number3"] == 9){
$_POST["number3"] = "09";
}

$number =  $_POST["number1"]."-".$_POST["number2"]. "-".$_POST["number3"];
$d = substr($req->date,0,2);
$m = substr($req->date,3,2);
$y = substr($req->date,6,4);
$date = $y."-".$m."-".$d;
$id = Auth::user()->id;
$ngay = DB::table('loto')->latest('created_at')->
where('iduser', $id)->
value('ngaydanh');

if ($ngay == $today ) {
    return redirect()->back()->with('errors','Hôm nay bạn đã chơi rồi, vui lòng chơi lại vào ngày mai!');
}

if($now > $hetgio){
    return redirect()->back()->with('errors','Đã hết giờ đánh, vui lòng chơi lại vào ngày mai!');
}

else if($date == $today && $now > $hetgio){
    return redirect()->back()->with('errors','Đã hết giờ đánh, vui lòng chơi lại vào ngày mai!');
}

$user = User::find(Auth::user()->id);
    $loto = new loto();
    $loto->iduser = Auth::user()->id;
    $loto->ngaydanh = $today;
    $loto->number = $number;
    $loto->jackpot = 0;
    $loto->save();

    return redirect()->back()->with('loidanhde','Chốt số thành công. Chúc bạn may mắn!');
    }
else return redirect()->back()->with('errors','Bạn chưa đăng nhập. Vui lòng đăng nhập để chốt số!');
  } 

public function getchotso(){ 
    if(Auth::check()){
 return view('page.chotso');
}
else return redirect('/')->with('errors','Bạn chưa đăng nhập. Vui lòng đăng nhập xem admin chốt số!');
       } 
       
public function timkiem(){
     return view('page.timkiem');
    }
 
 
    // 
      public function test(){
     return view('page.test');
     }
      public function postnapthe(Request $req){
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        
            $napthe = new napthe();
            $napthe->iduser = Auth::user()->id;
            $napthe->idthe = $req->bank;
            $napthe->mathe = $req->mathe;
            $napthe->seri = $req->seri;
            $napthe->menhgia = $req->menhgia;
            $napthe->trangthai = "Đang chờ";
            $napthe->save();
            return redirect()->back()->with([
                'giaodich'=>'Gửi yêu cầu thành công! Hệ thống sẽ xác nhận lại với bạn trong vòng 24h',
                'flag'=>'success'
                ]);
        }
 
}