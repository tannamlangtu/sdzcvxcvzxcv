<?php

namespace App\Http\Controllers;
use App\Comment;
use App\giahan;
use App\User;
use Illuminate\Http\Request;
use Auth;

class GiahanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req)
    {
        $day = date("Y-m-d");
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                if(!isset($req->trangthai)){
                   $giaodich = giahan::where('hethan','<',$day)->paginate(10,['*'],'giaodich');
                    return view('admin.page.giahan.index',[
                        'giaodich'=>$giaodich,
                        'type'=>'Đang chờ'
                    ]);
                }
                else if($req->trangthai == 0){
                    $giaodich = giahan::where('hethan',$day)->paginate(10,['*'],'giaodich');
                    return view('admin.page.giahan.index',[
                        'giaodich'=>$giaodich,
                        'type'=>'Đang chờ'
                    ]);
                }
                
            }
        }
        else return view('page.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                return view('admin.page.giahan.create');
            }
        }
        else return view('page.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                
                $cmt = new giahan();
                $cmt->iduser = $request->input('iduser');
                $cmt->hethan = $request->input('hethan');
                $cmt->trangthai = "Đang chờ";
                $cmt->save();
                return redirect()->route('giahan.index')
                ->with('thanhcong','Tạo thành công!');
            }
        }
        else return view('page.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\giaodich  $giaodich
     * @return \Illuminate\Http\Response
     */
    public function show(giaodich $giaodich)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\giaodich  $giaodich
     * @return \Illuminate\Http\Response
     */
    public function edit(giahan $giahan)
    {
        //
        {
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                $giahan = giahan::find($giahan->id);
            return view('admin.page.giahan.edit',['giahan'=>$giahan]);
            }
        }
        else return view('page.index');
        
    }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\giaodich  $giaodich
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, giahan $giahan)
    {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        //
        if(isset($request->capnhat)){
            $user = User::find($giahan->iduser);
                $giaodich = giahan::where('id',$giahan->id)
                ->Update(['trangthai'=>"Thành công"]);
                $user->Update([
                    'vip'=> "0"
                ]);
            }
            return back()->with('thanhcong','Cập nhật thành công');
        }
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\giaodich  $giaodich
     * @return \Illuminate\Http\Response
     */
    public function destroy(giaodich $giaodich)
    {
        //
    }
}
