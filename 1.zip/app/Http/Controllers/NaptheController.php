<?php

namespace App\Http\Controllers;
use App\Comment;
use App\napthe;
use App\User;
use Illuminate\Http\Request;
use Auth;

class NaptheController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req)
    {
        
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                if(!isset($req->trangthai)){
                    $giaodich = napthe::paginate(10,['*'],'giaodich');
                    return view('admin.page.giaodich.index',[
                        'giaodich'=>$giaodich,
                        'type'=>'Tất cả'
                    ]);
                }
                else if($req->trangthai == 0){
                    $giaodich = napthe::where('trangthai',"Đang chờ")->paginate(10,['*'],'giaodich');
                    return view('admin.page.giaodich.index',[
                        'giaodich'=>$giaodich,
                        'type'=>'Đang chờ'
                    ]);
                }
                else{
                    $giaodich = napthe::where('trangthai',"Thành công")->paginate(10,['*'],'giaodich');
                    return view('admin.page.giaodich.index',[
                        'giaodich'=>$giaodich,
                        'type'=>'Tất cả'
                    ]);
                }
            }
        }
        else return view('page.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                return view('admin.page.giaodich.create');
            }
        }
        else return view('page.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                
                $cmt = new Comment();
                $cmt->user_id = $request->input('iduser');
                $cmt->comment = $request->input('comment');
                $cmt->save();
                return redirect()->route('giaodich.create')
                ->with('thanhcong','Tạo thành công!');
            }
        }
        else return view('page.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\giaodich  $giaodich
     * @return \Illuminate\Http\Response
     */
    public function show(giaodich $giaodich)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\giaodich  $giaodich
     * @return \Illuminate\Http\Response
     */
    public function edit(giaodich $giaodich)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\giaodich  $giaodich
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, napthe $giaodich)
    {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        //
        if(isset($request->capnhat)){
            $user = User::find($giaodich->iduser);
            $money = $giaodich->menhgia;
            if($money == "100k"){
                $giaodich = napthe::where('id',$giaodich->id)
                ->Update([
                    'trangthai'=>"Thành công"
                ]);
                $user->Update([
                    'vip'=> "1"
                ]);
            }
            else{
                $giaodich = napthe::where('id',$giaodich->id)
                ->Update([
                    'trangthai'=>"Thành công"
                ]);
            }
            return back()->with('thanhcong','Cập nhật thành công');
        }
        if(isset($request->huybo)){
           
            $user = User::find($giaodich->iduser);
           
                $giaodich = napthe::where('id',$giaodich->id)
                ->Update([
                    'trangthai'=>"Thất bại"
                ]);
                
            
            return back()->with('thanhcong','Hủy bỏ thành công');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\giaodich  $giaodich
     * @return \Illuminate\Http\Response
     */
    public function destroy(giaodich $giaodich)
    {
        //
    }
}
