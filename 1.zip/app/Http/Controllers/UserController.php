<?php

namespace App\Http\Controllers;

use App\User;
use App\loto;
use Illuminate\Http\Request;
use Hash;
use Auth;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req)
    {
        //
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.me');
            }
            else{
                if(!isset($req->admin)){
                    $users = User::paginate(15,['*'],'user');
                    return view('admin.page.user.index',[
                        'users'=>$users,
                        'type'=>'Tất cả'
                        ]);
                }else if($req->admin==0){
                    $users = User::where('vip',1)->paginate(50,['*'],'user');
                    return view('admin.page.user.index',[
                        'users'=>$users,
                        'type'=>'Người dùng'
                        ]);
                }
                else if($req->admin==2){
                     $users = User::orderBy('diem','desc')->paginate(50,['*'],'user');
                    return view('admin.page.user.index',[
                        'users'=>$users,
                        'type'=>'Điểm'
                        ]);
                }
                else {
                    $users = User::where('level',1)->paginate(50,['*'],'user');
                    return view('admin.page.user.index',[
                        'users'=>$users,
                        'type'=>'Admin'
                        ]);
                }
                
            }
        } 
        else return view('page.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                return view('admin.page.user.create');
            }
        }
        else return view('page.index');
    }

   
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
 

    public function store(Request $request)
    {
        //
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                
                $loto = new loto();
                $loto->iduser = $request->input('iduser');
                $loto->number = $request->input('number');
                $loto->ngaydanh = $request->input('ngaydanh');
                $loto->jackpot = 0;
                
                $loto->save();
                
                return redirect()->route('users.create')
                ->with('thanhcong','Tạo thành công!');
            }
        }
        else return view('page.index');
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                $user = User::find($user->id);
            return view('admin.page.user.edit',['user'=>$user]);
            }
        }
        else return view('page.index');
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        //
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                if($request->level=="on"){
                    $level = 1;
                }
                else $level=0;
            
                if($request->vip=="on"){
                    $vip = 1;
                }
                else $vip=0;
                
                $userUpdate = User::where('id', $user->id)
                    ->Update([
                        'diem'=>$request->input('diem'),
                        'level'=>$level,
                        'vip'=>$vip
                    ]);
                if($userUpdate){
                    return redirect()
                    ->route('users.index')
                    ->with('edit','Chỉnh sửa thành công');
                }
                //Quay lại trang ban đầu với tất cả thông tin của đối tượng đó
                return back()->withInput();
            }
        }
        else return view('page.index');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        //
        dd($user);
        $findUser = User::find($user->id);
        if($findUser->delete()){
            return redirect()->route('users.index')
             ->with('delete','Xóa User thành công');
        }
        //return back()->withInput()->with('error','Company could not be delete');
    }
    public function deleteItem(Request $req)
    {
        if(Auth::check()){
            if(Auth::user()->level == 0){
                return view('page.index');
            }
            else{
                $user = User::find($req->id);
                $countUser = User::where('level',1)->count();
                if($user->level == 1 && $countUser==1){
                    return redirect()->route('user.index')->with('thatbai','Không thể xóa Admin cuối cùng!');
                }
                else{
                    ruttien::where('iduser',$req->id)->delete();
                    giaodich::where('iduser',$req->id)->delete();
                    danhde::where('iduser',$req->id)->delete();
                    User::find($req->id)->delete();
                    return response()->json();
                }
            }
        }
        else return view('page.index');
    }
}
