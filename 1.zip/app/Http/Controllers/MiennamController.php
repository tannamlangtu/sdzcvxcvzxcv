<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Hash;
use App\User;
use App\daycity;
use App\ketqua;
use App\city;
use App\kqxs;
use App\giaikqxs;
use App\Comment;
class MiennamController extends Controller
{
	      public function xshcm(){   
     return view('miennam.hochiminh');
    }
    public function xstg(){   
     return view('miennam.tiengiang');
    }
      public function xsbt(){
     return view('miennam.bentre');
    }
      public function xsag(){
     return view('miennam.angiang');
    }
    public function xsla(){
     return view('miennam.longan');
    }
     public function xskg(){
     return view('miennam.kiengiang');
    }
     public function xsbl(){
     return view('miennam.baclieu');
    }
     public function xstn(){
     return view('miennam.tayninh');
    }
     public function xsbp(){   
     return view('miennam.binhphuoc');
    }
      public function xsdl(){
     return view('miennam.dalat');
    }
      public function xsvt(){
     return view('miennam.vungtau');
    }
      public function xsbthuan(){
     return view('miennam.binhthuan');
    }
      public function xshg(){
     return view('miennam.haugiang');
    }
     public function xsct(){
     return view('miennam.cantho');
    }
     public function xsbd(){
     return view('miennam.binhduong');
    }
     public function xsdt(){
     return view('miennam.dongthap');
    }
     public function xsdn(){
     return view('miennam.dongnai');
    }
     public function xstv(){
     return view('miennam.travinh');
    }
     public function xscm(){
     return view('miennam.camau');
    }
     public function xsst(){
     return view('miennam.soctrang');
    }
     public function xsvl(){
     return view('miennam.vinhlong');
 }
}