<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Hash;
use App\User;
use App\daycity;
use App\ketqua;
use App\city;
use App\kqxs;
use App\giaikqxs;
use App\Comment;
class MientrungController extends Controller
{
	      public function xskh(){   
     return view('mientrung.khanhhoa');
    }
    public function xsdn(){   
     return view('mientrung.danang');
    }
      public function xsqn(){
     return view('mientrung.quangngai');
    }
    public function xskt(){
     return view('mientrung.kontum');
    }
      public function xsbd(){
     return view('mientrung.binhdinh');
    }
    public function xsbn(){
     return view('mientrung.dacnong');
    }
    public function xspy(){
     return view('mientrung.phuyen');
    }
    public function xsqb(){
     return view('mientrung.quangbinh');
    }
     public function xshue(){
     return view('mientrung.hue');
    }
     public function xsqt(){
     return view('mientrung.quangtri');
    }
     public function xsdl(){
     return view('mientrung.daclac');
    }
     public function xsgl(){   
     return view('mientrung.gialai');
    }
      public function xsqnam(){
     return view('mientrung.quangnam');
    }
      public function xsnt(){
     return view('mientrung.ninhthuan');
    }

}