<?php
use App\loto;
use App\User;
$users = user::latest('created_at')->paginate(1);
$homnay = date("Y-m-d");
$b = $ngay;
$plus = 1; 
?> 
 <?php $__env->startSection('content'); ?>

<div class="container">
            <h1 style="color: red;text-align: center">LOTO ONLINE</h1>
            <div class="col-md-12 txtmb">(Miền Bắc)</div>
            <div class="col-xs-12  col-md-12 div_note"><span class="note">Lưu ý:</span> <br>
                <i> -Chỉ chơi loto Miền Mắc</i>
                <br>
                <i> -Thời gian kết thúc chơi loto vào lúc  18h hàng ngày và bắt đầu chơi lô và tổng kết số điểm sau 18h45 phút.</i>
                <i> -Mỗi thành viên chỉ được chốt số 1 lần duy nhất trong ngày.</i>
                <br>
                <i> -Thành viên có điểm lô cao nhất trong tháng sẽ nhận được 500k.</i>
            </div>
        </div>


<section>
        <h3 class="header h3_thongke" style="margin-bottom: 0px;"><span>THÀNH VIÊN CHỐT LOTO ONLINE NGÀY <?php
                            $n=date_create("$ngay");
                            echo date_format($n,"d-m-Y"); 
                      ?>      
          </span>
            
            
        </h3>
        
  <?php $__currentLoopData = $loto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="div_loto_online" class="post notice">
                        <div class="row_loto row_loto1">
                <div class="row">
                    <div class="row user-info left_loto">
                        <div class="col-xs-2 col-md-1 avt">
                            <a href="/user/<?php echo e($u->user->name); ?>">
                                <img class="img-circle avt_chat" src="public/uploads/avatars/<?php echo e($u->user->image); ?>" alt="<?php echo e($u->user->name); ?>">
                            </a>
                        </div>
                        <div class="col-xs-6 col-md-5 name">
                            <a class="name-chat" href="/user/<?php echo e($u->user->name); ?>"><h4><?php echo e($u->user->name); ?></h4></a>

                            <span class="point-loto"><?php echo e($u->user->diem); ?> điểm</span>
                        </div>
                    </div>
                    <div class="post-content right_loto">
                        <div class="col-xs-12">
                            <i class="time time-chat"><?php 
                            $date=date_create("$u->created_at");
                            echo date_format($date,"d/m/Y H:i:s"); 
                            ?></i>
                            <p class="p_logo">
                                <span>CHỐT:</span> <?php echo e($u->number); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>

                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
 
 <div class="row">
                    <div class="row left_loto">
    <ul><li><a href="loto-online/<?php echo date("Y-m-d",strtotime("$b -$plus day")); ?>"><img src="images/truoc.png" alt="Ngày sau">Ngày trước</a></li></ul>

                    </div>
                    <div class="row right_loto">
                         <?php if($homnay === $b): ?>
    <?php else: ?>
     <li><a href="loto-online/<?php echo date("Y-m-d",strtotime("$b +$plus day")); ?>">Ngày sau</a></li>
    <?php endif; ?>
                    </div>
                </div>

    
                                                        

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>