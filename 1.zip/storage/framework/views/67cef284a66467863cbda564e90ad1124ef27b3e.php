 <script src="<?php echo e(asset('/js/app.js')); ?>"></script> 
    <script src="<?php echo e(asset('/js/main.js')); ?>"></script> 
<header id="header">
    <div class="header">
        <a id="logo" href="/"><img src="images/soicau-banner1.PNG" alt="Go Soi Cầu"></a>    </div>
    
    <ul id="menu">
        <li class="li_home">
            <a href="/">Home</a>
        </li>
        <li class="li_menu_des">
            <a href="ket-qua-xoso">Kết Quả Xổ Số</a>
        </li>
        <li class="li_menu_mobi">
            <a href="/ket-qua/mien-bac">KQXS</a>
        </li>
        <li class="li_menu_sub">
            <a> Soi cầu</a>
            <ul class="sub-menu" style="display: none">
                <li><img src="soicau/frontend/t.png"> <a href="soi-cau">Miền bắc</a></li>
                <li><img src="soicau/frontend/t.png"> <a href="soi-cau/dac-biet">XSMB Giải Đb</a></li>
                <li><img src="soicau/frontend/t.png"> <a href="soi-cau/thong-ke">Thống kê lô gan</a></li>
                 <li><img src="soicau/frontend/t.png"> <a href="chan-le-dac-biet">Chẳn lẻ đặc biệt</a></li>
                 <li><img src="soicau/frontend/t.png"> <a href="thong-ke-00-99">Thống kê 00-99</a></li>
            </ul>
        </li>
        <li>
            <a href="loto-online"> LOTO ONLINE</a>
        </li>

        <li class="show-sub-menu">
            <img src="soicau/images/icon_menu.png">
            <ul class="sub-menu" style="display: none">
                <li>
                    <img src="soicau/frontend/t.png" />
                    <a href="/so-mo">Sổ mơ</a>
                </li>
                <li>
                    <img src="soicau/frontend/t.png" />
                    <a href="quay-thu">Quay thử xổ số</a>
                </li>
                <li>
                    <img src="soicau/frontend/t.png" />
                    <a href="/tim-kiem-thanh-vien">tìm thành viên</a>
                </li>
            </ul>

        </li>
    </ul>
    <ul id="sub-menu">

        <li>
            <a class="current" href="ket-qua/mien-bac">Miền bắc</a>
        </li>
        <li>
            <a class="" href="ket-qua/mien-trung">Miền trung</a>
        </li>
        <li>
            <a class="" href="ket-qua/mien-nam">Miền nam</a>
        </li>
    </ul>
</header>
<?php if(Auth::check()): ?>
<div id="user-info">
    Thành viên:
    <a href="me"><?php echo e(Auth::user()->name); ?></a> |
    <a href="inbox">Hộp Thư
        <sup class="new-messages">1</sup>
    </a> |
<?php if(Auth::user()->vip==0): ?> 
<a href="nap-the">Nâng cấp vip</a> |
<?php endif; ?> 

    <a href="<?php echo e(route('dangxuat')); ?>">Thoát</a>
    <br>
    <span>Loại tài khoản:
        <b style="color: red;">
            <b style="color: #0C528E;"><?php if(Auth::user()->vip==0) echo "Thường"; else echo"VIP";?></b>
        </b>
    </span>
</div>
<?php else: ?>
<div id="login-box" class="btn-group">
    <a class="btn btn-success" href="<?php echo e(route('dangky')); ?>">Đăng Ký</a>
    <a class="btn btn-success" href="<?php echo e(route('dangnhap')); ?>">Đăng Nhập</a>
</div>
<?php endif; ?>