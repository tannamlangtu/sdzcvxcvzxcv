 <?php $__env->startSection('content'); ?>

<?php 
use App\User;
$users = user::latest('created_at')->paginate(1); 
?> 
<?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul class="list-group">
        <li class="list-group-item">Hình đại diện: <img style="margin-left: 20px;" src="public/uploads/avatars/<?php echo e($n->image); ?>" class="img-circle" width="70" height="70"></li>
        <li class="list-group-item">Nickname: <?php echo e($n->name); ?> <b></b></li> 
        <?php $lenght = strlen($n->phone);?>
        <li class="list-group-item">Số ĐT: <b><?php echo e(substr($n->phone,0,$lenght-5)); ?>*****</b></li>
        <li class="list-group-item">Điểm: <b><?php echo e($n->diem); ?></b></li>
        

    </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



 <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>