 <?php $__env->startSection('content'); ?>
<div class="main page-lode">
    <?php if(Session::has('reset')): ?>
    <div class="alert alert-<?php echo e(Session::get('flag')); ?>">
        <?php echo e(Session::get('reset')); ?>

    </div>
    <?php endif; ?>
    <?php if(count($errors)>0): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($err); ?><br/>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <?php if(Auth::check()): ?>
    <div id="div_updatethongkhachhang" class="ca-nhan">
        <form action="<?php echo e(route('reset')); ?>" method="post">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
            <div class="title">Sửa thông tin</div>
            <div class="thong-tin form-horizontal">
                <div class="form-group">
                    <label for="inputEmail3" class="col-xs-3 control-label">Email (
                        <font color="red">
                            <b>*</b>
                        </font>)</label>
                    <div class="col-xs-4">
                        <input id="form_customer_id" type="hidden" class="form-control" value="32">
                        <input disabled="disabled" value="<?php echo e(Auth::user()->email); ?>" id="form_customer_detail_email" type="text"
                            class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEmail3" class="col-xs-3 control-label">
                        Mật khẩu (
                        <font color="red">
                            <b>*</b>
                        </font>)
                    </label>
                    <div class="col-xs-4">
                        <input id="form_customer_detail_password" type="password" name="password" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEmail3" class="col-xs-3 control-label">
                        Xác Nhận mật khẩu (
                        <font color="red">
                            <b>*</b>
                        </font>)
                    </label>
                    <div class="col-xs-4">
                        <input id="form_customer_detail_password_confirm" type="password" name="password_repeate" class="form-control" required>
                    </div>
                </div>
            </div>
            <div class="sua-thong-tin" style="margin-top:10px;">
                <button type="submit" class="btn btn-signin" >
                    <i class="glyphicon glyphicon-floppy-saved"></i>Cập nhật</button>
            
            
                <button  class="btn btn-signin" >
                    <i class="glyphicon glyphicon-floppy-saved"></i><a href='/'>Hủy</a></button>
            </div>
        </form>
    </div>
    <?php else: ?>
    <li>
  <strong><big>
  <a href='dang-nhap'>Bạn chưa đăng nhập</a>
</strong></big>
</li>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>