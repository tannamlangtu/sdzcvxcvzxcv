 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php $date = date("d-m-Y")  ?>
   
           
<?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("https://xosodacbiet.com/thong-ke-tan-suat-lo-to-vip-tu-00-den-99.html");
        $soi = $html->find("div.box",2);
        $soi1 = $html->find("div.box",1);
         ?>

<?php echo $soi; ?>

<?php echo $soi1; ?>

<style type="text/css">
.tk-txloto.colgiai th, .tk-txloto.colgiai tr td:first-child {
    font-size: 11px;
    font-weight: 700;
}
      .tk-txloto.colgiai .bg_note .clnote {
    font-weight: 700;
}
.box-tk .colgiai tr th, .clnote {
    color: #ed0303;
}

*
.colgiai td {
    border-left: 1px solid #e4e4e4;
    text-align: center;
    padding: 3px 5px;
}
.title, .title-r, table td {
    font-size: 14px;
    text-align: center;
}
.colgiai {
    font-family: Tahoma,Geneva,sans-serif;
}
user agent stylesheet
table {
    display: table;
    border-collapse: separate;
    border-spacing: 2px;
    border-color: grey;
}



.hrate {
    background: #da1c47;
}
.hrate {
    width: 10px;
    display: inline-block;
}
.hrate {
    width: 10px;
    display: inline-block;
    background: #da1c47;
}

*
.colgiai td div {
    font-size: 18px;
    font-weight: 700;
    min-height: 20px;
    padding: 2px 0;
    margin: auto auto 2px;
    display: block;
}
#mega645 .results li .caption, #mega645 .results li .data td p, #mega645 .title, .coppyr, .cp_sms, .txt-center, footer .share-social {
    text-align: center;
}

.colgiai td {
    border-left: 1px solid #e4e4e4;
    text-align: center;
    padding: 3px 5px;
}
.title, .title-r, table td {
    font-size: 14px;
    text-align: center;
}
.colgiai {
    font-family: Tahoma,Geneva,sans-serif;
}
user agent stylesheet
table {
    display: table;
    border-collapse: separate;
    border-spacing: 2px;
    border-color: grey;
}
</style>
   <br>
</section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>