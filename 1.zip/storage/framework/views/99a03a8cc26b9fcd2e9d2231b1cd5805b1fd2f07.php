<?php 
use App\Comment;
$comments = Comment::latest('created_at')->paginate(15);
 ?>

<script language="javascript" src="http://code.jquery.com/jquery-2.0.0.min.js"></script>
<script>
    $(document).on('click','.pagination a', function(e){
           e.preventDefault();
           var page = $(this).attr('href').split('page=')[1];
           getPosts(page);
       });
  
       function getPosts(page)
       {
           $.ajax({
               type: "GET",
               url: '?page='+ page
           })
           .success(function(data) {
               $('body').html(data);
           });
       }
</script>
<?php if(Auth::check()): ?> 
<!-- nếu đã đăng nhập -->

<?php if(Auth::user()->vip==0): ?>
<!-- Nếu vip = 0 -->
<br>
<div class="row chat-form">
                <div class="col-xs-2 col-md-1">
                    <img src="soicau/images/chat.png" alt="chat">
                </div>
                                    <div class="col-xs-10 col-md-11">
                        Bạn cần phải nâng cấp lên VIP để bình luận <a href="/nap-the" class="btn btn-warning">Nâng cấp lên VIP</a>
                    </div>
                            </div>
                            <br>
<?php else: ?>
<!-- nếu là vip -->

        

                    <form id="comment-form" method="post" action="<?php echo e(route('comments.store')); ?>" >
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>" >

                        <div class="row" style="padding: 10px;">
                            <div class="form-group"> 
                                <textarea class="form-control" name="comment" placeholder="Viết bình luận..! "required  ></textarea>
                                
                            </div>
                        </div>
                        <div class="row" style="padding: 0 10px 0 10px;">
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary btn-lg" style="width: 100%" name="submit">
                            </div>
                        </div>
                    </form>
          <?php endif; ?>      
<form>
                <div class="panel-body comment-container" >
                    
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="well">
                            <div class="col-xs-2 col-md-1 avt">
                            <a href="/user/<?php echo e($comment -> user ->name); ?>">
                            <img src="public/uploads/avatars/<?php echo e($comment -> user ->image); ?>" alt="chat"  class="img-circle" width="46" height="48"">
                                </a>
                            </div>
                            <div class="col-xs-9 col-md-11 name">
                            <a class="name-chat" href="/user/<?php echo e($comment -> user ->name); ?>" ><h4><strong><?php echo e($comment->name); ?></strong></h4></a>
                            <i class="time time-chat">
                            <?php 
                            $date=date_create("$comment->created_at");
                            echo date_format($date,"Y/m/d H:i"); 
                            ?></i>
                            <span class="point-loto"><?php echo e($comment -> user ->diem); ?> điểm</span>
                            </div>
                            
                            <br><br><br>
                            <span> <big><?php 
                            echo nl2br($comment->comment);
                             ?></big> </span>
                            
                            <div style="margin-left:5px;">
                                <a style="cursor: pointer;" cid="<?php echo e($comment->id); ?>" name_a="<?php echo e(Auth::user()->name); ?>" token="<?php echo e(csrf_token()); ?>" class="reply"><?php if(Auth::user()->vip==0) echo ""; else echo"Trả lời";?></a>&nbsp;&nbsp;&nbsp;
                                <a style="cursor: pointer;"  class="delete-comment" token="<?php echo e(csrf_token()); ?>" comment-did="<?php echo e($comment->id); ?>" ><?php if(Auth::user()->vip==0) echo ""; else echo"Xóa";?></a>
                                <div class="reply-form">
                                    
                                    <!-- Dynamic Reply form -->
                                    
                                </div>
                                <br>
                                <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($comment->id === $rep->comment_id): ?>
                            <div class="well">
                            <div class="col-xs-9 col-md-11 name">
                            <a href="/user/<?php echo e($rep -> user ->name); ?>">
                            <img src="public/uploads/avatars/<?php echo e($rep -> user ->image); ?>" alt="chat"  class="img-circle" width="46" height="48"">
                            <a class="name-chat" href="/user/<?php echo e($rep -> user ->name); ?>" ><h4 ><strong>&nbsp;<?php echo e($rep->name); ?></strong></h4></a>
                            <i class="time time-chat">&nbsp;
                            <?php 
                            $date=date_create("$rep->created_at");
                            echo date_format($date,"Y/m/d H:i"); 
                            ?></i>
                            <span class="point-loto"><?php echo e($rep -> user ->diem); ?> điểm</span>
                            </div>
                                            
                                                 <br><br><br>
                                            <span> <big><?php 
                            echo nl2br($rep->reply);
                             ?></big> </span>
                                        
                                            <div class="reply-to-reply-form">
                                    
                                                <!-- Dynamic Reply form -->
                                                
                                            </div>
                                            
                            </div>
                                    <?php endif; ?> 


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e($comments->links()); ?>



                </section>  
    </form>    
<?php else: ?> 
<!-- nếu chưa đăng nhập -->

        <div class="row chat-form">
                <div class="col-xs-2 col-md-1">
                    <img src="soicau/images/chat.png" alt="chat">
                </div>
                                    <div class="col-xs-10 col-md-11">
                        Mời thành viên ra số và chém gió (Bạn chưa <a href="/login">đăng nhập</a>)
                    </div>
                            </div>


     <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        
                        <div class="well">
                            <div class="col-xs-2 col-md-1 avt">
                            <a href="/user/<?php echo e($comment -> user ->name); ?>">
                            <img src="public/uploads/avatars/<?php echo e($comment -> user ->image); ?>" alt="chat"  class="img-circle" width="46" height="48"">
                                </a>
                            </div>
                            <div class="col-xs-9 col-md-11 name">
                            <a class="name-chat" href="/user/<?php echo e($comment -> user ->name); ?>" ><h4><strong><?php echo e($comment->name); ?></strong></h4></a>
                            <i class="time time-chat">
                            <?php 
                            $date=date_create("$comment->created_at");
                            echo date_format($date,"Y/m/d H:i"); 
                            ?></i>
                            <span class="point-loto"><?php echo e($comment -> user ->diem); ?> điểm</span>
                            </div>
                            
                            <br><br><br>
                            <span> <big><?php 
                            echo nl2br($comment->comment);
                             ?></big> </span>
                            
                            
                                <div class="reply-form">
                                    
                                    <!-- Dynamic Reply form -->
                                    
                                </div>
                                <br>
                                <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($comment->id === $rep->comment_id): ?>
                                        <div class="well">
                                            <div class="col-xs-2 col-md-1 avt">
                            <a href="/user/<?php echo e($rep -> user ->name); ?>">
                            <img src="public/uploads/avatars/<?php echo e($rep -> user ->image); ?>" alt="chat"  class="img-circle" width="46" height="48"">
                            </div>
                            <div class="col-xs-9 col-md-11 name">
                            <a class="name-chat" href="/user/<?php echo e($rep -> user ->name); ?>" ><h4 ><strong>&nbsp;<?php echo e($rep->name); ?></strong></h4></a>
                            <i class="time time-chat">
                            <?php 
                            $date=date_create("$rep->created_at");
                            echo date_format($date,"Y/m/d H:i"); 
                            ?></i>
                            <span class="point-loto"><?php echo e($rep -> user ->diem); ?> điểm</span>
                            </div>
                                            
                                                 <br><br><br>
                                            <span> <big><?php 
                            echo nl2br($rep->reply);
                             ?></big> </span>
                                        
                                            <div class="reply-to-reply-form">
                                    
                                                <!-- Dynamic Reply form -->
                                                
                                            </div>
                                            
                                        </div>
                                    <?php endif; ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($comments->links()); ?>


        <?php endif; ?>
      