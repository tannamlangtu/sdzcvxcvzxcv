 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<?php 
$day = date("d-m-Y");
$plus = 1; ?>
<div class="list-tinh">
     <li><a class="" href="ket-qua/mien-trung/khanh-hoa">Khánh Hoà</a></li>
     <li><a class="" href="ket-qua/mien-trung/da-nang">Đà Nẵng</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-ngai">Quãng Ngãi</a></li>
     <li><a class="" href="ket-qua/mien-trung/kon-tum">Kon Tum</a></li>
     <li><a class="" href="ket-qua/mien-trung/binh-dinh">Bình Định</a></li>
     <li><a class="" href="ket-qua/mien-trung/dac-nong">Đắc Nông</a></li>
     <li><a class="" href="ket-qua/mien-trung/phu-yen">Phú Yên</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-binh">Quãng Bình</a></li>
     <li><a class="" href="ket-qua/mien-trung/thua-thien-hue">Huế</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-tri">Quãng Trị</a></li>
     <li><a class="" href="ket-qua/mien-trung/dac-lac">Dak Lak</a></li>
     <li><a class="" href="ket-qua/mien-trung/gia-lai">Gia Lai</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-nam">Quãng Nam</a></li>
     <li><a class="" href="ket-qua/mien-trung/ninh-thuan">Ninh Thuận</a></li>
 </div>
<div class="content-wrapper">
  
   
    <section id="ket-qua" style="margin-bottom: 15px;clear: both;">
        
       
<div class="row">
        <div class="col-xs-12">
            <table class="table table-bordered table-striped">
               <tbody>
                 
        <h3 class="header">Kết quả xổ số miền trung ngày <?php echo e($ngay = date("d-m-Y",strtotime($ngay))); ?></h3>
        
                    <tbody>
                            <tr class="gr-yellow">
                                <th class="first">Đài</th>
                                <?php $__currentLoopData = $city2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th>
    
                                        <b class="underline"><?php echo e($cty->name); ?></b>
                                    </a>
                                    <br/>
                                   
                                </th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr class="g8">
                                <td>G8</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_8_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G7</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_7_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G6</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_6_2']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_6_1']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_6_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G5</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_5_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G4</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_4_6']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_5']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_4']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_3']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_2']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_1']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G3</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_3_1']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_3_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G2</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_2_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G1</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_1_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr class="gdb">
                                <td>ĐB</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_0_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                </tbody>
            </table>
        </div>
    </div>
<div class="row">
        <div class="col-xs-12 ">
            <table class="table table-bordered table-striped">
                
                <tbody>
                        <tr class="header">
                            <th width="10%" class="first">Đầu</th>
                            <?php $__currentLoopData = $city2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($cty->name); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php for($k=0;$k<10;$k++): ?>
                        <tr>
                            <td>
                                <b class="clnote"><?php echo e($k); ?></b>
                            </td>
                            <?php for($i=0;$i<count($rmt);$i++): ?>
                            <td><?php $j=0; for($m=0;$m<count($kqmt[$i]);$m++){ if(substr($kqmt[$i][$m],0,1)==(string)$k){if($j==0){echo substr($kqmt[$i][$m],-2);$j=1;}else echo ', '.substr($kqmt[$i][$m],-2);}}?></td>
                            <?php endfor; ?>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
                </div>
            </table>
        </div>
    </div>
<div class="row">
        <div class="col-xs-12 ">
            <table class="table table-bordered table-striped">
                <tbody>
                        <tr class="header">
                            <th width="10%" class="first">Đít</th>
                            <?php $__currentLoopData = $city2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($cty->name); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php for($k=0;$k<10;$k++): ?>
                        <tr>
                            <td>
                                <b class="clnote"><?php echo e($k); ?></b>
                            </td>
                            <?php for($i=0;$i<count($rmt);$i++): ?>
                            <td><?php $j=0; for($m=0;$m<count($kqmt[$i]);$m++){ if(substr($kqmt[$i][$m],-1)==(string)$k){if($j==0){echo substr($kqmt[$i][$m],0,2);$j=1;}else echo ', '.substr($kqmt[$i][$m],0,2);}}?></td>
                            <?php endfor; ?>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
               
            </table>
        </div>
    </div>
<div class="row">
                    <div class="row left_loto">
    <ul><li><a href="mien-trung/<?php echo date("Y-m-d",strtotime("$ngay -$plus day")); 
                ?>"><img src="images/truoc.png" alt="Ngày sau">Ngày trước</a></li></ul>

                    </div>
                    <div class="row right_loto">
                        
    
     <li><a href="mien-trung/<?php echo date("Y-m-d",strtotime("$ngay +$plus day")); 
                ?>">Ngày sau</a></li>
   
                    </div>
                </div>


 <div class="row xem-them">
            <div class="col-xs-12">
                &gt;&gt; Xem thêm KQXS:

                <ul>
                                        <li><a class="" href="/ket-qua/mien-bac">Miền bắc</a></li>
                                        <li><a class="" href="/ket-qua/mien-trung">Miền trung</a></li>
                                        <li><a class="current" href="/ket-qua/mien-nam">Miền nam</a></li>
                                    </ul>
            </div>

        
 
    <!-- /.content -->
</div>
</section>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>