<div id="adv" class="row">
        <div class="col-xs-12">
            <div class="row">
                <div class="zone1 adv_text_top adv_text_top0">
                    <a href="http://soicau568.com/" rel="nofollow" target="_blank">
                        <p style="line-height: 16px;">
                            <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/09/vipgif1504952144.gif" alt="vip" />&nbsp;
                            <strong>
                                <span style="color: #0000ff; font-size: 14pt;">
                                    <span style="font-size: 10pt;">
                                        <span style="color: #0000ff;">Số chuẩn tuyệt mật từ HĐXS , Soi cầu si&ecirc;u chuẩn x&aacute;c B&aacute; Đạo từ
                                            chuy&ecirc;n gia , Nhanh tay truy cập lấy lộc đầu năm ===&gt;</span>
                                    </span>&nbsp;</span>
                            </strong>&nbsp;
                            <span style="color: #ff0000;">
                                <span style="font-size: 13.3333px;">
                                    <strong>soicau568.com</strong>
                                </span>
                            </span>&nbsp;
                            <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/09/vipgif1504952144.gif" alt="vip" />
                        </p>
                    </a>
                </div>
                <div class="zone1 adv_text_top adv_text_top1">
                    <a href="http://xosomienbac9999.com/" rel="nofollow" target="_blank">
                        <p style="line-height: 26px;">
                            <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                            />&nbsp;
                            <strong>
                                <span style="color: #0000ff; font-size: 14pt;">&nbsp;
                                    <span style="font-size: 10pt;">&nbsp;Th&ocirc;ng tin tuyệt mật đ&aacute;nh bại chủ l&ocirc; số chuẩn đ&oacute;n xu&acirc;n
                                        cầu đẹp mỗi n&agrave;y chỉ c&oacute; tại </span>
                                </span>
                            </strong>
                            <span style="font-size: 10pt; color: #ff0000;">
                                <strong>xosomienbac9999.com</strong>
                            </span>&nbsp;
                            <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                            />
                        </p>
                    </a>
                </div>
            </div>
        </div>
    </div>