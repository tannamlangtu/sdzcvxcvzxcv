 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="list-tinh">
     <li><a class="" href="ket-qua/mien-trung/khanh-hoa">Khánh Hoà</a></li>
     <li><a class="" href="ket-qua/mien-trung/da-nang">Đà Nẵng</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-ngai">Quãng Ngãi</a></li>
     <li><a class="" href="ket-qua/mien-trung/kon-tum">Kon Tum</a></li>
     <li><a class="" href="ket-qua/mien-trung/binh-dinh">Bình Định</a></li>
     <li><a class="" href="ket-qua/mien-trung/dac-nong">Đắc Nông</a></li>
     <li><a class="" href="ket-qua/mien-trung/phu-yen">Phú Yên</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-binh">Quãng Bình</a></li>
     <li><a class="" href="ket-qua/mien-trung/thua-thien-hue">Huế</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-tri">Quãng Trị</a></li>
     <li><a class="" href="ket-qua/mien-trung/dac-lac">Dak Lak</a></li>
     <li><a class="" href="ket-qua/mien-trung/gia-lai">Gia Lai</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-nam">Quãng Nam</a></li>
     <li><a class="" href="ket-qua/mien-trung/ninh-thuan">Ninh Thuận</a></li>
 </div>
<div class="content-wrapper">
  
    <?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
    use App\daycity;
    use App\city;
        include('ketquaxoso/simple_html_dom.php');
        $rmb = array();
        $rmt = array();
        $rmn = array();
        $day = date("d-m-Y");
        $plus = 1;
        
        if( date( 'H' ) > 19 || ( isset( $day ) && $day !== date( 'd-m-Y' ) ) ) {
        }
        else {
            $day = date("d-m-Y",strtotime("$day -$plus day"));
        }
        $html = file_get_html("http://vesophuongtrang.com/ket-qua-xo-so/".$day.".html");
        $inputmb = array(
            'rs_0_0' => '<img class="a1" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_1_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_2_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_2_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />'
        );
        $input = array(
            'rs_8_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_6' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_2_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_1_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_0_0' => '<img class="a1" src="ketquaxoso/Clock.gif" width="20" />',
        );
        
        $ketquamb = $html->find("table.kqxsmienbac div.dayso");
        if( date( 'H' ) > 19 || ( isset( $day ) && $day !== date( 'd-m-Y' ) ) ) {
            $i=0;
            foreach( $inputmb as $key => $value ){
                $rmb[$key] = $ketquamb[$i]->innertext;
                $i++;
            }
        }
        else {
            $rmb = $inputmb;
        }
        $thu = date('l', strtotime($day));
        if($thu=="Sunday") $thu = 1;
        if($thu=="Monday") $thu = 2;
        if($thu=="Tuesday") $thu = 3;
        if($thu=="Wednesday") $thu = 4;
        if($thu=="Thursday") $thu = 5;
        if($thu=="Friday") $thu = 6;
        if($thu=="Saturday") $thu = 7;
        $daycity = daycity::where('idday',$thu)->get();
        $city2 = array();
        $city3 = array();
        foreach($daycity as $dci){
            $cityy = city::where([['id',$dci->idcity],['idarea',2]])->first();
           if(!empty($cityy)>0){
                $city2[] = $cityy;
            }
        }
        foreach($daycity as $dci){
            $cityy = city::where([['id',$dci->idcity],['idarea',3]])->first();
           if(!empty($cityy)>0){
                $city3[] = $cityy;
            }
        }
        $j=0;
        $k=0;
        foreach($city2 as $cty2){
            $ten = $cty2->name;
            $tinh = $html->find("table.kqxsdaicol td.tentinh a");
            for($i=0;$i<count($tinh);$i++){
                if($cty2->name=="Hồ Chí Minh") $ten = "TP. HCM";
                else if($cty2->name=="Thừa Thiên Huế") $ten = "Thừa T. Huế";
                else if($cty2->name=="Lâm Đồng") $ten = "Đà Lạt";
                else if($cty2->name=="Đắc Lắc") $ten = "Đắk Lắk";
                else if($cty2->name=="Đà Nẵng"){
                    if($thu == "Thứ tư")
                    $ten = "Đà Nẵng";
                    else if($thu == "Thứ bảy")
                    $ten = "Đ.Nẵng";
                }
                else if($cty2->name=="Quảng Ngãi") $ten = "Q.Ngãi";
                else if($cty2->name=="Đắc Nông") $ten = "Đ.Nông";
                else if($cty2->name=="Long An") $ten = "L.An";
                else if($cty2->name=="Hậu Giang") $ten = "H.Giang";
                else if($cty2->name=="Bình Phước") $ten = "B.Phước";
                if($tinh[$i]->innertext==$ten){
                    $table = $html->find("table.kqxsdaicol",$i);
                    $ketquamt = $table->find("div.dayso");
                    break;
                }
            }
            if( date( 'H' ) > 19 || ( isset( $day ) && $day !== date( 'd-m-Y' ) ) ) {
                $i=0;
                foreach( $input as $key => $value ){
                    $rmt[$j][$key] = $ketquamt[$i]->innertext;
                    $i++;
                }
            }
            else {
                $rmt[$j] = $input;
            }
            $j++;
        }
        
        foreach($city3 as $cty3){
            $ten = $cty3->name;
            $tinh = $html->find("table.kqxsdaicol td.tentinh a");
            for($i=0;$i<count($tinh);$i++){
                if($cty2->name=="Hồ Chí Minh") $ten = "TP. HCM";
                else if($cty3->name=="Thừa Thiên Huế") $ten = "Thừa T. Huế";
                else if($cty3->name=="Lâm Đồng") $ten = "Đà Lạt";
                else if($cty3->name=="Đắc Lắc") $ten = "Đắk Lắk";
                else if($cty3->name=="Đà Nẵng"){
                    if($thu == "Thứ tư")
                    $ten = "Đà Nẵng";
                    else if($thu == "Thứ bảy")
                    $ten = "Đ.Nẵng";
                }
                else if($cty3->name=="Quảng Ngãi") $ten = "Q.Ngãi";
                else if($cty3->name=="Đắc Nông") $ten = "Đ.Nông";
                else if($cty3->name=="Long An") $ten = "L.An";
                else if($cty3->name=="Hậu Giang") $ten = "H.Giang";
                else if($cty3->name=="Bình Phước") $ten = "B.Phước";
                if($tinh[$i]->innertext==$ten){
                    $table = $html->find("table.kqxsdaicol",$i);
                    $ketquamn = $table->find("div.dayso");
                    break;
                }
            }
            if( date( 'H' ) > 19 || ( isset( $day ) && $day !== date( 'd-m-Y' ) ) ) {
                $i=0;
                foreach( $input as $key => $value ){
                    $rmn[$k][$key] = $ketquamn[$i]->innertext;
                    $i++;
                }
            }
            else {
                $rmn[$k] = $input;
            }
            $k++;
        }
        $kqmb = array();
        $kqmn = array();
        $kqmt = array();
        foreach($rmb as $kq){
            $kqmb[] = substr($kq,-2);
        }
        for($i=0;$i<count($rmn);$i++){
            foreach($rmn[$i] as $kq){
                $kqmn[$i][] = substr($kq,-2);
            }
        }
        for($i=0;$i<count($rmt);$i++){
            foreach($rmt[$i] as $kq){
                $kqmt[$i][] = substr($kq,-2);
            }
        }
         ?>


    <section id="ket-qua" style="margin-bottom: 15px;clear: both;">
        
       
<div class="row">
        <div class="col-xs-12">
            <table class="table table-bordered table-striped">
               <tbody>
                 
        <h3 class="header">Kết quả xổ số miền trung ngày <?php echo e($day); ?></h3>
        
                    <tbody>
                            <tr class="gr-yellow">
                                <th class="first">Đài</th>
                                <?php $__currentLoopData = $city2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th>
    
                                        <b class="underline"><?php echo e($cty->name); ?></b>
                                    </a>
                                    <br/>
                                   
                                </th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr class="g8">
                                <td>G8</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_8_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G7</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_7_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G6</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_6_2']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_6_1']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_6_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G5</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_5_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G4</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_4_6']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_5']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_4']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_3']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_2']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_1']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_4_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G3</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_3_1']; ?></div>
                                    <div><?php echo $rmt[$i]['rs_3_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G2</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_2_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G1</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_1_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr class="gdb">
                                <td>ĐB</td>
                                <?php for($i=0;$i<count($city2);$i++): ?>
                                <td>
                                    <div><?php echo $rmt[$i]['rs_0_0']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                </tbody>
            </table>
        </div>
    </div>
<div class="row">
        <div class="col-xs-12 ">
            <table class="table table-bordered table-striped">
                
                <tbody>
                        <tr class="header">
                            <th width="10%" class="first">Đầu</th>
                            <?php $__currentLoopData = $city2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($cty->name); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php for($k=0;$k<10;$k++): ?>
                        <tr>
                            <td>
                                <b class="clnote"><?php echo e($k); ?></b>
                            </td>
                            <?php for($i=0;$i<count($rmt);$i++): ?>
                            <td><?php $j=0; for($m=0;$m<count($kqmt[$i]);$m++){ if(substr($kqmt[$i][$m],0,1)==(string)$k){if($j==0){echo substr($kqmt[$i][$m],-2);$j=1;}else echo ', '.substr($kqmt[$i][$m],-2);}}?></td>
                            <?php endfor; ?>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
                </div>
            </table>
        </div>
    </div>
<div class="row">
        <div class="col-xs-12 ">
            <table class="table table-bordered table-striped">
                <tbody>
                        <tr class="header">
                            <th width="10%" class="first">Đít</th>
                            <?php $__currentLoopData = $city2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($cty->name); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php for($k=0;$k<10;$k++): ?>
                        <tr>
                            <td>
                                <b class="clnote"><?php echo e($k); ?></b>
                            </td>
                            <?php for($i=0;$i<count($rmt);$i++): ?>
                            <td><?php $j=0; for($m=0;$m<count($kqmt[$i]);$m++){ if(substr($kqmt[$i][$m],-1)==(string)$k){if($j==0){echo substr($kqmt[$i][$m],0,2);$j=1;}else echo ', '.substr($kqmt[$i][$m],0,2);}}?></td>
                            <?php endfor; ?>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
               
            </table>
        </div>
    </div>
<div class="row">
                    <div class="row left_loto">
    <ul><li><a href="mien-trung/<?php echo date("Y-m-d",strtotime("$day -$plus day")); 
                ?>"><img src="images/truoc.png" alt="Ngày sau">Ngày trước</a></li></ul>

                    </div>
                    <div class="row right_loto">
                        
    
     <li><a href="mien-trung/<?php echo date("Y-m-d",strtotime("$day +$plus day")); 
                ?>">Ngày sau</a></li>
   
                    </div>
                </div>


 <div class="row xem-them">
            <div class="col-xs-12">
                &gt;&gt; Xem thêm KQXS:

                <ul>
                                        <li><a class="" href="/ket-qua/mien-bac">Miền bắc</a></li>
                                        <li><a class="" href="/ket-qua/mien-trung">Miền trung</a></li>
                                        <li><a class="current" href="/ket-qua/mien-nam">Miền nam</a></li>
                                    </ul>
            </div>

        
 
    <!-- /.content -->
</div>
</section>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>