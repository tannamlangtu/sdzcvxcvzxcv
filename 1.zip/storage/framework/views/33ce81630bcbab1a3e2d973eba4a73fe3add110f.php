<?php 
 include('ketquaxoso/simple_html_dom.php');
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $inputmb = array(
            'rs_8_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_6' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_2_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_1_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_0_0' => '<img class="a1" src="ketquaxoso/Clock.gif" width="20" />',
        );
        $rmb = array();
        $ketquamb = array();
        for($u=0 ; $u<1; $u++){
           
            $html = file_get_html("https://vesophuongtrang.com/xo-so-vung-tau.html");
            $ketquamb[] = $html->find("table.bkqtinhmiennam div.dayso");
            $tinh = $html->find("div.box_dauduoi_header",0);
            if( count($ketquamb[$u]) != 0 ) {
                $i=0;
                foreach( $inputmb as $key => $value ){
                    $rmb[$u][$key] = $ketquamb[$u][$i]->innertext;
                    $i++;
                }
            }
            else {
                $rmb[$u] = $inputmb;
            }
            
            foreach($rmb[$u] as $kq){
                $kqmb[$u][] = substr($kq,-2);
            }
        }  
        
 ?>
 <?php echo $tinh; ?>

 <?php for($i=0;$i<count($rmb);$i++): ?>
 
<?php echo $rmb[$i]['rs_8_0']; ?>

<?php echo $rmb[$i]['rs_7_0']; ?>



 <div id="dd" class="col-firstlast">
                <table class="firstlast-mb fl" border="0" cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr class="header">
                            <th>Đầu</th>
                            <th>Đuôi</th>
                        </tr>
                        <?php for($k=0;$k<10;$k++): ?>
                            <tr>
                                <td>
                                    <b class="clnote"><?php echo e($k); ?></b>
                                </td>
                                <td><?php 
                                $j=0;
                                for($u=0;$u<count($kqmb[$i]);$u++){
                                    if(substr($kqmb[$i][$u],0,1)==(string)$k){
                                        if($j==0){
                                            echo substr($kqmb[$i][$u],-1);
                                            $j=1;
                                        }else echo ', '.substr($kqmb[$i][$u],-1);
                                    }
                                }
                                ?></td>
                            </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>
                <table cellspacing="0" cellpadding="0" border="0" class="firstlast-mb fr">
                    <tbody>
                        <tr class="header">
                            <th>Đầu</th>
                            <th>Đuôi</th>
                        </tr>
                        <?php for($k=0;$k<10;$k++): ?>
                            <tr>
                                <td><?php $j=0; for($u=0;$u<count($kqmb[$i]);$u++){ if(substr($kqmb[$i][$u],-1)==(string)$k){if($j==0){echo substr($kqmb[$i][$u],0,1);$j=1;}else echo ', '.substr($kqmb[$i][$u],0,1);}}?></td>
                                <td>
                                    <b class="clnote"><?php echo e($k); ?></b>
                                </td>
                            </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>
            </div>
            <?php endfor; ?>