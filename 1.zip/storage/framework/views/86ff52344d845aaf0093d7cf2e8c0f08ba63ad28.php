 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="list-tinh">
    <li><a class="" href="ket-qua/mien-trung/khanh-hoa">Khánh Hoà</a></li>
     <li><a class="" href="ket-qua/mien-trung/da-nang">Đà Nẵng</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-ngai">Quãng Ngãi</a></li>
     <li><a class="" href="ket-qua/mien-trung/kon-tum">Kon Tum</a></li>
     <li><a class="" href="ket-qua/mien-trung/binh-dinh">Bình Định</a></li>
     <li><a class="" href="ket-qua/mien-trung/dac-nong">Đắc Nông</a></li>
     <li><a class="" href="ket-qua/mien-trung/phu-yen">Phú Yên</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-binh">Cần Thơ</a></li>
     <li><a class="" href="ket-qua/mien-trung/thua-thien-hue">Huế</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-tri">Quãng Trị</a></li>
     <li><a class="" href="ket-qua/mien-trung/dac-lac">Dak Lak</a></li>
     <li><a class="" href="ket-qua/mien-trung/gia-lai">Gia Lai</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-nam">Quãng Nam</a></li>
     <li><a class="" href="ket-qua/mien-trung/ninh-thuan">Ninh Thuận</a></li>
 </div>
         


<div class="content-wrapper">
    
            
    <?php include('simple_html_dom.php');
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $inputmn = array(
            'rs_8_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_6' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_2_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_1_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_0_0' => '<img class="a1" src="ketquaxoso/Clock.gif" width="20" />',
        );
        $rmn = array();
        $kqmn = array();
        $ketquamn = array();
        for($u=0 ; $u<1; $u++){
           
            $html = file_get_html("https://vesophuongtrang.com/xo-so-kon-tum.html");
            $ketquamn[] = $html->find("table.bkqtinhmiennam div.dayso");
            $tinh = $html->find("div.box_dauduoi_header",0)->plaintext;
            
            if( count($ketquamn[$u]) != 0 ) {
                $i=0;
                foreach( $inputmn as $key => $value ){
                    $rmn[$u][$key] = $ketquamn[$u][$i]->innertext;
                    $i++;
                }
            }
            else {
                $rmn[$u] = $inputmn;
            }
            
            foreach($rmn[$u] as $kq){
                $kqmn[$u][] = substr($kq,-2);
            }
        }  
        
 ?>

    <section id="ket-qua" style="margin-bottom: 15px;clear: both;">
      <h3 class="header">Kết quả xổ số <?php echo e($tinh); ?> </h3>
      <?php for($i=0;$i<count($rmn);$i++): ?>
    </br>
    <div class="row">
        <div class="col-xs-12">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr class="info">
                        <th class="col-xs-1"> ĐB </th>
                        <th class="red">
                        <?php echo $rmn[$i]['rs_0_0']; ?> </th>
                    </tr>
                    <tr>
                        <th> G1 </th>
                        <th>
                        <?php echo $rmn[$i]['rs_1_0']; ?> </th>
                    </tr>
                    <tr>
                        <th> G2 </th>
                        <th>
                        <?php echo $rmn[$i]['rs_2_0']; ?> </th>
                    </tr>
                    <tr>
                        <th> G3 </th>
                        <th>
                       <?php echo $rmn[$i]['rs_3_0']; ?> - <?php echo $rmn[$i]['rs_3_1']; ?> </th>
                    </tr>
                    <tr>
                        <th> G4 </th>
                        <th>
                        <?php echo $rmn[$i]['rs_4_0']; ?> - <?php echo $rmn[$i]['rs_4_1']; ?> - <?php echo $rmn[$i]['rs_4_2']; ?> - <?php echo $rmn[$i]['rs_4_3']; ?> - <?php echo $rmn[$i]['rs_4_4']; ?> - <?php echo $rmn[$i]['rs_4_5']; ?> - <?php echo $rmn[$i]['rs_4_6']; ?> </th>
                    </tr>
                    <tr>
                        <th> G5 </th>
                        <th>
                        <?php echo $rmn[$i]['rs_5_0']; ?> </th>
                    </tr>
                    <tr>
                        <th> G6 </th>
                        <th>
                        <?php echo $rmn[$i]['rs_6_0']; ?> - <?php echo $rmn[$i]['rs_6_1']; ?> - <?php echo $rmn[$i]['rs_6_2']; ?> </th>
                    </tr>
                    <tr>
                        <th> G7 </th>
                        <th>
                        <?php echo $rmn[$i]['rs_7_0']; ?> </th>
                    </tr>
                    <tr>
                        <th> G8 </th>
                        <th>
                        <?php echo $rmn[$i]['rs_8_0']; ?> </th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-6">
            <table class="table table-bordered table-striped">
                <tr class="info">
                    <th class="col-xs-1">Đầu</th>
                    <th>Lô Tô</th>
                </tr>
                 <?php for($k=0;$k<10;$k++): ?>
                            <tr>
                                <td>
                                    <b class="clnote"><?php echo e($k); ?></b>
                                </td>
                                <td><?php 
                                $j=0;
                                for($u=0;$u<count($kqmn[$i]);$u++){
                                    if(substr($kqmn[$i][$u],0,1)==(string)$k){
                                        if($j==0){
                                            echo substr($kqmn[$i][$u],-2);
                                            $j=1;
                                        }else echo ', '.substr($kqmn[$i][$u],-2);
                                    }
                                }
                                ?></td>
                            </tr>
                        <?php endfor; ?>
            </table>
        </div>
          <div class="row">
        <div class="col-xs-12 col-sm-6">
            <table class="table table-bordered table-striped">
                <tr class="info">
                    <th class="col-xs-1">Đít</th>
                    <th>Lô Tô</th>
                </tr>
                <?php for($k=0;$k<10;$k++): ?>
                            <tr>
                                 <td>
                                    <b class="clnote"><?php echo e($k); ?></b>
                                </td>
                                <td>
                                    <?php $j=0; for($u=0;$u<count($kqmn[$i]);$u++){ if(substr($kqmn[$i][$u],-1)==(string)$k){if($j==0){echo substr($kqmn[$i][$u],0,2);$j=1;}else echo ', '.substr($kqmn[$i][$u],0,2);}}?></td>
                               
                            </tr>
                        <?php endfor; ?>
            </table>
        </div>
    </div>
<?php endfor; ?>
 <div class="row xem-them">
            <div class="col-xs-12">
                &gt;&gt; Xem thêm KQXS:

                <ul>
                                        <li><a class="" href="/ket-qua/mien-bac">Miền bắc</a></li>
                                        <li><a class="" href="/ket-qua/mien-trung">Miền trung</a></li>
                                        <li><a class="current" href="/ket-qua/mien-nam">Miền nam</a></li>
                                    </ul>
            </div>

        
    </section>
        <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>