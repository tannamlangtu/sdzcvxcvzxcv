<section>
        <h4 class="h4_title_tk">LÔ CHƠI NHIỀU NGÀY <?php echo e($date); ?></h4>
        <div id="stats" class="row stats div_thongke" style="margin-bottom: 20px;">
            <div class="col-xs-3 divbs">
                <span class="left">01</span>
                <span class="right">4 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">62</span>
                <span class="right">4 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">21</span>
                <span class="right">4 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">26</span>
                <span class="right">3 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">46</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">11</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">03</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">52</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">59</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">69</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">05</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">92</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">98</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">63</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">12</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">29</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">09</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">99</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">34</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">85</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">50</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">82</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">93</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">83</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">90</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">16</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">45</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">02</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">54</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">25</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">33</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">08</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">47</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">35</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">79</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">80</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">89</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">57</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">49</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">31</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">68</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">94</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">00</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">51</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">61</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">07</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">60</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">06</span>
                <span class="right">1 lần</span>
            </div>
        </div>
    </section>