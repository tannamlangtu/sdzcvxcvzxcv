 <?php $__env->startSection('content'); ?>

<?php 
    $date = date("d-m-Y");
     $day = date('l');
    if($day=="Sunday") $thui = "Chủ nhật";
    if($day=="Monday") $thui = "Thứ hai";
    if($day=="Tuesday") $thui = "Thứ ba";
    if($day=="Wednesday") $thui = "Thứ tư";
    if($day=="Thursday") $thui = "Thứ năm";
    if($day=="Friday") $thui = "Thứ sáu";
    if($day=="Saturday") $thui = "Thứ bảy";
     $sothu = date('l');
    if($sothu=="Sunday") $sothu = "1";
    if($sothu=="Monday") $sothu = "2";
    if($sothu=="Tuesday") $sothu = "3";
    if($sothu=="Wednesday") $sothu = "4";
    if($sothu=="Thursday") $sothu = "5";
    if($sothu=="Friday") $sothu = "6";
    if($sothu=="Saturday") $sothu = "7";
    $plus = 1;
  
?>
<div id="div_bor_content">

    <ul class="list-tinh">
    </ul>
    <script>
        var time_block = -1520816706
    </script>

    <div id="adv" class="row">
        <div class="col-xs-12">
            <div class="row">
                <div class="zone1 adv_text_top adv_text_top0">
                    <a href="http://soicau568.com/" rel="nofollow" target="_blank">
                        <p style="line-height: 16px;">
                            <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/09/vipgif1504952144.gif" alt="vip" />&nbsp;
                            <strong>
                                <span style="color: #0000ff; font-size: 14pt;">
                                    <span style="font-size: 10pt;">
                                        <span style="color: #0000ff;">Số chuẩn tuyệt mật từ HĐXS , Soi cầu si&ecirc;u chuẩn x&aacute;c B&aacute; Đạo từ
                                            chuy&ecirc;n gia , Nhanh tay truy cập lấy lộc đầu năm ===&gt;</span>
                                    </span>&nbsp;</span>
                            </strong>&nbsp;
                            <span style="color: #ff0000;">
                                <span style="font-size: 13.3333px;">
                                    <strong>soicau568.com</strong>
                                </span>
                            </span>&nbsp;
                            <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/09/vipgif1504952144.gif" alt="vip" />
                        </p>
                    </a>
                </div>
                <div class="zone1 adv_text_top adv_text_top1">
                    <a href="http://xosomienbac9999.com/" rel="nofollow" target="_blank">
                        <p style="line-height: 26px;">
                            <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                            />&nbsp;
                            <strong>
                                <span style="color: #0000ff; font-size: 14pt;">&nbsp;
                                    <span style="font-size: 10pt;">&nbsp;Th&ocirc;ng tin tuyệt mật đ&aacute;nh bại chủ l&ocirc; số chuẩn đ&oacute;n xu&acirc;n
                                        cầu đẹp mỗi n&agrave;y chỉ c&oacute; tại </span>
                                </span>
                            </strong>
                            <span style="font-size: 10pt; color: #ff0000;">
                                <strong>xosomienbac9999.com</strong>
                            </span>&nbsp;
                            <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                            />
                        </p>
                    </a>
                </div>
            </div>
        </div>
    </div>


    <div id="soi-cau">
        <div id="soi-cau">
            <h4>Soi cầu kết quả xổ số Miền bắc ngày <?php echo e($date); ?></h4>
<?php if(Auth::check()): ?>
             
        <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/soicau.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng 
                    <?php if(Auth::user()->vip==0) echo "<A HREF='nap-the'>Nâng cấp Vip</A>"; else echo"<A HREF='chot-so'>Click vào đây</A>";?></b>
                    </a> để xem admin chốt số </div>
            </div>
        </div>
<?php else: ?>
    
            <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/soicau.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng
                    <a href="/register">Đăng Ký</a> hoặc
                    <a href="/login">Đăng nhập</a> để xem admin chốt số </div>
            </div>

<?php endif; ?> 
    </div>



    <div id="adv" class="row">
        <div class="col-xs-12">
            <div class="row">
                <div id="hide_float_right_zone2" class="hideQCAlign">
                    <a href="javascript:HOME.hide_float_right_zone2()">Tắt quảng cáo [X]</a>
                </div>
                <div id="float_content_right_zone2" class="QCAlign" style="display: block;">

                    <div class="zone">

                        <a href="http://soicaudinhcao.net" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/6-soicaudinhcao-netgif1519669297.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://xoso3mien24h.com" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/7-xoso3mien-24h-comgif1519669333.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://xosotailoc9999.com" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/8-xosotailoc9999-comgif1519669369.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://sochuan366.top" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/1-sochuan366-topgif1519668960.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://sochuanvaobo.me" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/2-sochuanvaobo-megif1519669033.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://caudepmienbac.mobi" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/caudepmienbac-m0bigif1519699054.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://sovangmayman.com" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/4-sovangmayman-comgif1519669218.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://sovip.top" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/5-sovip-topgif1519669255.gif" class="img-responsive center-block">
                        </a>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <div id="adv" class="row">
        <div class="col-xs-12">
            <div class="row">
                <div id="hide_float_right_zone4" class="hideQCAlign">
                    <a href="javascript:HOME.hide_float_right_zone4()">Tắt quảng cáo [X]</a>
                </div>
                <div id="float_content_right_zone4" class="QCAlign" style="display: block;">
                    <div class="list2 list2_chu"></div>
                    <div class="zone1">

                        <a href="http://soicaumb288.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 25px; margin-top: 0px;" src="soicau/upload/files/2017/03/moigif1490371428.gif" alt="mới"
                                />
                                <span style="font-size: 10pt;">&nbsp;
                                    <span style="color: #ff0000;">
                                        <strong>&nbsp;BAN Đ&Atilde; C&Oacute; SỐ ĐẸP CHO H&Ocirc;M NAY CHƯA NHỈ , H&Atilde;Y ĐẾN
                                            VỚi CH&Uacute;NG T&Ocirc;i ĐỂ NHẬN NHỮNG CON SỐ ĐẸP NHẤt TRONG NG&Agrave;Y
                                        </strong>
                                    </span>
                                </span>&nbsp;&nbsp;
                                <strong>
                                    <span style="color: #008000; font-size: 14pt;">
                                        <span style="color: #ff6600;">
                                            <span style="color: #0000ff; font-size: 10pt;">soicaumb288.com</span>&nbsp;
                                            <img style="max-width: 600px; height: 25px; margin-top: 0px;" src="soicau/upload/files/2017/03/moigif1490371428.gif" alt="mới"
                                            />
                                        </span>
                                    </span>
                                </strong>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://hoidongsovip68.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; margin-top: 0px; height: 20px;" src="soicau/upload/files/2017/03/newgif1490378591.gif" alt="new"
                                />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 10pt;">Ch&agrave;o ae nha , nếu lấy số đẹp h&atilde;y truy cập ngay wapsite của em nh&eacute;
                                        , số chuẩn , cầu đang th&ocirc;ng &nbsp;</span>
                                    <span style="color: #0000ff; font-size: 10pt;">
                                        <span style="color: #ff0000;">HOIDONGSOVIP68.COM</span>
                                    </span>
                                    <span style="color: #008000; font-size: 14pt;">&nbsp;</span>
                                    <img style="max-width: 600px; margin-top: 0px; height: 20px;" src="soicau/upload/files/2017/03/newgif1490378591.gif" alt="new22"
                                    />
                                </strong>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://soicauvang24h.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2016/12/vipgif1480788461.gif" alt="icon vip"
                                />&nbsp;
                                <span style="font-size: 10pt;">
                                    <strong>
                                        <span style="color: #0000ff;">&nbsp;CON SỐ MAY MẮN CỦA CH&Uacute;Ng T&Ocirc;I SẼ GI&Uacute;P C&Aacute;C BẠN V&Agrave;O
                                            BỜ , C&Ograve;N CHỜ G&Igrave; nỮA NHANH TAY TRUY CẬP NGAY&nbsp;
                                        </span>
                                    </strong>
                                </span>&nbsp;
                                <strong>
                                    <span style="color: #008000; font-size: 16pt;">
                                        <span style="color: #ff0000; font-size: 10pt;">soicauvang24h.com</span>&nbsp;&nbsp;
                                        <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2016/12/vipgif1480788461.gif" alt="icon vip"
                                        />
                                    </span>
                                </strong>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://soicau24h.info/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 22px; margin-top: 0px;" src="soicau/upload/files/2017/03/clickgif1490376092.gif" alt="click"
                                />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: 10pt;">
                                            <span style="color: #ff0000;">Lại một năm nữa bắt đầu , ch&uacute;ng t&ocirc;i những chuy&ecirc;n gia xổ số
                                                cao cấp sẽ m&atilde;i đồng h&agrave;nh c&ugrave;ng c&aacute;c bạn </span>
                                            <span style="color: #008000;">&nbsp;</span>
                                        </span>
                                    </span>
                                </strong>
                                <span style="font-size: 10pt; color: #0000ff;">
                                    <strong>SOICAU24H.INFO</strong>
                                </span>
                                <img style="max-width: 600px; height: 22px; margin-top: 0px;" src="soicau/upload/files/2017/03/click-2gif1490376594.gif"
                                    alt="click2" />
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://congtyxosophattaiphatloc6868.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; height: 15px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotqua-newgif1490369489.gif"
                                    alt="hotqua-new" />
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: 10pt;">Ch&uacute;ng t&ocirc;i gi&uacute;p h&agrave;ng trăm ae v&agrave;o bờ an to&agrave;n
                                            , thử rồi mới tin thật</span>&nbsp;</span>
                                </strong>
                                <span style="font-size: 14pt; color: #ff0000;">
                                    <span style="color: #000000;">
                                        <strong>
                                            <span style="color: #ff0000; font-size: 10pt;">CONGTYXOSOPHATTAIPHATLOC6868.COM</span>&nbsp;
                                            <img style="max-width: 600px; height: 15px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotqua-newgif1490369489.gif"
                                                alt="hot-qua-new" />
                                        </strong>
                                    </span>
                                </span>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://cauchuansodepmb289.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                                />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: 10pt;">Con số chuẩn tuyệt mật từ hđxs - soi cầu ch&iacute;nh x&aacute;c - soi la chuẩn -
                                            đ&aacute;nh l&agrave; ăn </span>
                                        <span style="font-size: large;">&nbsp;</span>
                                    </span>
                                </strong>
                                <span style="font-size: 10pt; color: #ff0000;">
                                    <strong>CAUCHUANSODEPMB289.COM&nbsp;</strong>
                                </span>
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                                />
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://sodep1368.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <span style="font-size: 10pt;">
                                    <img style="max-width: 600px; height: 25px;" src="soicau/upload/files/2017/10/moi-xanhlagif1508250117.gif" alt="iconmoi"
                                    />&nbsp;
                                    <span style="color: #ff0000;">
                                        <strong>Kh&ocirc;ng theo sẽ hối tiếc , h&atilde;y click để nhận số đẹp nhất h&ocirc;m nay
                                            tại</strong>
                                    </span>
                                </span>
                                <span style="color: #510080;">
                                    <span style="color: #008000;">&nbsp;</span>&nbsp;</span>
                                <strong>
                                    <span style="color: #008000; font-size: 14pt;">
                                        <span style="color: #ff6600;">
                                            <span style="color: #0000ff; font-size: 10pt;">SODEP1368.COM</span>&nbsp;
                                            <img style="max-width: 600px; height: 25px;" src="soicau/upload/files/2017/10/moi-xanhlagif1508250117.gif" alt="mới" />
                                        </span>
                                    </span>
                                </strong>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://caudep366.mobi/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                                />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: small;">&nbsp;Lấy số từ hội đống xổ số , gỡ nợ mang tiền về mua xe duy nhất chỉ c&oacute;
                                            tại ==&gt;&gt;</span>
                                    </span>
                                </strong>
                                <span style="color: #ff0000; font-size: small;">
                                    <strong>CAUDEP366.MOBI</strong>
                                </span>
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                                />
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://soilode88.mobi/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/10/vip-timgif1508250358.gif" alt="vip" />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: 10pt;">
                                            <span style="color: #ff0000;">Số đẹp , phao lớn đưa ae xa bờ cập bến ae truye cập ngay để v&agrave;o bờ nha
                                                </span>&nbsp;</span>&nbsp;</span>
                                </strong>&nbsp;
                                <span style="color: #0000ff;">
                                    <span style="font-size: 13.3333px;">
                                        <strong>SOiLODE88.MOBI</strong>
                                    </span>
                                </span>&nbsp;
                                <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/10/vip-timgif1508250358.gif" alt="vip" />
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://caudep689.net/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 22px; margin-top: 0px;" src="soicau/upload/files/2017/03/clickgif1490376092.gif" alt="click"
                                />&nbsp;
                                <span style="color: #ff0000;">
                                    <strong>
                                        <span style="font-size: 14pt;">
                                            <span style="font-size: 10pt;">Số chuẩn từ hđxs c&oacute; ngay tại đ&acirc;y , đầu năm tr&uacute;ng số , cả
                                                năm lộc về truy cập ngay&nbsp;</span>
                                        </span>
                                    </strong>&nbsp;</span>
                                <span style="font-size: 10pt; color: #0000ff;">
                                    <strong>CAUDEP689.NET</strong>
                                </span>&nbsp;
                                <img style="max-width: 600px; height: 22px; margin-top: 0px;" src="soicau/upload/files/2017/03/click-2gif1490376594.gif"
                                    alt="click2" />
                            </p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<section id="chot-so">
        <div class="header">Khu vực chốt số của quản trị viên</div>
<?php if(Auth::check()): ?>
    <p style="padding: 15px;padding-bottom: 0; font-size: 18px;font-weight: bold;">
         <?php if(Auth::user()->vip==0) echo "Bạn phải là <A HREF='nap-the'>thành viên Vip</A> mới xem các QTV chốt số</A>"; else echo"<A HREF='chot-so'>Click vào đây</A> để xem QTV chốt số</A>";?>
         <?php else: ?>
        
              <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/soicau.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng
                    <a href="/register">Đăng Ký</a> hoặc
                    <a href="/login">Đăng nhập</a> để xem admin chốt số </div>
            </div>
    </section>
<?php endif; ?>
    <section>
        <h4 class="h4_title_tk">LÔ CHƠI NHIỀU NGÀY <?php echo e($date); ?></h4>
        <div id="stats" class="row stats div_thongke" style="margin-bottom: 20px;">
            <div class="col-xs-3 divbs">
                <span class="left">01</span>
                <span class="right">4 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">62</span>
                <span class="right">4 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">21</span>
                <span class="right">4 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">26</span>
                <span class="right">3 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">46</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">11</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">03</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">52</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">59</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">69</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">05</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">92</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">98</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">63</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">12</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">29</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">09</span>
                <span class="right">2 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">99</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">34</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">85</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">50</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">82</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">93</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">83</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">90</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">16</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">45</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">02</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">54</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">25</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">33</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">08</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">47</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">35</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">79</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">80</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">89</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">57</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">49</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">31</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">68</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">94</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">00</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">51</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">61</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">07</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">60</span>
                <span class="right">1 lần</span>
            </div>
            <div class="col-xs-3 divbs">
                <span class="left">06</span>
                <span class="right">1 lần</span>
            </div>
        </div>
    </section>
</div>
<input type="hidden" id="avata_user" value="images/avt/soi-cau-366.png" />
<input type="hidden" id="first_name_user" value="" />
<input type="hidden" id="slug_user" value="" />
<input type="hidden" id="point_user" value="0" />
<input type="hidden" id="count_chat" value="25" />
<input type="hidden" id="province_id" value="13">
  <input type="hidden" id="input_token" value="ttcNpx0fXEsIIQiuRATTjS0AAb7mGxAGUZvksdeA">
    <section id="forum">
        <h3 class="header">Diễn đàn chém gió soi cầu dự đoán kết quả xổ số</h3>
        



                
<?php if(Auth::check()): ?>


 
<section id="Forum">
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                   


<?php if(Auth::user()->vip==0): ?>  
               

            <div class="row chat-form">
                
                    <img src="soicau/images/chat.png" alt="chat">
          
                        Bạn cần phải nâng  <a href="/nap-the"> cấp lên VIP</a>
                    để bình luận
                            <a href="/nap-the" class="btn btn-primary-warning">Nâng cấp lên VIP</a>
                    
                            </div>
<?php else: ?>
     <form id="comment-form" method="post" action="<?php echo e(route('comments.store')); ?>" >
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>" >
                        <div class="row";">
                            <div class="form-group">
                                <textarea class="form-control" name="comment" placeholder="Viết bình luận!"></textarea>
                            </div>
                        </div>
                        <div class="row" ;">
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary btn-lg" style="width:100%" name="submit">
                            </div>
                        </div>
                    </form>
<?php endif; ?> 



                </div>
            </div>
        </div>
    </div>


    <div class="row">
         <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
               

                <div class="panel-body comment-container" >
                    
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="well">
                            <i><b><img src="soicau/images/chat.png"> <?php echo e($comment->name); ?> </b></i>&nbsp;&nbsp;
                            
                            <span> <?php echo e($comment->created_at); ?> </span>
                            <br>
                            <span> <big> <?php echo e($comment->comment); ?> </big></span>
                            <div >
                                <br>

                                <?php if(Auth::user()->vip==0): ?>  
                                <?php else: ?>
                                <a style="cursor: pointer;" cid="<?php echo e($comment->id); ?>" name_a="<?php echo e(Auth::user()->name); ?>" token="<?php echo e(csrf_token()); ?>" class="reply">Trả lời</a>&nbsp;
                                <?php endif; ?>
                                
                                <a style="cursor: pointer;"  class="delete-comment" token="<?php echo e(csrf_token()); ?>" comment-did="<?php echo e($comment->id); ?>" >Xóa</a>
                                <div class="reply-form">
                                    

                                    <!-- Dynamic Reply form -->
                                    
                                </div>
                                <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($comment->id === $rep->comment_id): ?>
                                        <div class="well">
                                            <i><b> <?php echo e($rep->name); ?> </b></i>&nbsp;&nbsp;
                                             <span> <?php echo e($rep->created_at); ?> </span>
                                                 <br>
                                            <span><big> <?php echo e($rep->reply); ?></big> </span>
                                            <div>
                                                <a rname="<?php echo e(Auth::user()->name); ?>" rid="<?php echo e($comment->id); ?>" style="cursor: pointer;" class="reply-to-reply" token="<?php echo e(csrf_token()); ?>"></a>
                                            </div>
                                            <div class="reply-to-reply-form">
                                            </div>
                                        </div>
                                    <?php endif; ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php else: ?>
<div  class="post notice">
            <div class="row chat-form">
                <div class="col-xs-2 col-md-1">
                    <img src="soicau/images/chat.png" alt="chat">
                </div>
                                    <div class="col-xs-10 col-md-11">
                        Mời thành viên ra số và chém gió (Bạn chưa <a href="/login">đăng nhập</a>)
                    </div>
                            <div class="col-xs-10 col-md-11">
                        Vui lòng <a href="/login">đăng nhập</a> để xem bình luận
                    </div>
                            </div>
            <div class="row">
                <ul class="date">
                                                                <li><a href="?date=2018-11-01"><img src="/images/truoc.png" alt="">Ngày trước</a></li>
                                                        </ul>
            </div>
            <input type="hidden"  id="cat_id" value="13">
            <input type="hidden" id="date" value="">
            <input type="hidden" id="_token" value="ttcNpx0fXEsIIQiuRATTjS0AAb7mGxAGUZvksdeA">
            <div id="pos">
            </div>
            <div id="div_chem">

            </div>
        </div>
        <div class="row">
            <div class="col-xs-12" id="div_paginate">

            </div>
        </div>

    </section>
               

        <?php endif; ?>     
           

   

<section>
    <h4 style="text-transform: uppercase;padding: 0 15px;margin:0px;height: 33px;line-height: 33px;background: #cc6600;color: #fff;font-weight: bold;;text-align: center;">
        TOP 10 CAO THỦ LOTO</h4>
    <div class="list-top-loto">
        <table class="table table-responsive table_loto">
            <tbody>
                <tr>
                    <th style="text-align: center">Xếp hạng</th>
                    <th style="">
                        <div class="col-xs-4 col-md-4"></div>
                        <div class="col-xs-8 col-md-8" style="padding-left: 0px;">Nickname</div>
                    </th>
                    <th style="text-align: center">Số điểm </th>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 1</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/anhhoang2016">
                                    <img class="img-circle avt_chat" src="soicau/upload/thumbs/200/200/files/2018/03/xam-moi-dep-tu-nhienjpg1519885912.jpg" alt="anhhoang2016"
                                        data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/anhhoang2016">
                                    <h4 style="padding: 0px;margin: 2px;">anhhoang2016</h4>
                                </a>
                                <i class="time">19/12/2016</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top1">18</span>
                    </td>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 2</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/medehp">
                                    <img class="img-circle avt_chat" src="soicau/upload/thumbs/200/200/files/2017/02/16300199-163492397475970-8403667558017750859-ojpg1486640663.jpg"
                                        alt="medehp" data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/medehp">
                                    <h4 style="padding: 0px;margin: 2px;">medehp</h4>
                                </a>
                                <i class="time">12/11/2016</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top2">16</span>
                    </td>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 3</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/admin-1">
                                    <img class="img-circle avt_chat" src="soicau/upload/thumbs/200/200/files/2018/02/cd6fd0c7-9860-402b-95a3-81e81c9c3917jpeg1519706835.jpeg"
                                        alt="admin" data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/admin-1">
                                    <h4 style="padding: 0px;margin: 2px;">admin</h4>
                                </a>
                                <i class="time">25/10/2016</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top3">15</span>
                    </td>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 4</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/niemtin3999">
                                    <img class="img-circle avt_chat" src="soicau/upload/thumbs/200/200/files/2017/10/img-2732jpg1507185884.jpg" alt="niemtin3999"
                                        data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/niemtin3999">
                                    <h4 style="padding: 0px;margin: 2px;">niemtin3999</h4>
                                </a>
                                <i class="time">05/10/2017</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top4">14</span>
                    </td>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 5</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/kiemtien-antet">
                                    <img class="img-circle avt_chat" src="soicau/upload/thumbs/200/200/files/2018/02/chrysanthemumjpg1519480547.jpg" alt="kiemtien_antet"
                                        data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/kiemtien-antet">
                                    <h4 style="padding: 0px;margin: 2px;">kiemtien_antet</h4>
                                </a>
                                <i class="time">22/01/2018</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top5">14</span>
                    </td>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 6</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/hieurua">
                                    <img class="img-circle avt_chat" src="soicau/images/avt/soi-cau-366.png" alt="hieurua" data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/hieurua">
                                    <h4 style="padding: 0px;margin: 2px;">hieurua</h4>
                                </a>
                                <i class="time">14/08/2017</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top6">14</span>
                    </td>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 7</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/hung85">
                                    <img class="img-circle avt_chat" src="soicau/upload/thumbs/200/200/files/2018/02/20180211-173014png1518345070.png" alt="hung85"
                                        data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/hung85">
                                    <h4 style="padding: 0px;margin: 2px;">hung85</h4>
                                </a>
                                <i class="time">13/02/2017</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top7">13</span>
                    </td>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 8</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/phuonglan1995">
                                    <img class="img-circle avt_chat" src="soicau/upload/thumbs/200/200/files/2017/12/15675696-941854139281590-7469487377304005681-ojpg1513388841.jpg"
                                        alt="phuonglan1995" data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/phuonglan1995">
                                    <h4 style="padding: 0px;margin: 2px;">phuonglan1995</h4>
                                </a>
                                <i class="time">02/08/2017</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top8">13</span>
                    </td>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 9</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/vualode87">
                                    <img class="img-circle avt_chat" src="soicau/images/avt/soi-cau-366.png" alt="vualode87" data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/vualode87">
                                    <h4 style="padding: 0px;margin: 2px;">vualode87</h4>
                                </a>
                                <i class="time">12/11/2017</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top9">12</span>
                    </td>
                </tr>
                <tr>
                    <td style="cursor: pointer;text-align: center;"> 10</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/chetlode">
                                    <img class="img-circle avt_chat" src="soicau/images/avt/soi-cau-366.png" alt="chetlode" data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/chetlode">
                                    <h4 style="padding: 0px;margin: 2px;">chetlode</h4>
                                </a>
                                <i class="time">05/12/2017</i>
                            </div>
                        </div>
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top10">12</span>
                    </td>
                </tr>
            </tbody>
        </table>

    </div> 
</section>
<div id="adv" class="row">
    <div class="col-xs-12">
        <div class="row">
            <div id="hide_float_right_zone1" class="hideQCAlign">
                <a href="javascript:HOME.hide_float_right_zone1()">Tắt quảng cáo [X]</a>
            </div>
            <div id="float_content_right_zone1" class="QCAlign" style="display: block;">

                <div class="zone">

                    <a href="http://congtysoicau365.com" rel="nofollow" target="_blank">
                        <img alt="" src="soicau/upload/files/2018/02/congtysoicau365-comgif1519112174.gif" class="img-responsive center-block">
                    </a>
                </div>
                <div class="zone">

                    <a href="http://xosophattaiphatloc.com" rel="nofollow" target="_blank">
                        <img alt="" src="soicau/upload/files/2018/02/xosophattaiphatloc-comgif1519112220.gif" class="img-responsive center-block">
                    </a>
                </div>
                <div class="zone">

                    <a href="http://sodephomnay88.net" rel="nofollow" target="_blank">
                        <img alt="" src="soicau/upload/files/2018/03/sodephomnay88-netgif1520618723.gif" class="img-responsive center-block">
                    </a>
                </div>


            </div>
        </div>
    </div>
</div>

<?php 
    $date = date("d-m-Y");
    $plus = 1;
    $date = date("d-m-Y",strtotime("$date -$plus day"));
    ?>

<section id="ket-qua">

   <?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("https://soicau366.com/mien-nam/hau-giang");
        $tinhdiv = $html->find("section#ket-qua",0);
        echo $tinhdiv; 
         ?>
</section>




<section id="bai-viet">
    <h3 class="header">Kinh nghiệm soi cầu xổ số</h3>
    <ul id="ul_baiviet">
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/tham-gia-nhom-ho-tro-thanh-vien-soicau366"> THAM GIA NHÓM HỖ TRỢ THÀNH VIÊN SOICAU366</a>
        </li>
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/soi-cau-rong-bach-kim-xac-suat-an-lo-la-bao-nhieu"> Soi cầu rồng bạch kim xác suất ăn lô là bao nhiêu %</a>
        </li>
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/kinh-nghiem-khi-danh-lo-de-hay-nhat"> Kinh nghiệm khi đánh lô đề hay nhất</a>
        </li>
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/danh-de-online"> Đánh đề online là gì - Có an toàn khi chơi lô đề online</a>
        </li>
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/bi-quyet-danh-lo-de-theo-giac-mo"> Bí quyết đánh lô đề theo giấc mơ</a>
        </li>
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/nguyen-tac-cho-nguoi-moi-choi-xo-so-nen-biet"> Nguyên tắc cho người mới chơi xổ số nên biết</a>
        </li>
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/soi-cau-lo-to-chuan-xac"> Soi cầu lô tô chuẩn xác</a>
        </li>
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/dinh-nghia-lo-khan-va-cach-choi-lo-khan"> Định nghĩa soi cầu lô khan với cách chơi hiệu quả nhất</a>
        </li>
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/phuong-phap-choi-lo-roi"> Kinh nghiệm chơi lô rơi từ soi cau 366</a>
        </li>
        <li>
            <img src="soicau/images/icon_new.png" />
            <a href="/news/lo-to-cap-3-ngay-la-gi-cach-choi-nhu-the-nao"> Lô tô cặp 3 ngày là gì? Cách chơi như thế nào?</a>
        </li>
    </ul>
    <p class="more">
        <a title="Xem thêm" href="/news">>> Xem thêm </a>
    </p>
</section>
<div id="zone_footer" class="zone" style="position: fixed;bottom: 0px; max-width: 720px; text-align: center; width:100%">


    <div id="hide_float_right">
        <a href="javascript:HOME.hide_float_right()">Tắt [X]</a>
    </div>
    <div id="float_content_right">
        <a href="http://caudep.me" rel="nofollow" target="_blank">
            <img alt="" src="soicau/upload/files/2018/02/caudep-megif1519549612.gif" class="img-responsive center-block">
        </a>
    </div>

</div>
<!-- Bootstrap JavaScript -->
<script src="js/jquery-1.12.3.min.js" ></script>
<script src="bootstrap3/js/bootstrap.min.js"></script>
<script src="js/nprogress.js"></script>
<script src="frontend/js/home5.js"></script>
<script src="js/chat4.js"></script>
<script src="js/user.js"></script>

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-75158570-1', 'auto');
    ga('send', 'pageview');

</script>
<!-- Facebook Pixel Code -->
<script>
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '180697755797837'); // Insert your pixel ID here.
    fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
               src="https://www.facebook.com/tr?id=180697755797837&ev=PageView&noscript=1"
    /></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->

    <script src="js/admin/alerts.js" ></script>
    <script>
        jQuery(document).ready(function(){
            if (HOME.getCookie("hide_popup_right_zone1") == "1") {
                var contentright = document.getElementById('float_content_right_zone1');
                var hideright = document.getElementById('hide_float_right_zone1');
                if (contentright.style.display != "none") {
                    contentright.style.display = "none";
                    hideright.innerHTML = '<a href="javascript:HOME.hide_float_right_zone1()">Xem quảng cáo...</a>';
                }
            };
       
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>