 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Quản lý giao dịch
            <small><?php echo e($type); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li>
                <a href="#">
                    <i class="fa fa-dashboard"></i> Home</a>
            </li>
            <li>
                <a href="#">Tables</a>
            </li>
            <li class="active">Data tables</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <?php if(Session::has('thanhcong')): ?>
        <div class="alert alert-success">
            <?php echo e(session('thanhcong')); ?>

        </div>
        <?php endif; ?> <?php if(Session::has('edit')): ?>
        <div class="alert alert-success">
            <?php echo e(session('edit')); ?>

        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Gia hạn</h3>
                        <button type="button" class="btn btn-success btn-info btn-xs">
                            <a href="giahan/create" style="color:inherit;">Tạo hạn dùng</a>
                        </button>
                        <button type="button" class="btn btn-success btn-info btn-xs">
                            <a href="giahan?trangthai=0" style="color:inherit;">Đã hết hạn hôm nay</a>
                        </button>
                        <button type="button" class="btn btn-success btn-info btn-xs">
                            <a href="giahan" style="color:inherit;">Tất cả</a>
                        </button>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>ID user</th>
                                    <td>Ngày tạo</td>
                                    <td>Tên</td>
                                    <td>Ngày hết hạn</td>
                                    <th>Trạng thái</th>
                                    <th>Xoá Vip</th>
                                    <th>Edit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $giaodich; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($gd->id); ?></td>
                                    <td><?php echo e($gd->iduser); ?></td>
                                    <td><?php echo e($gd->created_at); ?></td>
                                    <td><?php echo e($gd->user->name); ?></td>
                                    <td><?php echo e($gd->hethan); ?></td>
                                    <td><?php echo e($gd->trangthai); ?></td>
                                    
                                    <td>
                                        <?php if($gd->trangthai == "Đang chờ"): ?>
                                        <form action="<?php echo e(route('giahan.update',[$gd->id])); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="_method" value="put" />
                                            <button type="submit" class="btn btn-success btn-xs">Cập nhật</button>
                                            <input type="hidden" name ="capnhat" value="1"/>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="giahan/<?php echo e($gd->id); ?>/edit">Edit</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="row" style="margin-left:3px;">
                            <?php echo e($giaodich->links()); ?>

                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <div class="deleteContent">
                    Are you Sure you want to delete
                    <span class="dname"></span> ?
                    <span class="hidden did"></span>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn actionBtn" data-dismiss="modal">
                    <span id="footer_action_button" class='glyphicon'> </span>
                </button>
                <button type="button" class="btn btn-warning" data-dismiss="modal">
                    <span class='glyphicon glyphicon-remove'></span> Close
                </button>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/app1.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>