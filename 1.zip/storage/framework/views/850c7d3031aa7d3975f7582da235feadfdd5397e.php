 <?php $__env->startSection('content'); ?>
<?php 
    $plus = 1;
    $homnay = date("Y-m-d");
?>

<section id="ket-qua">

    <h3 class="header">Kết quả xổ số Miền bắc ngày <?php echo e($date = date("d-m-Y",strtotime($date))); ?></h3>
    <div class="row">
        <div class="col-xs-12">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr class="info">
                        <th class="col-xs-1"> ĐB </th>
                        <th class="red">
                        <?php echo $rmb['rs_0_0']; ?> </th>
                    </tr>
                    <tr>
                        <th> G1 </th>
                        <th>
                        <?php echo $rmb['rs_1_0']; ?> </th>
                    </tr>
                    <tr>
                        <th> G2 </th>
                        <th>
                        <?php echo $rmb['rs_2_0']; ?> - <?php echo $rmb['rs_2_1']; ?> </th>
                    </tr>
                    <tr>
                        <th> G3 </th>
                        <th>
                        <?php echo $rmb['rs_3_0']; ?> - <?php echo $rmb['rs_3_1']; ?> - <?php echo $rmb['rs_3_2']; ?> - <?php echo $rmb['rs_3_3']; ?> - <?php echo $rmb['rs_3_4']; ?> - <?php echo $rmb['rs_3_5']; ?> </th>
                    </tr>
                    <tr>
                        <th> G4 </th>
                        <th>
                        <?php echo $rmb['rs_4_0']; ?> - <?php echo $rmb['rs_4_1']; ?> - <?php echo $rmb['rs_4_2']; ?> - <?php echo $rmb['rs_4_3']; ?> </th>
                    </tr>
                    <tr>
                        <th> G5 </th>
                        <th>
                        <?php echo $rmb['rs_5_0']; ?> - <?php echo $rmb['rs_5_1']; ?> - <?php echo $rmb['rs_5_2']; ?> - <?php echo $rmb['rs_5_3']; ?> - <?php echo $rmb['rs_5_4']; ?> - <?php echo $rmb['rs_5_5']; ?> </th>
                    </tr>
                    <tr>
                        <th> G6 </th>
                        <th>
                        <?php echo $rmb['rs_6_0']; ?> - <?php echo $rmb['rs_6_1']; ?> - <?php echo $rmb['rs_6_2']; ?> </th>
                    </tr>
                    <tr>
                        <th> G7 </th>
                        <th>
                        <?php echo $rmb['rs_7_0']; ?> - <?php echo $rmb['rs_7_1']; ?> - <?php echo $rmb['rs_7_2']; ?> - <?php echo $rmb['rs_7_3']; ?> </th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-6">
            <table class="table table-bordered table-striped">
                <tr class="info">
                    <th class="col-xs-1">Đầu</th>
                    <th>Lô Tô</th>
                </tr>
                 <?php for($k=0;$k<10;$k++): ?>
                            <tr>
                                <td>
                                    <b class="clnote"><?php echo e($k); ?></b>
                                </td>
                                <td><?php 
                                $j=0;
                                for($i=0;$i<count($kqmb);$i++){
                                    if(substr($kqmb[$i],0,1)==(string)$k){
                                        if($j==0){
                                            echo substr($kqmb[$i],-1);
                                            $j=1;
                                        }else echo ', '.substr($kqmb[$i],-1);
                                    }
                                }
                                ?></td>
                            </tr>
                            <?php endfor; ?>
            </table>
        </div>
          <div class="row">
        <div class="col-xs-12 col-sm-6">
            <table class="table table-bordered table-striped">
                <tr class="info">
                    <th class="col-xs-1">Đít</th>
                    <th>Lô Tô</th>
                </tr>
                <?php for($k=0;$k<10;$k++): ?>
                            <tr>
                                <td><b class="clnote"><?php echo e($k); ?></b>
                                <td>
                                    <?php $j=0; for($i=0;$i<count($kqmb);$i++){ if(substr($kqmb[$i],-1)==(string)$k){if($j==0){echo substr($kqmb[$i],0,1);$j=1;}else echo ', '.substr($kqmb[$i],0,1);}}?></td>
                                </td>
                            </tr>
                            <?php endfor; ?>
            </table>
        </div>
    </div>
    </div>

 <div class="row">
                    <div class="row left_loto">
    <ul><li><a href="ket-qua/mien-bac/<?php echo date("Y-m-d",strtotime("$date -$plus day")); ?>"><img src="images/truoc.png" alt="Ngày sau">Ngày trước</a></li></ul>

                    </div>
                    <div class="row right_loto">
                         <?php if($homnay === $date): ?>
    <?php else: ?>
     <li><a href="ket-qua/mien-bac/<?php echo date("Y-m-d",strtotime("$date +$plus day")); ?>">Ngày sau</a></li>
    <?php endif; ?>
                    </div>
                </div>
    <div class="row xem-them">
        <div class="col-xs-12">
            &gt;&gt; Xem thêm KQXS:

            <ul>
                <li>
                    <a class="current" href="/ket-qua/mien-bac">Miền bắc</a>
                </li>
                <li>
                    <a class="" href="/ket-qua/mien-trung">Miền trung</a>
                </li>
                <li>
                    <a class="" href="/ket-qua/mien-nam">Miền nam</a>
                </li>
            </ul>
        </div>
    </div>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>