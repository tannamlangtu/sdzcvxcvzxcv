<?php
use App\User;
$users = user::latest('created_at')->paginate(1);
    ?>
    <h4 style="text-transform: uppercase;padding: 0 15px;margin:0px;height: 33px;line-height: 33px;background: #cc6600;color: #fff;font-weight: bold;;text-align: center;">
        NỘI QUY THAM GIA CỘNG ĐỒNG GOSOICAU.COM</h4>
<div class="content" style="padding:0 15px">
<p><em>Trở thành thành viên của cộng đồng gosoicau.com các bạn phải tuân thủ các nguyên tắc sau đây:<br>
– Không tạo lập nhiều tài khoản<br>
– Không spam nội dung.<br>
– Không bán số, không để lại số điện thoại, không mời chào website khác.<br>
– Không chửi bới, lăng mạ thành viên khác. Nếu không hài lòng hoặc các thành viên có hành động vô văn hóa, các bạn hãy phản ánh tới Admin.<br>
<strong>Admin</strong> có quyền xóa tài khoản của bạn bất cứ lúc nào nếu các bạn vi phạm các nguyên tắc sinh hoạt trên.<br>
Chúc các bạn tham gia cộng đồng vui vẻ, chiến thắng!</em></p>
</div>
<h4 style="text-transform: uppercase;padding: 0 15px;margin:0px;height: 33px;line-height: 33px;background: #cc6600;color: #fff;font-weight: bold;;text-align: center;">
        ĐIỀU KIỆN THỎA THUẬN</h4>


<div class="content" style="padding:0 15px">
<p><strong style="color:#FF0000">1.</strong> Không khuyến khích ép buộc chèo kéo tham gia sử dụng dịch vụ trên website tất cả đều là tự nguyện.</p>
<p><strong style="color:#FF0000">2.</strong> Không chịu bất cứ một trách nhiệm về tổn thất thiệt hại vật chất hay tinh thần nào về việc sử dụng các thông tin trên web.</p>
<p><strong style="color:#FF0000">3.</strong> Không chịu bất cứ trách nhiệm nào trước pháp luật với những thông tin đưa ra vì đây chỉ là tham khảo cho người dùng tùy ý lựa chọn.</p>
<p><strong style="color:#FF0000">4.</strong> Hãy cân nhắc kỹ trước khi bấm vào các đường text link , text link quảng cáo của chúng tôi và sử dụng dịch vụ của các text link dẫn đến trang website đó.</p>
<p><strong style="color:#FF0000">5.</strong> Không soi lô đề bán số lô đề , cá cược và cá độ lô đề trái phép , không cung cấp số chơi lô đề</p>
<p><strong style="color:#FF0000">6.</strong>Website nghiêm cấm truy cập đối với đối tượng vị thành niên.</p>
<p><strong style="color:#FF0000">7.</strong>Chúng tôi không chịu trách nhiệm về việc sử dụng thông tin vào mục đích cá nhân của bạn.</p>
</div>
<footer>
    <div class="row copyright">
        <div class="col-xs-6">
            ©Go Soi Cầu
        </div>
        <div class="col-xs-4 col-xs-offset-2 col-md-2 col-md-offset-4">
            <script id="_wauh0r">
                var _wau = _wau || [];
                _wau.push(["small", "g0rr49o9p7", "h0r"]);
                (function () {
                    var s = document.createElement("script");
                    s.async = true;
                    s.src = "https://widgets.amung.us/small.js";
                    document.getElementsByTagName("head")[0].appendChild(s);
                })();
            </script>
            
        </div>
    </div>


    <p class="new-user">Chào mừng thành viên mới: <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php echo e($user->name); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </p>
    <p class="tags">
        Tag: Soi cau, soi lo de, soi cau lo de mien bac, soi cau mien bac, soi cau vip, dien dan soi cau, dien dan chem gio, soi
        cau mb, soi cau xs, soi cau lo de mien phi, soi cau lo de hang ngay, soi cau mien nam, soi cau mien trung, soi cau
        xo so, bach thu lo, xo so 888, gio vang chot so, chuyen gia xo so, bach thu lo kep, bach thu lo mb, rong bach kim,
        xsmb. </p>

    <ul class="socials">
        <li>
            <a href="https://www.facebook.com/Go-Soi-Cầu-1799477696831043" target="_blank">
                <img src="soicau/images/socials/fb.png" alt="facebook">
            </a>
        </li>
        <li>
            <a href="https://www.google.com.vn/" target="_blank">
                <img src="soicau/images/socials/gg.png" alt="google+">
            </a>
        </li>
        <li>
            <a href="https://twitter.com/" target="_blank">
                <img src="soicau/images/socials/tw.png" alt="twiter">
            </a>
        </li>
        <!-- <li>
            <a href="https://zalo.me/0522690050" target="_blank">
                <img src="soicau/images/socials/zalo.png" alt="zalo">
            </a>
        </li>
        
        <li>
            <a style="font-size: 14px;" >LH quảng cáo : 0522690050</a>
            <br/>
        </li> -->
    </ul>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-131231717-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-131231717-1');
</script>
</footer>