 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php $date = date("d-m-Y")  ?>
   
           
<?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("http://www.xoso.com/thong-ke-cap-so-tu-00-99.html");
        $soi = $html->find("table.tbl-tk",0);
        $soi1 = $html->find("div.box_so",1);
        $soi2 = $html->find("div.box_so",2);
        $soi3 = $html->find("div.box_so",3);
        $soi4 = $html->find("div.box_so",4);
        $soi5 = $html->find("div.box_so",5);
        $soi6 = $html->find("div.box_so",6);
        $soi7 = $html->find("div.box_so",7);
      
         ?>
<h1>Thống kê cặp số từ 00-99 Xổ số <a >Miền Bắc</a></h1>
         <div class="title-tk">Các số xuất hiện trong 30 lần quay Xổ số <a>Miền Bắc</a></div>
<?php echo $soi; ?>

<link rel="stylesheet" href="http://www.xoso.com/min/g=css1411" />
   <br>
</section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>