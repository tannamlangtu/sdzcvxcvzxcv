 <?php $__env->startSection('content'); ?>
<?php 
use App\somo;
$somo = somo::orderBy('name')->paginate(30,['*'],'somo');
$i=1;
?> 

<div class="row">
        <div class="col-lg-12">
            <div id="UserInfoBlock" class="board" style="text-align:center">
                <div id="Title">
                    <p class="text_dangky"> <a class="a_title_sm">SỔ MƠ</a> </p>
                </div>
            </div>
        </div>
    </div>
    <div class="row ">
        <div class="col-lg-12 div-t">

             
        </div>
        <div class="col-lg-12">
            <table class="table table-hover table-striped nowrap">
                <thead>
                <tr><th>STT</th>
                    <th>Tên giấc mơ</th>
                    <th>Bộ số tương ứng</th>
                </tr></thead>
                <tbody>
                    <?php $__currentLoopData = $somo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($x -> name); ?></td>
                    <td class="text-primary" style="font-size: 16px;"><?php echo e($x -> number); ?></td>
                </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                                                </tbody>
            </table>
        </div>
    </div>
 
<?php echo e($somo->links()); ?>

 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>