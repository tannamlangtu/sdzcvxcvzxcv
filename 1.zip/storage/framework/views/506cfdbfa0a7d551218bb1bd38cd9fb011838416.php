 <?php $__env->startSection('content'); ?>
 
    <?php if(Session::has('errors')): ?>
    <div class="alert alert-danger">
        <?php echo e(Session::get('errors')); ?>

    </div>
    <?php endif; ?>
     <?php if(Session::has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(Session::get('success')); ?> 
    </div>
    <?php endif; ?>

<?php
         include('simple_html_dom.php');
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $inputmb = array(
            'rs_0_0' => '<img class="a1" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_1_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_2_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_2_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_3_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_4_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_4' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_5_5' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_6_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_0' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_1' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_2' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />',
            'rs_7_3' => '<img class="a" src="ketquaxoso/Clock.gif" width="20" />'
        );
        $rmb = array();
        $day = date("d-m-Y");
        $ngay = array();
        $thu = array();
        $kqmb = array();
        $plus = 1;
        $homqua = date("d-m-Y",strtotime("$day -$plus day"));
        $ketquamb = array();
        for($u=0 ; $u<1; $u++){
            if( date( 'H' ) >= 19 ) {
                $ngay[] = date("d-m-Y",strtotime("$day -$u day"));
            }
            else {
                $ngay[] = date("d-m-Y",strtotime("$homqua -$u day"));
            }
            $html = file_get_html("http://vesophuongtrang.com/ket-qua-xo-so/".$ngay[$u].".html");
            $ketquamb[] = $html->find("table.kqxsmienbac div.dayso");
            if( count($ketquamb[$u]) != 0 ) {
                $i=0;
                foreach( $inputmb as $key => $value ){
                    $rmb[$u][$key] = $ketquamb[$u][$i]->innertext;
                    $i++;
                }
            }
            else {
                $rmb[$u] = $inputmb;
            }
            $thu[] = date('l', strtotime($ngay[$u]));
            if($thu[$u]=="Sunday") $thu[$u] = "Chủ nhật";
            if($thu[$u]=="Monday") $thu[$u] = "Thứ hai";
            if($thu[$u]=="Tuesday") $thu[$u] = "Thứ ba";
            if($thu[$u]=="Wednesday") $thu[$u] = "Thứ tư";
            if($thu[$u]=="Thursday") $thu[$u] = "Thứ năm";
            if($thu[$u]=="Friday") $thu[$u] = "Thứ sáu";
            if($thu[$u]=="Saturday") $thu[$u] = "Thứ bảy";
            foreach($rmb[$u] as $kq){
                $kqmb[$u][] = substr($kq,-2);
            }
        }
 ?>

<?php 
    $date = date("d-m-Y");
     $day = date('l');
    if($day=="Sunday") $thui = "Chủ nhật";
    if($day=="Monday") $thui = "Thứ hai";
    if($day=="Tuesday") $thui = "Thứ ba";
    if($day=="Wednesday") $thui = "Thứ tư";
    if($day=="Thursday") $thui = "Thứ năm";
    if($day=="Friday") $thui = "Thứ sáu";
    if($day=="Saturday") $thui = "Thứ bảy";
     $sothu = date('l');
    if($sothu=="Sunday") $sothu = "1";
    if($sothu=="Monday") $sothu = "2";
    if($sothu=="Tuesday") $sothu = "3";
    if($sothu=="Wednesday") $sothu = "4";
    if($sothu=="Thursday") $sothu = "5";
    if($sothu=="Friday") $sothu = "6";
    if($sothu=="Saturday") $sothu = "7";
    $plus = 1;
  
?>
<div id="div_bor_content">

    <ul class="list-tinh">
    </ul>
    <script>
        var time_block = -1520816706
    </script>

<?php echo $__env->make('page.banner1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="soi-cau">
        <div id="soi-cau">
            <h4>Soi cầu kết quả xổ số Miền bắc ngày <?php echo e($date); ?></h4>
            
<?php if(Auth::check()): ?>
             
        <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/soicau.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng 
                    <?php if(Auth::user()->vip==0) echo "<A HREF='nap-the'>Nâng cấp Vip</A>"; else echo"<A HREF='chot-so'>Click vào đây</A>";?></b>
                    </a> để xem admin chốt số </div>
            </div>
        </div>
<?php else: ?>
    
            <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/soicau.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng
                    <a href="/dang-ky">Đăng Ký</a> hoặc
                    <a href="/dang-nhap">Đăng nhập</a> để xem admin chốt số </div>
            </div>
        <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/daudit.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng
                    <a href="/dang-ky">Đăng Ký</a> hoặc
                    <a href="/dang-nhap">Đăng nhập</a> để xem admin chốt số </div>
            </div>
<?php endif; ?> 
    </div>
    </div>

 

    <?php echo $__env->make('page.banner2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section id="chot-so">
        <div class="header">Khu vực chốt số của quản trị viên</div>
<?php if(Auth::check()): ?>
    <p style="padding: 15px;padding-bottom: 0; font-size: 18px;font-weight: bold;">
         <?php if(Auth::user()->vip==0) echo "Bạn phải là <A HREF='nap-the'>thành viên Vip</A> mới xem các QTV chốt số</A>"; else echo"<A HREF='chot-so'>Click vào đây</A> để xem QTV chốt số</A>";?>
         <?php else: ?>
        <p style="padding: 15px;padding-bottom: 0;font-size: 18px;font-weight: bold;">Bạn vui lòng
                <a href="dang-ky">Đăng ký</a> hoặc <a href="dang-nhap">Đăng nhập</a> để xem quản trị viên chốt số
            </p>
    
<?php endif; ?>
    <?php echo $__env->make('page.lochoinhieu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section id="forum">
        <h3 class="header">Diễn đàn chém gió soi cầu dự đoán kết quả xổ số</h3>  
<?php echo $__env->make('page.comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('page.caothu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('page.banner3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php 
    $date = date("d-m-Y");
    $plus = 1;
    $date = date("d-m-Y",strtotime("$date -$plus day"));
    ?>
</section>
<section id="ket-qua">
<?php for($i=0;$i<count($rmb);$i++): ?>
    <h3 class="header">Kết quả xổ số Miền bắc ngày <?php echo e($ngay[$i]); ?></h3>
</br>
    <div class="row">
        <div class="col-xs-12">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr class="info">
                        <th class="col-xs-1"> ĐB </th>
                        <th class="red">
                        <?php echo $rmb[$i]['rs_0_0']; ?> </th>
                    </tr>
                    <tr>
                        <th> G1 </th>
                        <th>
                        <?php echo $rmb[$i]['rs_1_0']; ?> </th>
                    </tr>
                    <tr>
                        <th> G2 </th>
                        <th>
                        <?php echo $rmb[$i]['rs_2_0']; ?> - <?php echo $rmb[$i]['rs_2_1']; ?> </th>
                    </tr>
                    <tr>
                        <th> G3 </th>
                        <th>
                        <?php echo $rmb[$i]['rs_3_0']; ?> - <?php echo $rmb[$i]['rs_3_1']; ?> - <?php echo $rmb[$i]['rs_3_2']; ?> - <?php echo $rmb[$i]['rs_3_3']; ?> - <?php echo $rmb[$i]['rs_3_4']; ?> - <?php echo $rmb[$i]['rs_3_5']; ?> </th>
                    </tr>
                    <tr>
                        <th> G4 </th>
                        <th>
                        <?php echo $rmb[$i]['rs_4_0']; ?> - <?php echo $rmb[$i]['rs_4_1']; ?> - <?php echo $rmb[$i]['rs_4_2']; ?> - <?php echo $rmb[$i]['rs_4_3']; ?> </th>
                    </tr>
                    <tr>
                        <th> G5 </th>
                        <th>
                        <?php echo $rmb[$i]['rs_5_0']; ?> - <?php echo $rmb[$i]['rs_5_1']; ?> - <?php echo $rmb[$i]['rs_5_2']; ?> - <?php echo $rmb[$i]['rs_5_3']; ?> - <?php echo $rmb[$i]['rs_5_4']; ?> - <?php echo $rmb[$i]['rs_5_5']; ?> </th>
                    </tr>
                    <tr>
                        <th> G6 </th>
                        <th>
                        <?php echo $rmb[$i]['rs_6_0']; ?> - <?php echo $rmb[$i]['rs_6_1']; ?> - <?php echo $rmb[$i]['rs_6_2']; ?> </th>
                    </tr>
                    <tr>
                        <th> G7 </th>
                        <th>
                        <?php echo $rmb[$i]['rs_7_0']; ?> - <?php echo $rmb[$i]['rs_7_1']; ?> - <?php echo $rmb[$i]['rs_7_2']; ?> - <?php echo $rmb[$i]['rs_7_3']; ?> </th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-6">
            <table class="table table-bordered table-striped">
                <tr class="info">
                    <th class="col-xs-1">Đầu</th>
                    <th>Lô Tô</th>
                </tr>
                <?php for($k=0;$k<10;$k++): ?>
                            <tr>
                                <td>
                                    <b class="clnote"><?php echo e($k); ?></b>
                                </td>
                                <td><?php 
                                $j=0;
                                for($u=0;$u<count($kqmb[$i]);$u++){
                                    if(substr($kqmb[$i][$u],0,1)==(string)$k){
                                        if($j==0){
                                            echo substr($kqmb[$i][$u],-2);
                                            $j=1;
                                        }else echo ', '.substr($kqmb[$i][$u],-2);
                                    }
                                }
                                ?></td>
                            </tr>
                        <?php endfor; ?>
            </table>
        </div>
          <div class="row">
        <div class="col-xs-12 col-sm-6">
            <table class="table table-bordered table-striped">
                <tr class="info">
                    <th class="col-xs-1">Đít</th>
                    <th>Lô Tô</th>
                </tr>
               <?php for($k=0;$k<10;$k++): ?>
                            <tr>
                                <td>
                                    <b class="clnote"><?php echo e($k); ?></b>
                                </td>
                                <td><?php $j=0; for($u=0;$u<count($kqmb[$i]);$u++){ if(substr($kqmb[$i][$u],-1)==(string)$k){if($j==0){echo substr($kqmb[$i][$u],0,2);$j=1;}else echo ', '.substr($kqmb[$i][$u],0,2);}}?></td>
                                
                            </tr>
                        <?php endfor; ?>
            </table>
        </div>
    </div>

                           <?php endfor; ?>
                                       
                           
                          

                                    


                               
    <div class="row xem-them">
        <div class="col-xs-12">
            >> Xem thêm KQXS:
            <ul>
                <li>
                    <a href="/ket-qua/mien-bac">Miền bắc</a>
                </li>
                <li>
                    <a href="/ket-qua/mien-trung">Miền trung</a>
                </li>
                <li>
                    <a href="/ket-qua/mien-nam">Miền nam</a>
                </li>
            </ul>
        </div>
    </div>

<div id="zone_footer" class="zone" style="position: fixed;bottom: 0px; max-width: 720px; text-align: center; width:100%">


    <div id="hide_float_right">
        <a href="javascript:HOME.hide_float_right()">Tắt [X]</a>
    </div>
    <div id="float_content_right">
        <a href="/" rel="nofollow" target="_blank">
            
        </a>
    </div>

</div>
<!-- Bootstrap JavaScript -->




<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->


    
    <script>
        jQuery(document).ready(function(){
            if (HOME.getCookie("hide_popup_right_zone1") == "1") {
                var contentright = document.getElementById('float_content_right_zone1');
                var hideright = document.getElementById('hide_float_right_zone1');
                if (contentright.style.display != "none") {
                    contentright.style.display = "none";
                    hideright.innerHTML = '<a href="javascript:HOME.hide_float_right_zone1()">Xem quảng cáo...</a>';
                }
            };
       
        });
    </script>
                                   
                           
 
                              
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>