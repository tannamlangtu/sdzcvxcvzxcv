  <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<?php $plus=1;?>
<div class="list-tinh">
     <li><a class="" href="ket-qua/mien-nam/an-giang">An Giang</a></li>
     <li><a class="" href="ket-qua/mien-nam/bac-lieu">Bạc Liêu</a></li>
     <li><a class="" href="ket-qua/mien-nam/ben-tre">Bến Tre</a></li>
     <li><a class="" href="ket-qua/mien-nam/binh-duong">Bình Dương</a></li>
     <li><a class="" href="ket-qua/mien-nam/binh-phuoc">Bình Phước</a></li>
     <li><a class="" href="ket-qua/mien-nam/binh-thuan">Bình Thuận</a></li>
     <li><a class="" href="ket-qua/mien-nam/ca-mau">Cà Mau</a></li>
     <li><a class="" href="ket-qua/mien-nam/can-tho">Cần Thơ</a></li>
     <li><a class="" href="ket-qua/mien-nam/da-lat">Đà Lạt</a></li>
     <li><a class="" href="ket-qua/mien-nam/dong-nai">Đồng Nai</a></li>
     <li><a class="" href="ket-qua/mien-nam/dong-thap">Đồng Tháp</a></li>
     <li><a class="" href="ket-qua/mien-nam/hau-giang">Hậu Giang</a></li>
     <li><a class="" href="ket-qua/mien-nam/ho-chi-minh">Hồ Chí Minh</a></li>
     <li><a class="" href="ket-qua/mien-nam/kien-giang">Kiên Giang</a></li>
     <li><a class="" href="ket-qua/mien-nam/long-an">Long An</a></li>
     <li><a class="" href="ket-qua/mien-nam/soc-trang">Sóc Trăng</a></li>
     <li><a class="" href="ket-qua/mien-nam/tay-ninh">Tây Ninh</a></li>
     <li><a class="" href="ket-qua/mien-nam/tien-giang">Tiền Giang</a></li>
     <li><a class="" href="ket-qua/mien-nam/tra-vinh">Trà Vinh</a></li>
     <li><a class="" href="ket-qua/mien-nam/vinh-long">Vĩnh Long</a></li>
     <li><a class="" href="ket-qua/mien-nam/vung-tau">Vũng Tàu</a></li>
 </div>
<div class="content-wrapper">
    <section id="ket-qua" style="margin-bottom: 15px;clear: both;">
        
       
<div class="row">
        <div class="col-xs-12">
            <table class="table table-bordered table-striped">
               <tbody>
                 
        <h3 class="header">Kết quả xổ số miền nam ngày <?php echo e($ngay = date("d-m-Y",strtotime($ngay))); ?></h3>
        <tbody>
                        <tr class="gr-yellow">
                            <th class="first">Đài</th>
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th>
                                <a href="" >
                                    <b class="underline"><?php echo e($cty->name); ?></b>
                                </a>
                                <br />
                               
                            </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <tr class="g8">
                                <td>G8</td>
                                <?php for($i=0;$i
                                <count($city);$i++): ?> <td>
                                    <div><?php echo $rmn[$i]['rs_8_0']; ?></div>
                                    </td>
                                    <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G7</td>
                                <?php for($i=0;$i
                                <count($city);$i++): ?> <td>
                                    <div><?php echo $rmn[$i]['rs_7_0']; ?></div>
                                    </td>
                                    <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G6</td>
                                <?php for($i=0;$i
                                <count($city);$i++): ?> <td>
                                    <div><?php echo $rmn[$i]['rs_6_0']; ?></div>
                                    <div><?php echo $rmn[$i]['rs_6_1']; ?></div>
                                    <div><?php echo $rmn[$i]['rs_6_2']; ?></div>
                                    </td>
                                    <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G5</td>
                                <?php for($i=0;$i
                                <count($city);$i++): ?> <td>
                                    <div><?php echo $rmn[$i]['rs_5_0']; ?></div>
                                    </td>
                                    <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G4</td>
                                <?php for($i=0;$i
                                <count($city);$i++): ?> <td>
                                    <div><?php echo $rmn[$i]['rs_4_0']; ?></div>
                                    <div><?php echo $rmn[$i]['rs_4_1']; ?></div>
                                    <div><?php echo $rmn[$i]['rs_4_2']; ?></div>
                                    <div><?php echo $rmn[$i]['rs_4_3']; ?></div>
                                    <div><?php echo $rmn[$i]['rs_4_4']; ?></div>
                                    <div><?php echo $rmn[$i]['rs_4_5']; ?></div>
                                    <div><?php echo $rmn[$i]['rs_4_6']; ?></div>
                                    </td>
                                    <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G3</td>
                                <?php for($i=0;$i
                                <count($city);$i++): ?> <td>
                                    <div><?php echo $rmn[$i]['rs_3_0']; ?></div>
                                    <div><?php echo $rmn[$i]['rs_3_1']; ?></div>
                                    </td>
                                    <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G2</td>
                                <?php for($i=0;$i
                                <count($city);$i++): ?> <td>
                                    <div><?php echo $rmn[$i]['rs_2_0']; ?></div>
                                    </td>
                                    <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>G1</td>
                                <?php for($i=0;$i
                                <count($city);$i++): ?> <td>
                                    <div><?php echo $rmn[$i]['rs_1_0']; ?></div>
                                    </td>
                                    <?php endfor; ?>
                            </tr>
                            <tr class="gdb">
                                <td>ĐB</td>
                                <?php for($i=0;$i
                                <count($city);$i++): ?> <td>
                                    <div><?php echo $rmn[$i]['rs_0_0']; ?></div>
                                    </td>
                                    <?php endfor; ?>
                            </tr>
                    </tbody>
                    
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 ">
            <table class="table table-bordered table-striped">
            	
                <tbody>
                        <tr class="header">
                            <th width="10%" class="first">Đầu</th>
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($cty->name); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php for($k=0;$k<10;$k++): ?>
                        <tr>
                            <td>
                                <b class="clnote"><?php echo e($k); ?></b>
                            </td>
                            <?php for($i=0;$i<count($rmn);$i++): ?>
                            <td><?php $j=0; for($m=0;$m<count($kqmn[$i]);$m++){ if(substr($kqmn[$i][$m],0,1)==(string)$k){if($j==0){echo substr($kqmn[$i][$m],-2);$j=1;}else echo ', '.substr($kqmn[$i][$m],-2);}}?></td>
                            <?php endfor; ?>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
                </div>
            </table>
        </div>
    </div>
       <div class="row">
        <div class="col-xs-12 ">
            <table class="table table-bordered table-striped">
                <tbody>
                        <tr class="header">
                            <th width="10%" class="first">Đít</th>
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($cty->name); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php for($k=0;$k<10;$k++): ?>
                        <tr>
                            <td>
                                <b class="clnote"><?php echo e($k); ?></b>
                            </td>
                            <?php for($i=0;$i<count($rmn);$i++): ?>
                            <td><?php $j=0; for($m=0;$m<count($kqmn[$i]);$m++){ if(substr($kqmn[$i][$m],-1)==(string)$k){if($j==0){echo substr($kqmn[$i][$m],0,2);$j=1;}else echo ', '.substr($kqmn[$i][$m],0,2);}}?></td>
                            <?php endfor; ?>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
               
            </table>
        </div>
    </div>



 <div class="row">
                    <div class="row left_loto">
    <ul><li><a href="mien-nam/<?php echo date("Y-m-d",strtotime("$ngay -$plus day")); 
                ?>"><img src="images/truoc.png" alt="Ngày sau">Ngày trước</a></li></ul>

                    </div>
                    <div class="row right_loto">
                        
    
     <li><a href="mien-nam/<?php echo date("Y-m-d",strtotime("$ngay +$plus day")); 
                ?>">Ngày sau</a></li>
   
                    </div>
                </div>

 <div class="row xem-them">
            <div class="col-xs-12">
                &gt;&gt; Xem thêm KQXS:

                <ul>
                                        <li><a class="" href="/ket-qua/mien-bac">Miền bắc</a></li>
                                        <li><a class="" href="/ket-qua/mien-trung">Miền trung</a></li>
                                        <li><a class="current" href="/ket-qua/mien-nam">Miền nam</a></li>
                                    </ul>
            </div>

        
 
    <!-- /.content -->
</div>
</section>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>