 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php $date = date("d-m-Y")  ?>
   
           
  <?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("http://xsmb.vn/thong-ke-cap-so-lo-to.html");
        $kq1 = $html->find("div.Page_CAULOTO_KQ",0);
        $kq2 = $html->find("div.Centre_TKCKdanLOTO_bg",0);
         $kq3 = $html->find("div.THONGKE_title_small",0);
          $kq4 = $html->find("div.Centre_TKCKdanLOTO_bg",0);
         
         ?>
<div class="TK_title">
                                BẢNG THỐNG KÊ XỔ SỐ MIỀN BẮC
                            </div>
<?php echo $kq1; ?>

<input value="XEM THÊM" type="button" class="Form_button" onclick="loadKQ('#ketqua');" style="cursor: pointer" id="them">
<link rel="stylesheet" href="http://xsmb.vn/css/style.css" />
  

    <!-- /.content -->

<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>