<div id="adv" class="row">
    <div class="col-xs-12">
        <div class="row">
            <div id="hide_float_right_zone1" class="hideQCAlign">
                <a href="javascript:HOME.hide_float_right_zone1()">Tắt quảng cáo [X]</a>
            </div>
            <div id="float_content_right_zone1" class="QCAlign" style="display: block;">

                <div class="zone">

                    <a href="http://congtysoicau365.com" rel="nofollow" target="_blank">
                        <img alt="" src="soicau/upload/files/2018/02/congtysoicau365-comgif1519112174.gif" class="img-responsive center-block">
                    </a>
                </div>
                <div class="zone">

                    <a href="http://xosophattaiphatloc.com" rel="nofollow" target="_blank">
                        <img alt="" src="soicau/upload/files/2018/02/xosophattaiphatloc-comgif1519112220.gif" class="img-responsive center-block">
                    </a>
                </div>
                <div class="zone">

                    <a href="http://sodephomnay88.net" rel="nofollow" target="_blank">
                        <img alt="" src="soicau/upload/files/2018/03/sodephomnay88-netgif1520618723.gif" class="img-responsive center-block">
                    </a>
                </div>


            </div>
        </div>
    </div>
</div>