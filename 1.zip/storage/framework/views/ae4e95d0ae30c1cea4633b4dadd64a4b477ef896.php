 <?php $__env->startSection('content'); ?>

<div class="alert alert-warning alert-dismissible fade in" role="alert">
            <b>Để cấp lại mật khẩu vui lòng liên hệ</b><br>
            Admin qua hotline(Zalo) 0522690050<br>
            <i style="text-decoration: underline;">Lưu ý:</i><br>
            Chỉ dùng để phản ánh việc tài khoản của bạn có vấn đề, sự cố nạp thẻ, mọi vấn đề khác admin xin được từ
            chối trả lời.
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>