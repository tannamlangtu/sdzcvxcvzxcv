 <?php $__env->startSection('content'); ?>
<h3 class="section-title text-center">Đăng nhập thành công</h3>
<?php if(Auth::check()): ?>
          
<?php if(Auth::user()->vip==0): ?>  
      <div class="page-alerts" style="padding: 5px;text-align: center;"> <!-- TK VIP hết hạn -->
            <div class="alert alert-danger page-alert" id="alert-1" style="font-size: 14px;"><strong>Tài khoản đã hết hạn sử dụng!</strong> 
                    <br>Hãy nâng cấp lên tài khoản VIP để tham gia luận số cùng các thánh.
                    <br>Tham gia chốt số online nhận quà hấp dẫn cho thành viên có số điểm cao nhất trong tháng này.
                <div style="padding-top: 10px">

                    <a class="btn btn-warning" href="nap-the" role="button">NÂNG
                        CẤP LÊN VIP</a> <a class="btn btn-primary" href="/" role="button">TRANG
                        CHỦ</a></div>
            </div>
        </div>
     <?php endif; ?> 

     <div id="msg">
            <div class="alert alert-info alert-dismissible fade in" role="alert">
                <strong><h3 class="text-center" style="margin-top: -10px;text-decoration: underline;color: black;">Nội Quy: </h3> 
                	<p style="padding-left: 30px; text-align: left;">Trở thành thành viên của cộng đồng Gosoicau.Com các bạn phải tuân thủ các nguyên tắc sau đây:<br>
                		- Không tạo lập nhiều tài khoản.<br>- Không spam nội dung.<br>- Không bán số, không để lại số điện thoại, không mời chào website khác trên diễn đàn.<br>
                		- Sử dụng tên nick trong sạch, lành mạnh, đúng quy cách, đúng mục đích.<br>
                		- Không chửi bới, lăng mạ thành viên khác. Nếu không hài lòng hoặc các thành viên có hành động vô văn hóa, các bạn hãy phản ánh tới Admin.
                		<br>Admin có quyền xóa tk của bạn bất cứ lúc nào nếu các bạn vi phạm các nguyên tắc sinh hoạt trên.
                		<br>Chúc các bạn tham gia cộng đồng vui vẻ, chiến thắng!</p>
<p style="padding-left: 30px; text-align: justify;"><br>Trân trọng!</p></strong>
            </div>
            <div class="text-center" style="margin-bottom: 15px;">
            <a href="/" class="btn btn-danger">Trang Chủ</a>
            <a href="/" class="btn btn-warning">Tham gia chém gió</a>
        </div>
        </div>
<?php endif; ?>
     <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>