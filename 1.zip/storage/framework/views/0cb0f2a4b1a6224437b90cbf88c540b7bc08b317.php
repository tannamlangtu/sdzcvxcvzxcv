 <?php $__env->startSection('content'); ?>
<?php 
use App\User;
$users = user::latest('created_at')->paginate(1);
 ?>
<div class="middledite" style="margin-bottom: 30px;">
        <div id="UserInfoBlock" class="board" style="text-align:center">
            <div id="Title"><h3 class="text_dangky" style="color: red;"><b>TÌM KIẾM THÀNH VIÊN</b></h3></div>
        </div>
    
        <div class="row">
            <form action="tim-kiem-thanh-vien/timkiem" method="POST" role="search">
    <?php echo e(csrf_field()); ?>

    <div class="input-group">
        <input type="text" class="form-control" name="q"
            placeholder="Tìm bằng nick name"> <span class="input-group-btn">
            <button type="submit" class="btn btn-default">
                <span class="glyphicon glyphicon-search"></span>
            </button>
        </span>
    </div>
</form>
</div></div>
<?php $__env->stopSection(); ?>
                                  
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>