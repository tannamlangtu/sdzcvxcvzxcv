<div id="adv" class="row">
        <div class="col-xs-12">
            <div class="row">
                <div id="hide_float_right_zone2" class="hideQCAlign">
                    <a href="javascript:HOME.hide_float_right_zone2()">Tắt quảng cáo [X]</a>
                </div>
                <div id="float_content_right_zone2" class="QCAlign" style="display: block;">

                    <div class="zone">

                        <a href="http://soicaudinhcao.net" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/6-soicaudinhcao-netgif1519669297.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://xoso3mien24h.com" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/7-xoso3mien-24h-comgif1519669333.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://xosotailoc9999.com" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/8-xosotailoc9999-comgif1519669369.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://sochuan366.top" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/1-sochuan366-topgif1519668960.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://sochuanvaobo.me" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/2-sochuanvaobo-megif1519669033.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://caudepmienbac.mobi" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/caudepmienbac-m0bigif1519699054.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://sovangmayman.com" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/4-sovangmayman-comgif1519669218.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">

                        <a href="http://sovip.top" rel="nofollow" target="_blank">
                            <img alt="" src="soicau/upload/files/2018/02/5-sovip-topgif1519669255.gif" class="img-responsive center-block">
                        </a>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <div id="adv" class="row">
        <div class="col-xs-12">
            <div class="row">
                <div id="hide_float_right_zone4" class="hideQCAlign">
                    <a href="javascript:HOME.hide_float_right_zone4()">Tắt quảng cáo [X]</a>
                </div>
                <div id="float_content_right_zone4" class="QCAlign" style="display: block;">
                    <div class="list2 list2_chu"></div>
                    <div class="zone1">

                        <a href="http://soicaumb288.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 25px; margin-top: 0px;" src="soicau/upload/files/2017/03/moigif1490371428.gif" alt="mới"
                                />
                                <span style="font-size: 10pt;">&nbsp;
                                    <span style="color: #ff0000;">
                                        <strong>&nbsp;BAN Đ&Atilde; C&Oacute; SỐ ĐẸP CHO H&Ocirc;M NAY CHƯA NHỈ , H&Atilde;Y ĐẾN
                                            VỚi CH&Uacute;NG T&Ocirc;i ĐỂ NHẬN NHỮNG CON SỐ ĐẸP NHẤt TRONG NG&Agrave;Y
                                        </strong>
                                    </span>
                                </span>&nbsp;&nbsp;
                                <strong>
                                    <span style="color: #008000; font-size: 14pt;">
                                        <span style="color: #ff6600;">
                                            <span style="color: #0000ff; font-size: 10pt;">soicaumb288.com</span>&nbsp;
                                            <img style="max-width: 600px; height: 25px; margin-top: 0px;" src="soicau/upload/files/2017/03/moigif1490371428.gif" alt="mới"
                                            />
                                        </span>
                                    </span>
                                </strong>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://hoidongsovip68.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; margin-top: 0px; height: 20px;" src="soicau/upload/files/2017/03/newgif1490378591.gif" alt="new"
                                />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 10pt;">Ch&agrave;o ae nha , nếu lấy số đẹp h&atilde;y truy cập ngay wapsite của em nh&eacute;
                                        , số chuẩn , cầu đang th&ocirc;ng &nbsp;</span>
                                    <span style="color: #0000ff; font-size: 10pt;">
                                        <span style="color: #ff0000;">HOIDONGSOVIP68.COM</span>
                                    </span>
                                    <span style="color: #008000; font-size: 14pt;">&nbsp;</span>
                                    <img style="max-width: 600px; margin-top: 0px; height: 20px;" src="soicau/upload/files/2017/03/newgif1490378591.gif" alt="new22"
                                    />
                                </strong>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://soicauvang24h.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2016/12/vipgif1480788461.gif" alt="icon vip"
                                />&nbsp;
                                <span style="font-size: 10pt;">
                                    <strong>
                                        <span style="color: #0000ff;">&nbsp;CON SỐ MAY MẮN CỦA CH&Uacute;Ng T&Ocirc;I SẼ GI&Uacute;P C&Aacute;C BẠN V&Agrave;O
                                            BỜ , C&Ograve;N CHỜ G&Igrave; nỮA NHANH TAY TRUY CẬP NGAY&nbsp;
                                        </span>
                                    </strong>
                                </span>&nbsp;
                                <strong>
                                    <span style="color: #008000; font-size: 16pt;">
                                        <span style="color: #ff0000; font-size: 10pt;">soicauvang24h.com</span>&nbsp;&nbsp;
                                        <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2016/12/vipgif1480788461.gif" alt="icon vip"
                                        />
                                    </span>
                                </strong>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://soicau24h.info/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 22px; margin-top: 0px;" src="soicau/upload/files/2017/03/clickgif1490376092.gif" alt="click"
                                />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: 10pt;">
                                            <span style="color: #ff0000;">Lại một năm nữa bắt đầu , ch&uacute;ng t&ocirc;i những chuy&ecirc;n gia xổ số
                                                cao cấp sẽ m&atilde;i đồng h&agrave;nh c&ugrave;ng c&aacute;c bạn </span>
                                            <span style="color: #008000;">&nbsp;</span>
                                        </span>
                                    </span>
                                </strong>
                                <span style="font-size: 10pt; color: #0000ff;">
                                    <strong>SOICAU24H.INFO</strong>
                                </span>
                                <img style="max-width: 600px; height: 22px; margin-top: 0px;" src="soicau/upload/files/2017/03/click-2gif1490376594.gif"
                                    alt="click2" />
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://congtyxosophattaiphatloc6868.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; height: 15px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotqua-newgif1490369489.gif"
                                    alt="hotqua-new" />
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: 10pt;">Ch&uacute;ng t&ocirc;i gi&uacute;p h&agrave;ng trăm ae v&agrave;o bờ an to&agrave;n
                                            , thử rồi mới tin thật</span>&nbsp;</span>
                                </strong>
                                <span style="font-size: 14pt; color: #ff0000;">
                                    <span style="color: #000000;">
                                        <strong>
                                            <span style="color: #ff0000; font-size: 10pt;">CONGTYXOSOPHATTAIPHATLOC6868.COM</span>&nbsp;
                                            <img style="max-width: 600px; height: 15px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotqua-newgif1490369489.gif"
                                                alt="hot-qua-new" />
                                        </strong>
                                    </span>
                                </span>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://cauchuansodepmb289.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                                />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: 10pt;">Con số chuẩn tuyệt mật từ hđxs - soi cầu ch&iacute;nh x&aacute;c - soi la chuẩn -
                                            đ&aacute;nh l&agrave; ăn </span>
                                        <span style="font-size: large;">&nbsp;</span>
                                    </span>
                                </strong>
                                <span style="font-size: 10pt; color: #ff0000;">
                                    <strong>CAUCHUANSODEPMB289.COM&nbsp;</strong>
                                </span>
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                                />
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://sodep1368.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <span style="font-size: 10pt;">
                                    <img style="max-width: 600px; height: 25px;" src="soicau/upload/files/2017/10/moi-xanhlagif1508250117.gif" alt="iconmoi"
                                    />&nbsp;
                                    <span style="color: #ff0000;">
                                        <strong>Kh&ocirc;ng theo sẽ hối tiếc , h&atilde;y click để nhận số đẹp nhất h&ocirc;m nay
                                            tại</strong>
                                    </span>
                                </span>
                                <span style="color: #510080;">
                                    <span style="color: #008000;">&nbsp;</span>&nbsp;</span>
                                <strong>
                                    <span style="color: #008000; font-size: 14pt;">
                                        <span style="color: #ff6600;">
                                            <span style="color: #0000ff; font-size: 10pt;">SODEP1368.COM</span>&nbsp;
                                            <img style="max-width: 600px; height: 25px;" src="soicau/upload/files/2017/10/moi-xanhlagif1508250117.gif" alt="mới" />
                                        </span>
                                    </span>
                                </strong>
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://caudep366.mobi/" rel="nofollow" target="_blank">
                            <p style="line-height: 26px;">
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                                />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: small;">&nbsp;Lấy số từ hội đống xổ số , gỡ nợ mang tiền về mua xe duy nhất chỉ c&oacute;
                                            tại ==&gt;&gt;</span>
                                    </span>
                                </strong>
                                <span style="color: #ff0000; font-size: small;">
                                    <strong>CAUDEP366.MOBI</strong>
                                </span>
                                <img style="max-width: 600px; height: 16px; margin-top: 0px;" src="soicau/upload/files/2017/03/hotgif1490386493.gif" alt="hot"
                                />
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://soilode88.mobi/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/10/vip-timgif1508250358.gif" alt="vip" />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: 10pt;">
                                            <span style="color: #ff0000;">Số đẹp , phao lớn đưa ae xa bờ cập bến ae truye cập ngay để v&agrave;o bờ nha
                                                </span>&nbsp;</span>&nbsp;</span>
                                </strong>&nbsp;
                                <span style="color: #0000ff;">
                                    <span style="font-size: 13.3333px;">
                                        <strong>SOiLODE88.MOBI</strong>
                                    </span>
                                </span>&nbsp;
                                <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/10/vip-timgif1508250358.gif" alt="vip" />
                            </p>
                        </a>
                    </div>
                    <div class="zone1">

                        <a href="http://caudep689.net/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 22px; margin-top: 0px;" src="soicau/upload/files/2017/03/clickgif1490376092.gif" alt="click"
                                />&nbsp;
                                <span style="color: #ff0000;">
                                    <strong>
                                        <span style="font-size: 14pt;">
                                            <span style="font-size: 10pt;">Số chuẩn từ hđxs c&oacute; ngay tại đ&acirc;y , đầu năm tr&uacute;ng số , cả
                                                năm lộc về truy cập ngay&nbsp;</span>
                                        </span>
                                    </strong>&nbsp;</span>
                                <span style="font-size: 10pt; color: #0000ff;">
                                    <strong>CAUDEP689.NET</strong>
                                </span>&nbsp;
                                <img style="max-width: 600px; height: 22px; margin-top: 0px;" src="soicau/upload/files/2017/03/click-2gif1490376594.gif"
                                    alt="click2" />
                            </p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>