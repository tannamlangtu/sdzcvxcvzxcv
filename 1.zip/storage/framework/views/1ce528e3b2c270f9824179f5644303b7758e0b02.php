 <?php $__env->startSection('content'); ?>
<?php if(Session::has('giaodich')): ?>
    <div class="alert alert-<?php echo e(Session::get('flag')); ?>">
        <?php echo e(Session::get('giaodich')); ?>

    </div>
    <?php endif; ?>
<?php if(Auth::check()): ?>
<!-- check login -->
<?php if(Auth::user()->vip==0): ?>  
<!-- check nếu là user thường -->
<div class="error_alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
           <strong> <big>Thông báo!</big></strong><strong> Thành viên thường không được bình luận và gửi tin nhắn. Liên hệ Admin để nâng cấp vip</strong>
        </div>
        <?php else: ?>
         <?php endif; ?> 

         <div style="background-color: #fff; padding: 15px;">
            <div style="background-color: #fff; padding: 10px;">
                <span style="color: #ff0000;">
                    <h3 class="section-title text-center">Nâng Cấp Tài Khoản</h3>
                    <strong>Thành viên lưu ý.</strong>
                    <span style="color: #0000ff;">
                    <br><strong><!-- Nhắn tin nickname vào sdt hoặc Zalo 0522690050<br> -->Admin sẽ nâng cấp cho bạn nhanh nhất có thể!</strong>
                    <br><strong>
                            <span style="color: #ff0000;" style="font-size: 14pt;"><strong>Nếu cố tình vi phạm nội quy. Admin sẽ xóa tài khoản của bạn</strong></span>
                        </strong></div> 
                           </div>
<!-- <div style="background-color: #fff; padding: 15px;">
            <div style="background-color: #fff; padding: 10px;">
            	<span style="color: #ff0000;">
                    <h3 class="section-title text-center">Nâng Cấp Tài Khoản</h3>
            		<strong>Thành viên lưu ý.</strong>
                    <span style="color: #0000ff;">
                    <br><strong>Nạp 100k có ngay 30 ngày VÍP sử dụng<br>Admin sẽ nâng cấp cho bạn nhanh nhất có thể!</strong>
                    <br><strong>
                            <span style="color: #ff0000;" style="font-size: 14pt;"><strong>Nếu cố tình nhập sai nhiều lần. Admin sẽ xóa tài khoản của bạn</strong></span>
                        </strong></div> 
                           </div> -->
<div style="background-color: #fff; padding: 10px;">
<form action="<?php echo e(route('napthe')); ?>" id="frm-deposit-make" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                        
                        <div>
                            <table style="width: 100%;">
                                <tbody>
                                    <tr>
                                        <td style="width: 135px;">
                                            Loại Thẻ (
                                            <font color="red">
                                                <b>*</b>
                                            </font>)
                                        </td>
                                        <td>
                                            <select name="bank" id="from_overview_naptien_bank" class="form-control">

                                                <option value="Viettel">Viettel</option>
                                                <option value="Mobifone">Mobifone</option>
                                                <option value="Vinafone">Vinafone</option>
                                                <option value="Gate">Gate</option>
                                                
                                            </select> 
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Mã Thẻ (
                                            <font color="red">
                                                <b>*</b>
                                            </font>)
                                        </td>
                                        <td>
                                            <input  name="mathe" type="number" class="form-control" required ng-model="number" onKeyPress="if(this.value.length==20) return false;">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Seri (
                                            <font color="red">
                                                <b>*</b>
                                            </font>)
                                        </td>
                                        <td>
                                            <input type="number" name="seri" class="form-control" required ng-model="number" onKeyPress="if(this.value.length==20) return false;">
                                        </td>
                                    </tr>
                                     <td style="width: 135px;">
                                            Mệnh Giá (
                                            <font color="red">
                                                <b>*</b>
                                            </font>)
                                        </td>
                                   <td>
                                            <select name="menhgia"  class="form-control">

                                                <option value="50k">50.000</option>
                                                <option value="100k">100.000</option>
                                                <option value="200k">200.000</option>
                                                <option value="500k">500.000</option>
                                                <option value="1M">1.000.000</option>
                                            </select> 
                                        </td>
                                    <tr>
                                        <td>
                                        </td>
                                        <td>
                                            <input class="btn btn-signin" id="btn-form-submit-deposite" type="submit" value="Nạp tiền" />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </div>
<div class="alert alert-warning alert-dismissible fade in" role="alert">
            <b>Mọi thắc mắc hay có sự cố, liên hệ</b><br>
            Admin qua hotline 0522690050<br>
            <i style="text-decoration: underline;">Lưu ý:</i><br>
            Chỉ dùng để phản ánh việc tài khoản của bạn có vấn đề, sự cố nạp thẻ, mọi vấn đề khác admin xin được từ
            chối trả lời.
        </div>
      
        
        

         <!-- lịch sử -->
         <style type="text/css">
             .gd td {
    width: 100%;
}
.lich-su-danh td {
    border: 1px solid #ccc;
    padding: 7px;
    width: 87px;
}
.lich-su-danh table tr:first-child td {
    background-color: #ededed;
    color: #000;
}

         </style>
         <div style="background-color: #fff; padding: 10px;">
          <div class="lich-su-danh gd">
            <div class="bhead">
                <div class="fl">
                    Lịch sử giao dịch</div>
            </div>
            <div class="bcontent" id="ls-danh-tran">
                <table id="tblshower_transaction">
                    <tbody id="table_cashhistory">
                        <tr class="info">
                            <td>Ngày tạo</td>
                            <td>Loại Thẻ</td>
                            <td>Mã Thẻ</td>
                            <td>Seri</td>
                            <td>Mệnh Giá</td>
                            <td>Trạng thái</td>
                        </tr>
                        <?php $__currentLoopData = $napthe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($gd->created_at); ?></td>
                            <td><?php echo e($gd->idthe); ?></td>
                            <td><?php echo e($gd->mathe); ?></td>
                            <td><?php echo e($gd->seri); ?></td>
                            <td><?php echo e($gd->menhgia); ?></td>
                            <td><?php echo e($gd->trangthai); ?></td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="row">
                    <?php echo e($napthe->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <div class="text-center" style="margin-bottom: 15px;">
        <a href="/" class="btn btn-danger">Trang Chủ</a>
        <a href="/" class="btn btn-warning">Tham gia chém gió</a>
    </div>
<?php else: ?>
    <div class="alert alert-danger">
       Thông báo! Bạn chưa đăng nhập
    </div>
<?php endif; ?>

<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>