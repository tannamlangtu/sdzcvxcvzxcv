 <?php $__env->startSection('content'); ?>
<?php echo $__env->make('script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    $(document).on('click','.pagination a', function(e){
           e.preventDefault();
           var page = $(this).attr('href').split('page=')[1];
           getPosts(page);
       });
 
       function getPosts(page)
       {
           $.ajax({
               type: "GET",
               url: '?page='+ page
           })
           .success(function(data) {
               $('body').html(data);
           });
       }
</script>


<?php 
    $date = date("d-m-Y");
     $day = date('l');
    if($day=="Sunday") $thui = "Chủ nhật";
    if($day=="Monday") $thui = "Thứ hai";
    if($day=="Tuesday") $thui = "Thứ ba";
    if($day=="Wednesday") $thui = "Thứ tư";
    if($day=="Thursday") $thui = "Thứ năm";
    if($day=="Friday") $thui = "Thứ sáu";
    if($day=="Saturday") $thui = "Thứ bảy";
     $sothu = date('l');
    if($sothu=="Sunday") $sothu = "1";
    if($sothu=="Monday") $sothu = "2";
    if($sothu=="Tuesday") $sothu = "3";
    if($sothu=="Wednesday") $sothu = "4";
    if($sothu=="Thursday") $sothu = "5";
    if($sothu=="Friday") $sothu = "6";
    if($sothu=="Saturday") $sothu = "7";
    $plus = 1;
  
?>
<?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("https://soicau366.com/mien-nam/binh-thuan");
        $tinh = $html->find("div#div_bor_content ul",0);
        $kq = $html->find("section#ket-qua",0);
        
         ?>
<div id="div_bor_content">

    <?php echo $tinh; ?>

    <script>
        var time_block = -1520816706
    </script>

    <?php echo $__env->make('page.banner1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <div id="soi-cau">
        <div id="soi-cau">
            <h4>Soi cầu kết quả xổ số Bình Thuận ngày <?php echo e($date); ?></h4>
            
<?php if(Auth::check()): ?>
             
        <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/soicau.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng 
                    <?php if(Auth::user()->vip==0) echo "<A HREF='nap-the'>Nâng cấp Vip</A>"; else echo"<A HREF='chot-so'>Click vào đây</A>";?></b>
                    </a> để xem admin chốt số </div>
            </div>
        </div>
<?php else: ?>
    
            <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/soicau.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng
                    <a href="/dang-ky">Đăng Ký</a> hoặc
                    <a href="/dang-nhap">Đăng nhập</a> để xem admin chốt số </div>
            </div>

<?php endif; ?> 
    </div>
	</div>



    <?php echo $__env->make('page.banner2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              
<section id="chot-so">
        <div class="header">Khu vực chốt số của quản trị viên</div>
<?php if(Auth::check()): ?>
    <p style="padding: 15px;padding-bottom: 0; font-size: 18px;font-weight: bold;">
         <?php if(Auth::user()->vip==0) echo "Bạn phải là <A HREF='nap-the'>thành viên Vip</A> mới xem các QTV chốt số</A>"; else echo"<A HREF='chot-so'>Click vào đây</A> để xem QTV chốt số</A>";?>
         <?php else: ?>
        <p style="padding: 15px;padding-bottom: 0;font-size: 18px;font-weight: bold;">Bạn vui lòng
                <a href="dang-ky">Đăng ký</a> hoặc <a href="dang-nhap">Đăng nhập</a> để xem quản trị viên chốt số
            </p>
    
<?php endif; ?>
    <?php echo $__env->make('page.lochoinhieu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section id="forum">
        <h3 class="header">Diễn đàn chém gió soi cầu dự đoán kết quả xổ số</h3>
<?php echo $__env->make('page.comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('page.caothu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('page.banner3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php 
    $date = date("d-m-Y");
    $plus = 1;
    $date = date("d-m-Y",strtotime("$date -$plus day"));
    ?>

<section id="ket-qua">

 <?php echo $kq; ?>


<div id="zone_footer" class="zone" style="position: fixed;bottom: 0px; max-width: 720px; text-align: center; width:100%">


    <div id="hide_float_right">
        <a href="javascript:HOME.hide_float_right()">Tắt [X]</a>
    </div>
    <div id="float_content_right">
        <a href="http://caudep.me" rel="nofollow" target="_blank">
            <img alt="" src="soicau/upload/files/2018/02/caudep-megif1519549612.gif" class="img-responsive center-block">
        </a>
    </div>

</div>
<!-- Bootstrap JavaScript -->


<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-75158570-1', 'auto');
    ga('send', 'pageview');

</script>
<!-- Facebook Pixel Code -->
<script>
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '180697755797837'); // Insert your pixel ID here.
    fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
               src="https://www.facebook.com/tr?id=180697755797837&ev=PageView&noscript=1"
    /></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->
<script src="<?php echo e(asset('/js/app.js')); ?>"></script> 
    <script src="<?php echo e(asset('/js/main.js')); ?>"></script> 

    <script src="js/admin/alerts.js" ></script>
    <script>
        jQuery(document).ready(function(){
            if (HOME.getCookie("hide_popup_right_zone1") == "1") {
                var contentright = document.getElementById('float_content_right_zone1');
                var hideright = document.getElementById('hide_float_right_zone1');
                if (contentright.style.display != "none") {
                    contentright.style.display = "none";
                    hideright.innerHTML = '<a href="javascript:HOME.hide_float_right_zone1()">Xem quảng cáo...</a>';
                }
            };
       
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>