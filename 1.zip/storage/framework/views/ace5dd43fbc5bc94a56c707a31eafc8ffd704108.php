<?php
$day = date("d-m-Y");
use App\loto;
$today = date("Y-m-d");
$loto = loto::where('ngaydanh', $today)->get();
$homnay = date("Y-m-d");
$plus = 1; 
?>
 <?php $__env->startSection('content'); ?>
 <?php if(Session::has('loidanhde')): ?>
    <div class="alert alert-success">
        <?php echo e(Session::get('loidanhde')); ?>

    </div>
    <?php endif; ?>

    <?php if(Session::has('errors')): ?>
    <div class="alert alert-danger">
        <?php echo e(Session::get('errors')); ?>

    </div>
    <?php endif; ?>
     
<div class="container">
            <h1 style="color: red;text-align: center">LOTO ONLINE</h1>
            <div class="col-md-12 txtmb">(Miền Bắc)</div>
            <div class="col-xs-12  col-md-12 div_note"><span class="note">Lưu ý:</span> <br>
                <i> -Chỉ chơi loto Miền Mắc</i>
                <br>
                <i> -Thời gian kết thúc chơi loto vào lúc  18h hàng ngày và bắt đầu chơi lô và tổng kết số điểm sau 18h45 phút.</i>
                <i> -Mỗi thành viên chỉ được chốt số 1 lần duy nhất trong ngày.</i>
                <br>
                <i> -Thành viên có điểm lô cao nhất trong tháng sẽ nhận được<strong><span style="color: #ff0000;"> 2.000k</span></strong></i>
            </div>
        </div>
       
        <div class="col-xs-6">
                <h4 style="color: #337ab7"><strong>Chơi 3 lô tô ngày <?php echo e($day); ?></strong></h4>
            </div>
            <br><br><br>
            
<form action="loto-online" method="post">
        <?php echo e(csrf_field()); ?>

        
        <div>
            <label for="Number1">Number1</label>
            <input id="number1" type="number" name="number1" required ng-model="number" onKeyPress="if(this.value.length==2) return false;" min="0"
                 class="form-control"/>
        </div>
             
        <div>
            <label for="Number2">Number2</label>
            <input id="number2" type="number" name="number2" required ng-model="number" onKeyPress="if(this.value.length==2) return false;" min="0" class="form-control"/>
        </div>
    

        <div>
            <label for="Number3">Number3</label>
            <input id="number3" type="number" name="number3" required ng-model="number" onKeyPress="if(this.value.length==2) return false;" min="0" class="form-control"/>
        </div> 
   
        <div class="div_submit">
            <input class="btn btn-success" type="submit" value="Chốt Số">
            <a href="loto-online" class="btn btn-warning">Chốt lại</a>
        </div>

    </form>

<section>
        <h3 class="header h3_thongke" style="margin-bottom: 0px;"><span>THÀNH VIÊN CHỐT LOTO ONLINE HÔM NAY</span>
            
            
        </h3>
        
  <?php $__currentLoopData = $loto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="div_loto_online" class="post notice">
                        <div class="row_loto row_loto1">
                <div class="row">
                    <div class="row user-info left_loto">
                        <div class="col-xs-2 col-md-1 avt">
                            <a href="/user/<?php echo e($u->user->name); ?>">
                                <img class="img-circle avt_chat" src="public/uploads/avatars/<?php echo e($u->user->image); ?>" alt="<?php echo e($u->user->name); ?>">
                            </a>
                        </div>
                        <div class="col-xs-6 col-md-5 name">
                            <a class="name-chat" href="/user/<?php echo e($u->user->name); ?>"><h4><?php echo e($u->user->name); ?></h4></a>

                            <span class="point-loto"><?php echo e($u->user->diem); ?> điểm</span>
                        </div>
                    </div>
                    <div class="post-content right_loto">
                        <div class="col-xs-12">
                            <i class="time time-chat"><?php 
                            $date=date_create("$u->created_at");
                            echo date_format($date,"Y/m/d H:i:s"); 
                            ?></i>
                            <p class="p_logo">
                                <span>CHỐT:</span> <?php echo e($u->number); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>

                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    <ul>
    <li><a href="loto-online/<?php echo date("Y-m-d",strtotime("$homnay -$plus day")); ?>"><img src="images/truoc.png" alt="">Ngày trước</a></li>
                                                        </ul>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>