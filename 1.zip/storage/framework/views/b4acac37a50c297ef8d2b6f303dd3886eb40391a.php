 <?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php $date = date("d-m-Y")  ?>
   
           
  <?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("http://xsmb.vn/thong-ke-chan-le-kep-dac-biet-xo-so-mien-bac.html");
        $kq1 = $html->find("div.DACBIET_KQ",0);
         ?>
<div class="Page_CAULOTO_KQ">
                                <div class="Page_CAULOTO_KQ_title">
                                    Bảng Đặc biệt trong 5 tuần
                                </div>
                            </div>
<?php echo $kq1; ?>

<style type="text/css">
/*DACBIET*/
.DACBIET_KQ{
  width:100%;
  font-family: 'Roboto', sans-serif;
  padding:0 0 20px 0;
  text-align:left;
}
.DACBIET_KQ p{
  font-family:Arial, Helvetica, sans-serif;
  font-size:12px;
  font-weight:bold;
  margin:0;
  padding:10px 0 0 0;
  line-height:14px;
}
.DACBIET_KQ_col{
  width:14.3%;
  text-align:center;
  padding:10px 0 10px 0;
  font-size:13px;
  line-height:17px;
}
.DACBIET_KQ_col p{
  margin:0;
  font-size:16px;
  font-weight:bold;
  padding:5px 0 5px 0;
  color:#565656;
}

.DACBIET_KQ_col_time{
  font-size:12px;
  color:#aaaaaa;
}
.DACBIET_KQ_row_1{
  background-color:#f3efe7;
  color:#6e6e6e;
}
.DACBIET_KQ_row_2{
  background-color:#ffffff;
  color:#6e6e6e;
}
.DACBIET_KQ_bg_xam{
  background-color:#f4f4f4;
}
.gray{
  color:#333;
}
.xanh{color:#0014d2;}
.DACBIET_KQ_bg_tatca{
  background-color:#ffffff;
}
.DACBIET_KQ_bg_Chanle{
  background-color:#ffeddd;
}
.DACBIET_KQ_bg_Lechan{
  background-color:#f3ffe6;
}
.DACBIET_KQ_bg_ChanChan{
  background-color:#e8faff;
}
.DACBIET_KQ_bg_LeLe{
  background-color:#ffecf6;
}
.DACBIET_KQ_bg_mota{
  margin:20px 0 0 0;
}
.DACBIET_KQ_bg_boxmota{
  border:1px solid#d7d7d7;
  padding:5px 8px 5px 8px;
}
.DACBIET_KQ_line{
  margin:10px 0 10px 0;
  background-color:#e5e5e5;
  height:3px;
}
.Page_CAULOTO_KQ_title {
    background: #424242;
    line-height: 36px;
    text-align: left;
    padding: 0 0 0 10px;
    font-size: 14px;
    color: #FFF;
    font-weight: bold;
    font-family: 'Roboto', sans-serif;
    margin: 0 0 10px 0;
}
.Page_CAULOTO_KQ {
    text-align: left;
}
table {
    display: table;
    border-collapse: separate;
    border-spacing: 2px;
    border-color: grey;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>