<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form id="comment-form" method="post" action="<?php echo e(route('comments.store')); ?>" >
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>" >
                        <div class="row" style="padding: 10px;">
                            <div class="form-group">
                                <textarea class="form-control" name="comment" placeholder="Write something from your heart..!"></textarea>
                            </div>
                        </div>
                        <div class="row" style="padding: 0 10px 0 10px;">
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary btn-lg" style="width: 100%" name="submit">
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="row">
         <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Comments</div>

                <div class="panel-body comment-container" >
                    
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="well">
                            <i><b> <?php echo e($comment->name); ?> </b></i>&nbsp;&nbsp;
                            
                            <span> <?php echo e($comment->created_at); ?> </span>
                            <br>
                            <span> <?php echo e($comment->comment); ?> </span>
                            <div style="margin-left:10px;">
                                <a style="cursor: pointer;" cid="<?php echo e($comment->id); ?>" name_a="<?php echo e(Auth::user()->name); ?>" token="<?php echo e(csrf_token()); ?>" class="reply">Reply</a>&nbsp;
                                <a style="cursor: pointer;"  class="delete-comment" token="<?php echo e(csrf_token()); ?>" comment-did="<?php echo e($comment->id); ?>" >Delete</a>
                                <div class="reply-form">
                                    
                                    <!-- Dynamic Reply form -->
                                    
                                </div>
                                <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($comment->id === $rep->comment_id): ?>
                                        <div class="well">
                                            <i><b> <?php echo e($rep->name); ?> </b></i>&nbsp;&nbsp;
                                             <span> <?php echo e($rep->created_at); ?> </span>
                                                 <br>
                                            <span> <?php echo e($rep->reply); ?> </span>
                                            <div style="margin-left:10px;">
                                                <a rname="<?php echo e(Auth::user()->name); ?>" rid="<?php echo e($comment->id); ?>" style="cursor: pointer;" class="reply-to-reply" token="<?php echo e(csrf_token()); ?>">Reply</a>&nbsp;<a did="<?php echo e($rep->id); ?>" class="delete-reply" token="<?php echo e(csrf_token()); ?>" >Delete</a>
                                            </div>
                                            <div class="reply-to-reply-form">
                                    
                                                <!-- Dynamic Reply form -->
                                                
                                            </div>
                                            
                                        </div>
                                    <?php endif; ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>

   

</div>
<?php $__env->stopSection(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/main.js')); ?>">
  
</script>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>