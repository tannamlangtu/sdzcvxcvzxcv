<div id="div_bor_tb" class="row"><section id="bai-viet" class="baiviet1"><h5 class="header header1">THÔNG BÁO</h5><div id="notice" class="div_tbhome" style="width: 98%;margin: auto;"><p>Chào mừng các thành viên đã đến với <span style="color: #ff0000;"><strong>diễn đàn soi cầu</strong>
</span>. Nhằm thêm động viên tinh thần khích lệ cho anh em.<br>Admin sẽ Tặng thẻ nạp cho thành viên có số điểm cao nhất, nhì, ba trong tháng cụ thể như sau:</p>
<p><strong>1. TV có điểm cao nhất :</strong> 
	<strong><span style="color: #ff0000;">500k</span></strong></p>
<p><strong>2. TV có điểm cao nhì :</strong> 
	<span style="color: #ff0000;"><strong>200k</strong></span></p>
<p><span style="color: #ff0000;">
	<strong><span style="color: #000000;">3. TV có điểm cao thứ ba :</span> 100k</strong></span></p>
<p><span style="color: #000000;">
<p><span style="color: #0000ff;"><em>
	<strong>Chúc các thành viên may mắn !</strong></em></span></p></div></section></div> 