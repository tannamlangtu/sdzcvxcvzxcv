
<div class="site-content container">

    <h3 class="section-title">Thêm số mơ</h3>
    <form action="them-so-mo" method="post">
        <?php echo e(csrf_field()); ?>


            <div>
                <label for="phone">1</label>
                <input id="name" type="text" name="name" required  maxlength="255" class="form-control"/>
               
            </div>
            <div>
                <label for="number"></label>
                <input id="number" type="text" name="number" required  class="form-control"/>
               
            </div>
           
            <div>
                <label for="phone">2</label>
                <input id="name1" type="text" name="name1" required  maxlength="255" class="form-control"/>
               
            </div>
            <div>
                <label for="number"></label>
                <input id="number1" type="text" name="number1" required  class="form-control"/>
               
            </div>


        <div class="div_submit">
            <input class="btn btn-success" type="submit" value="Thêm">
            <a href="/" class="btn btn-warning">Hủy bỏ</a>
        </div>
    </form>
</div>
