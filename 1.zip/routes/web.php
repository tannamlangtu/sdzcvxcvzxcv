<?php
use App\User;
use Illuminate\Support\Facades\Input;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
| 
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/ 
Route::get('/',[
    'as'=>'trangchu',
    'uses'=>'PageController@index'
]);
Route::get('reset',[
    'as'=>'reset',
    'uses'=>'PageController@getresetpassword'
]);
Route::post('reset',[
    'as'=>'reset',
    'uses'=>'PageController@postresetpassword'
]);
Route::get('/',  'PageController@index')->name('home');
Route::resource('comments','CommentsController');
Route::resource('replies','RepliesController');
Route::post('replies/ajaxDelete','RepliesController@ajaxDelete');
Route::get('soi-cau/thong-ke','PageController@thongke');
Route::get('chan-le-dac-biet','PageController@chanledacbiet');
Route::get('thong-ke-00-99','PageController@thongke0099');
Route::get('soi-cau/dac-biet','PageController@dacbiet');
Route::get('quay-thu','PageController@quaythu');
Route::get('loto-online','PageController@getloto');
Route::post('loto-online','PageController@postloto');
Route::get('quen-mat-khau','PageController@getquenmatkhau');
Route::get('inbox','PageController@getinbox');
Route::get('me','PageController@getme');
Route::post('me', 'PageController@update_avatar');
Route::get('nap-the','PageController@napthe' );
Route::get('soi-cau','PageController@soicau' );
Route::get('mien-bac','PageController@getmienbac');
Route::get('/ket-qua/mien-bac','PageController@getkqmb');
Route::get('/ket-qua/mien-nam','PageController@getkqmn');
Route::get('/ket-qua/mien-trung','PageController@getkqmt');
Route::get('dang-ky',[
    'as'=>'dangky',
    'uses'=>'PageController@getdangky'
]);
Route::post('dang-ky',[
    'as'=>'dangky',
    'uses'=>'PageController@postdangky'
]);
Route::get('dang-nhap',[
    'as'=>'dangnhap',
    'uses'=>'PageController@getdangnhap'
]);
Route::post('dang-nhap',[
    'as'=>'dangnhap',
    'uses'=>'PageController@postdangnhap'
]);
Route::get('dang-xuat',[
    'as'=>'dangxuat',
    'uses'=>'PageController@getdangxuat'
]);
Route::get('ketqua',[
    'as'=>'ketqua',
    'uses'=>'PageController@getketqua'
]);
Route::post('ketqua',[
    'as'=>'ketqua',
    'uses'=>'PageController@postketqua'
]);
Route::resource('kqxs','kqxsController');
Route::get('ket-qua-xoso','PageController@ketquaxoso');
//  
Route::resource('users','UserController');
Route::resource('giaodich','NaptheController');
Route::resource('giahan','GiahanController');
Route::resource('users/createloto','UserController@createloto');
Route::get('ajax/title/{idcity}/{day}','AjaxController@gettitle');
Route::get('ketqua/ajax/dai/{thu}/{ngay}','AjaxController@getdai');
Route::get('kqxs/ajax/ketqua/{idcity}/{ngay}','AjaxController@getkqxs');
Route::get('ajax/city/{thu}','AjaxController@getcity');
Route::get('ajax/ketqua/{idcity}/{day}','AjaxController@getketqua');
Route::get('user/{name}','AjaxController@getname');
Route::get('loto-online/{ngay}','AjaxController@getloto'); 
Route::get('chot-so','PageController@getchotso'); 
// 
Route::get('ket-qua/mien-bac/{date}','AjaxController@getmienbac'); 
Route::get('mien-nam/{ngay}','AjaxController@getmiennam'); 
Route::get('mien-trung/{ngay}','AjaxController@getmientrung'); 
// 
Route::get('tim-kiem-thanh-vien','PageController@timkiem');
Route::any('tim-kiem-thanh-vien/timkiem',function(){
    $q = Input::get ( 'q' );
    $user = User::where('name','LIKE','%'.$q.'%')->paginate(10);
        return view('page.timthanhvien')->withDetails($user)->withQuery ( $q );
});
Route::post('nap-the',[
    'as'=>'napthe',
    'uses'=>'PageController@postnapthe'
]);
Route::get('so-mo','PageController@getsomo');
Route::get('test','PageController@test');


// ketqua/miennam
Route::get('ket-qua/mien-nam/ho-chi-minh','MiennamController@xshcm');
Route::get('ket-qua/mien-nam/tien-giang','MiennamController@xstg');
Route::get('ket-qua/mien-nam/ben-tre','MiennamController@xsbt');
Route::get('ket-qua/mien-nam/an-giang','MiennamController@xsag');
Route::get('ket-qua/mien-nam/long-an','MiennamController@xsla');
Route::get('ket-qua/mien-nam/kien-giang','MiennamController@xskg');
Route::get('ket-qua/mien-nam/bac-lieu','MiennamController@xsbl');
Route::get('ket-qua/mien-nam/tay-ninh','MiennamController@xstn');
Route::get('ket-qua/mien-nam/binh-phuoc','MiennamController@xsbp');
Route::get('ket-qua/mien-nam/da-lat','MiennamController@xsdl');
Route::get('ket-qua/mien-nam/vung-tau','MiennamController@xsvt');
Route::get('ket-qua/mien-nam/binh-thuan','MiennamController@xsbthuan');
Route::get('ket-qua/mien-nam/hau-giang','MiennamController@xshg');
Route::get('ket-qua/mien-nam/can-tho','MiennamController@xsct');
Route::get('ket-qua/mien-nam/binh-duong','MiennamController@xsbd');
Route::get('ket-qua/mien-nam/dong-thap','MiennamController@xsdt');
Route::get('ket-qua/mien-nam/dong-nai','MiennamController@xsdn');
Route::get('ket-qua/mien-nam/tra-vinh','MiennamController@xstv');
Route::get('ket-qua/mien-nam/ca-mau','MiennamController@xscm');
Route::get('ket-qua/mien-nam/soc-trang','MiennamController@xsst');
Route::get('ket-qua/mien-nam/vinh-long','MiennamController@xsvl');
  
// ketqua/mientrung
Route::get('ket-qua/mien-trung/khanh-hoa','MientrungController@xskh');
Route::get('ket-qua/mien-trung/da-nang','MientrungController@xsdn');
Route::get('ket-qua/mien-trung/quang-ngai','MientrungController@xsqn');
Route::get('ket-qua/mien-trung/kon-tum','MientrungController@xskt');
Route::get('ket-qua/mien-trung/binh-dinh','MientrungController@xsbd');
Route::get('ket-qua/mien-trung/dac-nong','MientrungController@xsbn');
Route::get('ket-qua/mien-trung/phu-yen','MientrungController@xspy');
Route::get('ket-qua/mien-trung/quang-binh','MientrungController@xsqb');
Route::get('ket-qua/mien-trung/thua-thien-hue','MientrungController@xshue');
Route::get('ket-qua/mien-trung/quang-tri','MientrungController@xsqt');
Route::get('ket-qua/mien-trung/dac-lac','MientrungController@xsdl');
Route::get('ket-qua/mien-trung/gia-lai','MientrungController@xsgl');
Route::get('ket-qua/mien-trung/quang-nam','MientrungController@xsqnam');
Route::get('ket-qua/mien-trung/ninh-thuan','MientrungController@xsnt');
