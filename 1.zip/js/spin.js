function spin() {
	// Status of title.
	var titleObj = jQuery('g-title');
	
	//Hide btn to avoid spam click.
	jQuery('#btnq').hide();
	
	var i, g, started, duration, titleArr = ['Đặc Biệt','nhất','nhì','ba','tư','năm','sáu','bảy','Đặc Biệt'];
	g 	= jQuery('.g-title').data('g');
	i  	= g.substr(-1,1);
	_n 	= jQuery('.g-title').data('n');
	
	// Reload page if all title were finished.
	if (i > 8)
		location.reload(true);
	
	// Time duration for spinning.
	duration = 5000;
	
	// Time for start spin.
	started = new Date().getTime();
	
	// Clear old result if already exists
	spins 	= jQuery('.square .spin');
	spins.html('');
	
	// Numbers of spinning over the title.
	switch (i) {
		case '8':
		case '1':
			var v = 1;
			break;
		case '2':
			var v = 2;
			break;
		case '3':
		case '5':
			var v = 6;
			break;
		case '4':
		case '7':
			var v = 4;
			break;
		case '6':
			var v = 3;
			break;
	}
	
	// Status of title.
	if (g.substr(-1,1) != 0 && i <= 8)
		if (v > 1)
			$('h1.g-title').html('Đang quay giải '+titleArr[i]+' lần '+_n);
		else 
			$('h1.g-title').html('Đang quay giải '+titleArr[i]);
	
	//Spin for find result.
	animationTimer = setInterval(function() {
		if (new Date().getTime() - started > duration) {
			clearInterval();
			var spin_rs = spins.text();
		} else {
			spins.each(function(value, sp) {
			if (i <= 3 || i == 8) {
				$(sp).text(
					Math.floor(Math.random() * 10)
				);
			} else if (3 < i && i <= 5) {
				if (value > 0)
					$(sp).text(
						Math.floor(Math.random() * 10)
					);
			} else if (i ==  6){
				if (value >= 2 )
					$(sp).text(
						Math.floor(Math.random() * 10)
					);
			} else {
				if (value >= 3)
					$(sp).text(
						Math.floor(Math.random() * 10)
					);
			}
			});
		}
	},80);

	// Update result.
	setTimeout(function() {
		var result  = spins.text();
		var dauu 	= result.substr(-1,1);
		var duoii 	= result.substr(-2,1);
		if (i == 8){
			jQuery('td#g0-'+_n).html('<big><strong><b style="color: red">'+result+'</b></strong></big>');
			i++;
		} else {
			jQuery('td#g'+i+'-'+_n).html('<strong>'+result+'</strong>');
			if (_n < v) {
				_n++;
			} else {
				_n = 1;
				i++;
			}
			
		}
		
		// Title.
		if (i > 8) {
			var title = 'Kết thúc quay số';
		} else { 
			if (i < 8)
				var title = 'Đang chuẩn bị quay giải '+titleArr[i];
			else 
				var title = 'Đang chuẩn bị quay giải Đặc Biệt';
		}
		var content = '<h4 class="g-title" data-g="g'+i+'" data-n="'+_n+'">'+title;
		(_n > 1 && i != 0) ? content += ' lần '+_n+'</h4>' : content += '</h4>';
		
		// Update title and round for the next spin.
		jQuery('h4.g-title').remove();
		jQuery('#t-wrap').prepend(content);
		
		// Update the lo by the first number.
		var dau = jQuery(jQuery('tr#d'+result.substr(-2,1)).children()[1]).text();
		dau == '' ? dau += dauu : dau += ' , '+dauu;
		jQuery(jQuery('tr#d'+result.substr(-2,1)).children()[1]).html(dau);
		

		var duoi = jQuery(jQuery('tr#h'+result.substr(-1,1)).children()[0]).text();
		duoi == '' ? duoi += duoii : duoi += ' , '+duoii;
		jQuery(jQuery('tr#h'+result.substr(-1,1)).children()[0]).html(duoi);
		
		// Show the spin button again;
		jQuery('#btnq').show();
		
		// Show the save button after spin all title.
		if (jQuery('#g0-1').text() != '')
			jQuery('#saveBtn').removeClass('hide');
	},5005);
}
