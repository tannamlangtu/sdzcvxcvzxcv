@extends('admin.master') @section('content')
<!-- Content Wrapper. Contains page content -->

<div class="content-wrapper">
<?php
echo phpversion();
?>
</div>
<!-- /.content-wrapper -->
@endsection