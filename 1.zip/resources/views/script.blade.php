 
<script>
    jQuery(document).ready(function () {
        if (HOME.getCookie("hide_popup_right_zone1") == "1") {
            var contentright = document.getElementById('float_content_right_zone1');
            var hideright = document.getElementById('hide_float_right_zone1');
            if (contentright.style.display != "none") {
                contentright.style.display = "none";
                hideright.innerHTML =
                    '<a href="javascript:HOME.hide_float_right_zone1()">Xem quảng cáo...</a>';
            }
        };
        if (HOME.getCookie("hide_popup_right_zone2") == "1") {
            var contentright = document.getElementById('float_content_right_zone2');
            var hideright = document.getElementById('hide_float_right_zone2');
            if (contentright.style.display != "none") {
                contentright.style.display = "none";
                hideright.innerHTML =
                    '<a href="javascript:HOME.hide_float_right_zone2()">Xem quảng cáo...</a>';
            }
        };
    });
</script>
<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer>
</script>
<script type="text/javascript">
    var recaptcha1;
    var onloadCallback = function () {
        recaptcha1 = grecaptcha.render(
            'Recaptcha_subscribe', {
                'sitekey': '6LeWKS4UAAAAAPfippSGh47kqNgMPX7e3w7WoeW2',
                'callback': function (a) {
                    USER.register_submit();

                }
            }
        );

    };
</script>
