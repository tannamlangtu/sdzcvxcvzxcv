@extends('master') @section('content')
<!-- Content Wrapper. Contains page content -->
<?php 
$day = date("d-m-Y");
$plus = 1; ?>
<div class="list-tinh">
     <li><a class="" href="ket-qua/mien-trung/khanh-hoa">Khánh Hoà</a></li>
     <li><a class="" href="ket-qua/mien-trung/da-nang">Đà Nẵng</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-ngai">Quãng Ngãi</a></li>
     <li><a class="" href="ket-qua/mien-trung/kon-tum">Kon Tum</a></li>
     <li><a class="" href="ket-qua/mien-trung/binh-dinh">Bình Định</a></li>
     <li><a class="" href="ket-qua/mien-trung/dac-nong">Đắc Nông</a></li>
     <li><a class="" href="ket-qua/mien-trung/phu-yen">Phú Yên</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-binh">Quãng Bình</a></li>
     <li><a class="" href="ket-qua/mien-trung/thua-thien-hue">Huế</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-tri">Quãng Trị</a></li>
     <li><a class="" href="ket-qua/mien-trung/dac-lac">Dak Lak</a></li>
     <li><a class="" href="ket-qua/mien-trung/gia-lai">Gia Lai</a></li>
     <li><a class="" href="ket-qua/mien-trung/quang-nam">Quãng Nam</a></li>
     <li><a class="" href="ket-qua/mien-trung/ninh-thuan">Ninh Thuận</a></li>
 </div>
<div class="content-wrapper">
  
   
    <section id="ket-qua" style="margin-bottom: 15px;clear: both;">
        
       
<div class="row">
        <div class="col-xs-12">
            <table class="table table-bordered table-striped">
               <tbody>
                 
        <h3 class="header">Kết quả xổ số miền trung ngày {{$ngay = date("d-m-Y",strtotime($ngay))}}</h3>
        
                    <tbody>
                            <tr class="gr-yellow">
                                <th class="first">Đài</th>
                                @foreach($city2 as $cty)
                                <th>
    
                                        <b class="underline">{{$cty->name}}</b>
                                    </a>
                                    <br/>
                                   
                                </th>
                                @endforeach
                            </tr>
                            <tr class="g8">
                                <td>G8</td>
                                @for($i=0;$i<count($city2);$i++)
                                <td>
                                    <div>{!!$rmt[$i]['rs_8_0']!!}</div>
                                </td>
                                @endfor
                            </tr>
                            <tr>
                                <td>G7</td>
                                @for($i=0;$i<count($city2);$i++)
                                <td>
                                    <div>{!!$rmt[$i]['rs_7_0']!!}</div>
                                </td>
                                @endfor
                            </tr>
                            <tr>
                                <td>G6</td>
                                @for($i=0;$i<count($city2);$i++)
                                <td>
                                    <div>{!!$rmt[$i]['rs_6_2']!!}</div>
                                    <div>{!!$rmt[$i]['rs_6_1']!!}</div>
                                    <div>{!!$rmt[$i]['rs_6_0']!!}</div>
                                </td>
                                @endfor
                            </tr>
                            <tr>
                                <td>G5</td>
                                @for($i=0;$i<count($city2);$i++)
                                <td>
                                    <div>{!!$rmt[$i]['rs_5_0']!!}</div>
                                </td>
                                @endfor
                            </tr>
                            <tr>
                                <td>G4</td>
                                @for($i=0;$i<count($city2);$i++)
                                <td>
                                    <div>{!!$rmt[$i]['rs_4_6']!!}</div>
                                    <div>{!!$rmt[$i]['rs_4_5']!!}</div>
                                    <div>{!!$rmt[$i]['rs_4_4']!!}</div>
                                    <div>{!!$rmt[$i]['rs_4_3']!!}</div>
                                    <div>{!!$rmt[$i]['rs_4_2']!!}</div>
                                    <div>{!!$rmt[$i]['rs_4_1']!!}</div>
                                    <div>{!!$rmt[$i]['rs_4_0']!!}</div>
                                </td>
                                @endfor
                            </tr>
                            <tr>
                                <td>G3</td>
                                @for($i=0;$i<count($city2);$i++)
                                <td>
                                    <div>{!!$rmt[$i]['rs_3_1']!!}</div>
                                    <div>{!!$rmt[$i]['rs_3_0']!!}</div>
                                </td>
                                @endfor
                            </tr>
                            <tr>
                                <td>G2</td>
                                @for($i=0;$i<count($city2);$i++)
                                <td>
                                    <div>{!!$rmt[$i]['rs_2_0']!!}</div>
                                </td>
                                @endfor
                            </tr>
                            <tr>
                                <td>G1</td>
                                @for($i=0;$i<count($city2);$i++)
                                <td>
                                    <div>{!!$rmt[$i]['rs_1_0']!!}</div>
                                </td>
                                @endfor
                            </tr>
                            <tr class="gdb">
                                <td>ĐB</td>
                                @for($i=0;$i<count($city2);$i++)
                                <td>
                                    <div>{!!$rmt[$i]['rs_0_0']!!}</div>
                                </td>
                                @endfor
                            </tr>
                </tbody>
            </table>
        </div>
    </div>
<div class="row">
        <div class="col-xs-12 ">
            <table class="table table-bordered table-striped">
                
                <tbody>
                        <tr class="header">
                            <th width="10%" class="first">Đầu</th>
                            @foreach($city2 as $cty)
                            <th>{{$cty->name}}</th>
                            @endforeach
                        </tr>
                        @for($k=0;$k<10;$k++)
                        <tr>
                            <td>
                                <b class="clnote">{{$k}}</b>
                            </td>
                            @for($i=0;$i<count($rmt);$i++)
                            <td><?php $j=0; for($m=0;$m<count($kqmt[$i]);$m++){ if(substr($kqmt[$i][$m],0,1)==(string)$k){if($j==0){echo substr($kqmt[$i][$m],-2);$j=1;}else echo ', '.substr($kqmt[$i][$m],-2);}}?></td>
                            @endfor()
                        </tr>
                        @endfor
                    </tbody>
                </div>
            </table>
        </div>
    </div>
<div class="row">
        <div class="col-xs-12 ">
            <table class="table table-bordered table-striped">
                <tbody>
                        <tr class="header">
                            <th width="10%" class="first">Đít</th>
                            @foreach($city2 as $cty)
                            <th>{{$cty->name}}</th>
                            @endforeach
                        </tr>
                        @for($k=0;$k<10;$k++)
                        <tr>
                            <td>
                                <b class="clnote">{{$k}}</b>
                            </td>
                            @for($i=0;$i<count($rmt);$i++)
                            <td><?php $j=0; for($m=0;$m<count($kqmt[$i]);$m++){ if(substr($kqmt[$i][$m],-1)==(string)$k){if($j==0){echo substr($kqmt[$i][$m],0,2);$j=1;}else echo ', '.substr($kqmt[$i][$m],0,2);}}?></td>
                            @endfor()
                        </tr>
                        @endfor
                    </tbody>
               
            </table>
        </div>
    </div>
<div class="row">
                    <div class="row left_loto">
    <ul><li><a href="mien-trung/<?php echo date("Y-m-d",strtotime("$ngay -$plus day")); 
                ?>"><img src="images/truoc.png" alt="Ngày sau">Ngày trước</a></li></ul>

                    </div>
                    <div class="row right_loto">
                        
    
     <li><a href="mien-trung/<?php echo date("Y-m-d",strtotime("$ngay +$plus day")); 
                ?>">Ngày sau</a></li>
   
                    </div>
                </div>


 <div class="row xem-them">
            <div class="col-xs-12">
                &gt;&gt; Xem thêm KQXS:

                <ul>
                                        <li><a class="" href="/ket-qua/mien-bac">Miền bắc</a></li>
                                        <li><a class="" href="/ket-qua/mien-trung">Miền trung</a></li>
                                        <li><a class="current" href="/ket-qua/mien-nam">Miền nam</a></li>
                                    </ul>
            </div>

        
 
    <!-- /.content -->
</div>
</section>
<!-- /.content-wrapper -->
@endsection