@extends('master') @section('content')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php $date = date("d-m-Y")  ?>
   
           
  <?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("http://xsmb.vn/thong-ke-giai-dac-biet-xo-so-mien-bac.html");
        $kq = $html->find("div.TKDB_TUANTHANG",0);
        $kq1 = $html->find("div.Page_CAULOTO_KQ_title_2",0);
        $kq2 = $html->find("div.DACBIET_TK_BANGDB_KQ",0);
       
         ?>
<div class="Page_CAULOTO_KQ_title_2">
                                Thống kê 2 số cuối giải đặc biệt KQXSMB trong 5 tuần
                            </div>
{!!$kq!!}
{!!$kq1!!}
{!!$kq2!!}
<style type="text/css">
    /*------------------THONGKEDB_TUANTHANG----------*/
.TKDB_TUANTHANG{
    margin:0 0 15px 0;
}
.TKDB_TUANTHANG p{
    line-height:28px;
    font-size:14px;
    text-align:left;
    color:#69a500;
    margin:0;
    font-weight:bold;
}
.TKDB_TUANTHANG_table{
    font-family: 'Roboto', sans-serif;
}
.TKDB_TUANTHANG_table_row_1{
    background-color:#f0f0f0;
    font-size:14px;
}
.TKDB_TUANTHANG_table_row_2{
    background-color:#ffffff;
    font-size:14px;
}
.TKDB_TUANTHANG_table_row_3{
    background-color:#ffffff;
    font-size:12px;
}
.TKDB_TUANTHANG_table_col_1{
    width:20%;
    text-align:center;
    padding:8px 0 8px 0;
    font-weight:bold;
}
.TKDB_TUANTHANG_table_col_2{
    width:30%;
    text-align:left;
    padding:8px 0 8px 10px;
}
.TKDB_TUANTHANG_table_col_3{
    width:20%;
    text-align:center;
    padding:8px 0 8px 0;
}
/*BangDB*/
.BangDB{
    font-size:15px;
    color:#FFF;
    text-align:center;
    font-weight:bold;
    font-family: 'Roboto', sans-serif;
    background-color:#69a500;
    padding:10px 0 10px 0;
    border:1px solid#dfdfdf;
    border-bottom:none;
}
.DACBIET_TK_BANGDB_KQ{
    width:100%;
    font-family: 'Roboto', sans-serif;
    margin:0 0 20px 0;
    text-align:left;
}
.DACBIET_TK_BANGDB_KQ p{
    font-family:Arial, Helvetica, sans-serif;
    font-size:12px;
    font-weight:bold;
    margin:0;
    padding:10px 0 0 0;
    line-height:14px;
}
.DACBIET_TK_BANGDB_KQ_col{
    width:14.2%;
    text-align:center;
    padding:5px 0 5px 0;
    font-size:13px;
    line-height:17px;
}
h3{
    margin:0;
}
.h3_color_text_1{
    color:#FFF;
}
.h3_color_text_2{
    color:#464646;
    font-size:13px;
}
.fon14{font-size:14px;}
.fon13{font-size:13px;}
.DACBIET_TK_BANGDB_KQ_col p{
    margin:0;
    font-size:15px;
    font-family: 'Roboto', sans-serif;
    font-weight:bold;
    padding:5px 0 5px 0;
    color:#565656;
}

.DACBIET_TK_BANGDB_KQ_col_time{
    font-size:12px;
    color:#aaaaaa;
}
.DACBIET_TK_BANGDB_KQ_row_1{
    background-color:#f1f1f1;
    color:#6e6e6e;
}
.DACBIET_TK_BANGDB_KQ_row_2{
    background-color:#ffffff;
    color:#6e6e6e;
}
.DACBIET_TK_BANGDB_KQ_bg_xam{
    background-color:#efefef;
    color:#efefef
}
.DACBIET_TK_BANGDB_KQ_bg_xanh{
    background-color:#eaf8d1;
    color:#393939
}

.Page_CAULOTO_KQ_title_2 {
    background: #424242;
    line-height: 36px;
    text-align: left;
    padding: 0 0 0 10px;
    font-size: 14px;
    color: #FFF;
    font-weight: bold;
    font-family: 'Roboto', sans-serif;
    margin: 0 0 0 0;
}
.TKDB_TUANTHANG_table_col_2 {
    width: 30%;
    text-align: left;
    padding: 8px 0 8px 10px;
}
.TKDB_TUANTHANG_table_row_1 {
    background-color: #f0f0f0;
    font-size: 14px;
}
.do {
    color: #c21824;
}
table[Attributes Style] {
    width: 100%;
    border-top-width: 0px;
    border-right-width: 0px;
    border-bottom-width: 0px;
    border-left-width: 0px;
    -webkit-border-horizontal-spacing: 1px;
    -webkit-border-vertical-spacing: 1px;
    background-color: rgb(225, 225, 225);
}
user agent stylesheet
table {
    display: table;
    border-collapse: separate;
    border-spacing: 2px;
    border-color: grey;
}

</style>
   
</section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
@endsection