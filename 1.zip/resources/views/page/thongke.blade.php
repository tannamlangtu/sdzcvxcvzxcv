@extends('master') @section('content')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php $date = date("d-m-Y")  ?>
   
           
  <?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("http://xsmb.vn/");
        $kq1 = $html->find("div.THONGKE_title_small",0);
        $kq2 = $html->find("div.Centre_TKCKdanLOTO_bg",0);
         $kq3 = $html->find("div.THONGKE_title_small",1);
          $kq4 = $html->find("div.Centre_TKCKdanLOTO_bg",1);
         
         ?>
<div class="TK_title">
                                BẢNG THỐNG KÊ XỔ SỐ MIỀN BẮC
                            </div>
{!!$kq1!!}
{!!$kq2!!}
{!!$kq3!!}
{!!$kq4!!}
<style type="text/css">

  /*--------------BangTK-----------------*/
.TK_title{
  font-size:15px;
  color:#ffffff;
  text-align:center;
  font-weight:bold;
  font-family: 'Roboto', sans-serif;
  background-color:#69a500;
  padding:10px 0 10px 0;
}
.TK_box{
  margin:0 0 15px 0;
}
.THONGKE_title_small{
  background-color:#f0f0f0;
  text-align:left;
  height:28px;
  padding:3px 0 0 0;
}
.THONGKE_title_small span{
  border-left:5px solid#ff5400;
  line-height:24px;
  height:24px;
  font-family: 'Roboto', sans-serif;
  font-size:13px;
  font-weight:bold;
  text-align:left;
  padding-left:8px;
  color:#393939;
}
/*THONGKEChukydanLOTO*/
.Centre_TKCKdanLOTO_bg{
  background-color:#FFF;
  margin:0 0 10px 0;
}
.Centre_TKCKdanLOTO_table_row_1{
  background-color:#ffffff;
  font-weight:normal;
  font-family: 'Roboto', sans-serif;
  font-size:13px;
  line-height:24px;
}
.Centre_TKCKdanLOTO_table_row_2{
  background-color:#ffffff;
  font-family: 'Roboto', sans-serif;
  font-size:13px;
}
.Centre_TKCKdanLOTO_table_col_1{
  width:12%;
  text-align:center;
  padding:5px 0 5px 0;
}
.Centre_TKCKdanLOTO_table_col_2{
  width:23%;
  text-align:center;
  padding:5px 0 5px 0;
}
.Centre_TKCKdanLOTO_table_col_3{
  width:20%;
  text-align:center;
  padding:5px 0 5px 0;
}
.Centre_TKCKdanLOTO_table_col_4{
  width:20%;
  text-align:center;
  padding:5px 0 5px 0;
}
.Centre_TKCKdanLOTO_table_col_5{
  width:25%;
  text-align:center;
  padding:5px 0 5px 0;
}
.Centre_TKCKdanLOTO_box_number_LOTO{
  width:26px;
  height:28px;
  line-height:28px;
  font-size:13px;
  text-align:center;
  background-color:#fff;
  padding:5px 8px 5px 8px;
  border-radius: 3px;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  font-weight:bold;
  color:#c21824;
  border:1px solid#c21824;
  font-family: 'Roboto', sans-serif;
}
.Centre_TKCKdanLOTO_box_number{
  width:26px;
  height:28px;
  line-height:28px;
  font-size:13px;
  text-align:center;
  padding:5px 8px 5px 8px;
  border-radius: 3px;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  font-weight:bold;
  color:#ffffff;
  background-color:#c21824;
  font-family: 'Roboto', sans-serif;
}
.Centre_TKCKdanLOTO_note{
  line-height:32px;
  text-align:center;
  font-size:13px;
  color:#0288d1;
  font-family: 'Roboto', sans-serif;
}
.Centre_TKCKdanLOTO_note a{color:#5f93b0;}
.Centre_TKCKdanLOTO_note a:hover{ color:#F00;}
/*ENDTHONGKEChukydanLOTO*/
table[Attributes Style] {
    width: 100%;
    border-top-width: 0px;
    border-right-width: 0px;
    border-bottom-width: 0px;
    border-left-width: 0px;
    -webkit-border-horizontal-spacing: 1px;
    -webkit-border-vertical-spacing: 1px;
    background-color: rgb(240, 240, 240);
}
user agent stylesheet
table {
    display: table;
    border-collapse: separate;
    border-spacing: 2px;
    border-color: grey;
}
.xanh {
    color: #0014d2;
}
table {
    display: table;
    border-collapse: separate;
    border-spacing: 2px;
    border-color: grey;
}
</style>
   <br>
</section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
@endsection