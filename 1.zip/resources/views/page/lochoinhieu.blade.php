<?php 
use App\User;
use App\loto;
$today = date("Y-m-d");
$ngay = date("d/m/Y");
$loto = loto::where('ngaydanh', $today)->pluck('number');
?>
<section>
    <h4 class="h4_title_tk">LÔ CHƠI NHIỀU NGÀY {{$ngay}}</h4>
    <div id="stats" class="row stats div_thongke" style="margin-bottom: 20px;">
 
<?php  
$string = $loto;
$result = substr_count($string, "01");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">01</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "02");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">02</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "03");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">03</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "04");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">04</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "05");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">05</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "06");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">06</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "07");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">07</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "08");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">08</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "09");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">09</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "10");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">10</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "11");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">11</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "12");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">12</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "13");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">13</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "14");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">14</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "15");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">15</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "16");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">16</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "17");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">17</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "18");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">18</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "19");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">19</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "20");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">20</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "21");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">21</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "22");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">22</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "23");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">23</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "24");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">24</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "25");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">25</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "26");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">26</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "27");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">27</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "28");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">28</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "29");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">29</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "30");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">30</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "31");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">31</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "32");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">32</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "33");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">33</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "34");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">34</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "35");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">35</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "36");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">36</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "37");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">37</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "38");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">38</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "39");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">39</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "40");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">40</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "41");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">41</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "42");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">42</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "43");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">43</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "44");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">44</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "45");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">45</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "46");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">46</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "47");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">47</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "48");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">48</span><span class="right">';echo $result;echo' lần </span></div>';}?> 
<?php  
$string = $loto;
$result = substr_count($string, "49");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">49</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "50");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">50</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "51");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">51</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "52");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">52</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "53");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">53</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "54");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">54</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "55");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">55</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "56");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">56</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "57");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">57</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "58");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">58</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "59");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">59</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "60");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">60</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "61");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">61</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "62");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">62</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "63");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">63</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "64");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">64</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "65");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">65</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "66");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">66</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "67");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">67</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "68");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">68</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "69");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">69</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "70");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">70</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "71");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">71</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "72");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">72</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "73");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">73</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "74");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">74</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "75");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">75</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "76");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">76</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "77");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">77</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "78");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">78</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "79");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">79</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "80");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">80</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "81");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">81</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "82");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">82</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "83");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">83</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "84");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">84</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "85");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">85</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "86");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">86</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "87");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">87</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "88");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">88</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "89");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">89</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "90");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">90</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "91");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">91</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "92");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">92</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "93");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">93</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "94");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">94</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "95");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">95</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "96");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">96</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "97");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">97</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "98");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">98</span><span class="right">';echo $result;echo' lần </span></div>';}?>  
<?php  
$string = $loto;
$result = substr_count($string, "99");
if ($result > 0)
{echo '<div class="col-xs-3 divbs"><span class="left">99</span><span class="right">';echo $result;echo' lần </span></div>';}?>  

            </div>
</section> 