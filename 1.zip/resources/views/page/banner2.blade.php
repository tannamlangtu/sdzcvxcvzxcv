<div id="div_bor_tb" class="row"><section id="bai-viet" class="baiviet1"><h5 class="header header1">THÔNG BÁO</h5><div id="notice" class="div_tbhome" style="width: 98%;margin: auto;"><p>Chào mừng các thành viên đã đến với diễn đàn<span style="color: #ff0000;"><strong> Go Soi Cầu</strong>
</span>. Nhằm thêm động viên tinh thần khích lệ cho anh em.<br>Admin sẽ Tặng thẻ nạp cho thành viên có số điểm cao nhất, nhì, ba trong tháng cụ thể như sau:</p>
<big><p><strong>1. TV có điểm cao nhất :</strong> 
    <strong><span style="color: #ff0000;">2.000k</span></strong></p>
<p><strong>2. TV có điểm cao nhì :</strong> 
    <span style="color: #ff0000;"><strong>1.000k</strong></span></p>
<p><span style="color: #ff0000;">
    <strong><span style="color: #000000;">3. TV có điểm cao thứ ba :</span> 500k</strong></span></p></big>
     <p>Trao thưởng vào ngày 01 hàng tháng!</p>
     <p>Mọi thắc mắc liên hệ sđt <span style="color: #ff0000;">0522690050</p>
<p><span style="color: #000000;">
<p><span style="color: #0000ff;"><em>

    <strong>Chúc các thành viên may mắn !</strong></em></span></p></div></section></div> 
<!-- <div id="adv" class="row">
        
            <div class="row">
                <div id="hide_float_right_zone2" class="hideQCAlign">
                    <a href="javascript:HOME.hide_float_right_zone2()">Tắt quảng cáo [X]</a>
                </div>
                <div id="float_content_right_zone2" class="QCAlign" style="display: block;">

                    <div class="zone">
                        <a href="https://lixi88.com/reg.shtml?id=35200" rel="nofollow" target="_blank">
                            <img alt="" src="images/soicau-lixi88.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">
                        <a href="https://www.fb88.com/vi-VN/Account/Register" rel="nofollow" target="_blank">
                            <img alt="" src="images/soicau-fb88.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">
                        <a href="https://www.188bet.com" rel="nofollow" target="_blank">
                            <img alt="" src="images/soicau-188bet.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">
                        <a href="https://www.lucky88.com" rel="nofollow" target="_blank">
                            <img alt="" src="images/soicau-lucky88.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">
                        <a href="https://www.388bet.com/Asia/vn/trang-chu.html" rel="nofollow" target="_blank">
                            <img alt="" src="images/soicau-388.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">
                        <a href="https://www.w88yes.com/_secure/register.aspx" rel="nofollow" target="_blank">
                            <img alt="" src="images/soicau-w88.gif" class="img-responsive center-block">
                        </a>
                    </div>
                    <div class="zone">
                        <a href="/" rel="nofollow" target="_blank">
                            <img alt="" src="images/soicau-qcbanner.gif" class="img-responsive center-block">
                        </a>
                    </div>


                </div>
            </div>
        
    </div>

    <div id="adv" class="row">
        
            <div class="row">
                <div id="hide_float_right_zone4" class="hideQCAlign">
                    <a href="javascript:HOME.hide_float_right_zone4()">Tắt quảng cáo [X]</a>
                </div>
                <div id="float_content_right_zone4" class="QCAlign" style="display: block;">
                    <div class="list2 list2_chu">

                    <div class="zone1">

                        <a href="http://xosomaianh.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 25px; margin-top: 0px;" src="soicau/upload/files/2017/03/moigif1490371428.gif" alt="mới"
                                />
                                <span style="font-size: 10pt;">&nbsp;
                                    <span style="color: #ff0000;">
                                        <strong>   HÃY ĐẾN VỚi CHÚNG TÔi ĐỂ NHẬN NHỮNG CON SỐ ĐẸP NHẤt TRONG NGÀY
                                        </strong>
                                    </span>
                                </span>&nbsp;&nbsp;
                                <strong>
                                    <span style="color: #008000; font-size: 14pt;">
                                        <span style="color: #ff6600;">
                                            <span style="color: #0000ff; font-size: 10pt;">XOSOMAIANH.COM</span>&nbsp;
                                            <img style="max-width: 600px; height: 25px; margin-top: 0px;" src="soicau/upload/files/2017/03/moigif1490371428.gif" alt="mới"
                                            />
                                        </span>
                                    </span>
                                </strong>
                            </p>
                        </a>
                    </div>

                    <div class="zone1">

                        <a href="http://xosodangmanh.com/" rel="nofollow" target="_blank">
                            <p style="line-height: 16px;">
                                <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/10/vip-timgif1508250358.gif" alt="vip" />&nbsp;
                                <strong>
                                    <span style="color: #0000ff; font-size: 14pt;">
                                        <span style="font-size: 10pt;">
                                            <span style="color: #ff0000;">Số đẹp , phao lớn đưa ae xa bờ cập bến ae truy cập ngay để vào bờ nha
                                                </span></span></span>
                                </strong>
                                <span style="color: #0000ff;">
                                    <span style="font-size: 13.3333px;">
                                        <strong>XOSODANGMANH.COM</strong>
                                    </span>
                                </span>&nbsp;
                                <img style="max-width: 600px; height: 20px;" src="soicau/upload/files/2017/10/vip-timgif1508250358.gif" alt="vip" />
                            </p>
                        </a>
                    </div>
                    
                </div>
            </div>
        </div>
    </div> -->