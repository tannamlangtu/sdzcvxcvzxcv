<?php 
use App\User;
$diem = user::orderBy('diem','desc')->Paginate(10,['*'],'diem'); 
$i=1;
$j=1;
?> 
<section>
    <h4 style="text-transform: uppercase;padding: 0 15px;margin:0px;height: 33px;line-height: 33px;background: #cc6600;color: #fff;font-weight: bold;;text-align: center;">
        TOP 10 CAO THỦ LOTO</h4>

    <div class="list-top-loto">
        <table class="table table-responsive table_loto">
            <tbody>
                <tr>
                    <th style="text-align: center">Xếp hạng</th>
                    <th style="">
                        <div class="col-xs-4 col-md-4"></div>
                        <div class="col-xs-8 col-md-8" style="padding-left: 0px;">Nickname</div>
                    </th>
                    <th style="text-align: center">Số điểm </th>
                </tr>
                @foreach ($diem as $xh)
                <tr>
                    <td style="cursor: pointer;text-align: center;">{{ $i++ }}</td>
                    <td style="cursor: pointer;text-align: center;">
                        <div class="row user-info" style="text-align: center;">
                            <div class="col-xs-4 col-md-4 avt-loto">
                                <a href="/user/{{$xh -> name}}">
                                    <img class="img-circle avt_chat" src="public/uploads/avatars/{{$xh -> image}}" alt="{{$xh -> name}}"
                                        data-pin-nopin="true">
                                </a>
                            </div>
                            <div class="col-xs-8 col-md-8 name-loto">
                                <a href="/user/{{$xh -> name}}">
                                    <h4 style="padding: 0px;margin: 2px;">{{$xh -> name}}</h4>
                                </a>
                                <i class="time">
                                    <?php 
                            $date=date_create("$xh->created_at");
                            echo date_format($date,"Y/m/d"); 
                            ?></i>
                            </div>
                        </div> 
                    </td>
                    <td style="cursor: pointer;text-align: center;">
                        <span class="point-top top{{ $j++ }}">{{$xh -> diem}}</span>
                    </td>
                </tr>
                 @endforeach
             </tbody>
        </table>

    </div> 
</section>