@extends('master') @section('content')
@if(Auth::check())
                                  
@if(Auth::user()->vip==0)  
               
            <li><a href="/nap-the"><b><big>Bạn cần nâng cấp thành viên</b></big><sup class="new-messages">1</sup></a></li>
@else
     <li><b><big>Chào mừng bạn đến với website Go Soi Cầu của chúng tôi</big></b></li>
     <li><b><big>Chung tay xây dựng diễn đàn lành mạnh</big></b></li>
     @endif 

@endif
<br>
  <div id="msg">
            <div class="alert alert-info alert-dismissible fade in" role="alert">
                <strong><h3 class="text-center" style="margin-top: -10px;text-decoration: underline;color: black;">Nội Quy: </h3> 
                	<p style="padding-left: 30px; text-align: left;">Trở thành thành viên của cộng đồng Gosoicau.Com các bạn phải tuân thủ các nguyên tắc sau đây:<br>
                		- Không tạo lập nhiều tài khoản.<br>- Không spam nội dung.<br>- Không bán số, không để lại số điện thoại, không mời chào website khác trên diễn đàn.<br>
                		- Sử dụng tên nick trong sạch, lành mạnh, đúng quy cách, đúng mục đích.<br>
                		- Không chửi bới, lăng mạ thành viên khác. Nếu không hài lòng hoặc các thành viên có hành động vô văn hóa, các bạn hãy phản ánh tới Admin.
                		<br>Admin có quyền xóa tk của bạn bất cứ lúc nào nếu các bạn vi phạm các nguyên tắc sinh hoạt trên.
                		<br>Chúc các bạn tham gia cộng đồng vui vẻ, chiến thắng!</p>
<p style="padding-left: 30px; text-align: justify;"><br>Trân trọng!</p></strong>
            </div>

     @endsection
     