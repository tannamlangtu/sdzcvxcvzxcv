@extends('master') @section('content')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php $date = date("d-m-Y")  ?>


    <?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("https://xoso.wap.vn/du-doan-ket-qua-xo-so.html");
        $soi = $html->find("div.box_so",0);
        $soi1 = $html->find("div.box_so",1);
        $soi2 = $html->find("div.box_so",2);
        $soi3 = $html->find("div.box_so",3);
        $soi4 = $html->find("div.box_so",4);
        $soi5 = $html->find("div.box_so",5);
        $soi6 = $html->find("div.box_so",6);
        $soi7 = $html->find("div.box_so",7);
      
         ?>


        

    <div class="result-header">
<h2><a >DỰ ĐOÁN XỔ SỐ MIỀN BẮC </a></h2>
</div>
     {!!$soi!!}
     <div class="result-header">
     <h2><a >DỰ ĐOÁN XỔ SỐ MIỀN TRUNG - MIỀN NAM</a></h2>
     </div>
     {!!$soi1!!}
     {!!$soi2!!}
     {!!$soi3!!}
       {!!$soi4!!}
       {!!$soi5!!} 
       {!!$soi6!!}
       {!!$soi7!!}



<style type="text/css">
    @import "https://fonts.googleapis.com/css?family=Roboto:400,500,700,300|Roboto+Condensed:400,300,700&subset=latin,vietnamese";
*{font-family:Roboto,Arial,sans-serif}

a{text-decoration:none}
img{border:none}
ul,li,p,h1,h2,h3,h4{margin:0;padding:0;list-style:none}
.cold_center{float:left;margin-left:10px;width:468px}
.box_cc{margin-bottom:10px}
.result-header{background:#e71a1a none repeat scroll 0 0;font-size:16px;font-weight:400;padding:8px 0 8px 8px;text-align:left}
.result-header a{color:#fff}
.result-header1{background:#eee none repeat scroll 0 0;border-bottom:2px solid #e71a1a;color:#222;font-size:16px;font-weight:400;padding:8px 0 8px 8px;text-align:left}
.result-header1 a{color:#222;font-weight:700;text-transform:uppercase}
.result-header h2,.result-header1 h2,.result-header h3{color:#fff;font-weight:400;line-height:20px}
.result-header h2,.result-header1 h2{color:#fff;font-size:16px}
.result-header1 h2{color:#222}
.result-header h2 a{font-weight:700;text-transform:uppercase}
.result-header h2 a:hover,.result-header1 a:hover{color:#ffc600}
.result-header h3{font-size:16px}
.boxtk_1 {
    color: #404040;
    font-weight: 700;
    line-height: 30px;
    padding: 0 0 0 8px;
    font-size: 14px;
    text-align: left;
    width: 40%;
}
.boxtk_2 {
    color: #404040;
    padding-left: 8px;
    text-align: left;
    width: 60%;
    font-size: 15px;
}
.name_tbl_tk {
    color: #e30000;
    font-size: 14px;
    font-weight: 700;
    padding-left: 8px;
}
.box_kqxs .do {
    color: #e30000;
}
.do {
    color: red;
}
</style>
<section id="ket-qua" style="margin-bottom: 15px;clear: both;">
 <div class="row xem-them">
            <div class="col-xs-12">
                <br>
                &gt;&gt; Xem thêm KQXS:

                <ul>
                                        <li><a class="" href="/ket-qua/mien-bac">Miền bắc</a></li>
                                        <li><a class="" href="/ket-qua/mien-trung">Miền trung</a></li>
                                        <li><a class="current" href="/ket-qua/mien-nam">Miền nam</a></li>
                                    </ul>
            </div>

        
</section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
@endsection