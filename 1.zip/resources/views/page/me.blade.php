  @extends('master') @section('content')

@if(Auth::check())

 
<li class="list-group-item">Hình đại diện: <img style="margin-left: 20px;" src="public/uploads/avatars/{{Auth::user()->image}}" class="img-circle" width="70" height="70"></li>

  <li class="list-group-item">
  	Thay hình đại diện:
    <div class="row">
            <form enctype="multipart/form-data"  method="POST">
                <input type="file" name="avatar">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="submit" class="pull-right btn btn-sm btn-primary">
            </form>
</div>	 
    </li>
  
<li class="list-group-item">Nickname: <b>{{Auth::user()->name}}</b></li>
   <li class="list-group-item">Số ĐT: <b>{{Auth::user()->phone}}</b></li></a> 
   <li class="list-group-item">Điểm: <b>{{Auth::user()->diem}}</b></li>
   <li class="list-group-item">Email: <b>{{Auth::user()->email}}</b></li>
   <li class="list-group-item">Gia nhập: <b>{{Auth::user()->created_at}}</b></li>

<li>
  <strong><big>
  <a href='reset'>Thay đổi mật khẩu</a>
</strong></big>
</li>
@else
  <li>
  <strong><big>
  <a href='dang-nhap'>Bạn chưa đăng nhập</a>
</strong></big>
</li>
@endif


@endsection
