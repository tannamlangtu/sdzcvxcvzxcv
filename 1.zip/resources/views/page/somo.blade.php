@extends('master') @section('content')
<?php 
use App\somo;
$somo = somo::orderBy('name')->paginate(30,['*'],'somo');
$i=1;
?> 

<div class="row">
        <div class="col-lg-12">
            <div id="UserInfoBlock" class="board" style="text-align:center">
                <div id="Title">
                    <p class="text_dangky"> <a class="a_title_sm">SỔ MƠ</a> </p>
                </div>
            </div>
        </div>
    </div>
    <div class="row ">
        <div class="col-lg-12 div-t">

             
        </div>
        <div class="col-lg-12">
            <table class="table table-hover table-striped nowrap">
                <thead>
                <tr><th>STT</th>
                    <th>Tên giấc mơ</th>
                    <th>Bộ số tương ứng</th>
                </tr></thead>
                <tbody>
                    @foreach ($somo as $x)
                                <tr>
                    <td>{{$i++}}</td>
                    <td>{{$x -> name}}</td>
                    <td class="text-primary" style="font-size: 16px;">{{$x -> number}}</td>
                </tr>
                 @endforeach
                
                                                </tbody>
            </table>
        </div>
    </div>
 
{{$somo->links()}}
 


@endsection