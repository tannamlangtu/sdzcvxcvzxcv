@extends('master') @section('content')
<?php 
    $date = date("d-m-Y");
     $day = date('l');
    if($day=="Sunday") $thui = "Chủ nhật";
    if($day=="Monday") $thui = "Thứ hai";
    if($day=="Tuesday") $thui = "Thứ ba";
    if($day=="Wednesday") $thui = "Thứ tư";
    if($day=="Thursday") $thui = "Thứ năm";
    if($day=="Friday") $thui = "Thứ sáu";
    if($day=="Saturday") $thui = "Thứ bảy";
     $sothu = date('l');
    if($sothu=="Sunday") $sothu = "1";
    if($sothu=="Monday") $sothu = "2";
    if($sothu=="Tuesday") $sothu = "3";
    if($sothu=="Wednesday") $sothu = "4";
    if($sothu=="Thursday") $sothu = "5";
    if($sothu=="Friday") $sothu = "6";
    if($sothu=="Saturday") $sothu = "7";
    $plus = 1;
  
?>
<?php  date_default_timezone_set('Asia/Ho_Chi_Minh');
        include('ketquaxoso/simple_html_dom.php');
        $html = file_get_html("https://soicau366.com/mien-trung/da-nang");
        $tinh = $html->find("div#div_bor_content ul",0);
        $kq = $html->find("section#ket-qua",0);
        
         ?>
<div id="div_bor_content">

   {!!$tinh!!}
    <script>
        var time_block = -1520816706
    </script>

    @include('page.banner1')


    <div id="soi-cau">
        <div id="soi-cau">
            <h4>Soi cầu kết quả xổ số Đà Nẵng ngày {{$date}}</h4>
            
@if(Auth::check())
             
        <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/soicau.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng 
                    <?php if(Auth::user()->vip==0) echo "<A HREF='nap-the'>Nâng cấp Vip</A>"; else echo"<A HREF='chot-so'>Click vào đây</A>";?></b>
                    </a> để xem admin chốt số </div>
            </div>
        </div>
@else
    
            <div class="row">
                <div class="col-xs-2 text-center">
                    <img src="soicau/images/soicau.png" alt="Soi Cầu"> </div>
                <div class="col-xs-10"> Bạn vui lòng
                    <a href="/dang-ky">Đăng Ký</a> hoặc
                    <a href="/dang-nhap">Đăng nhập</a> để xem admin chốt số </div>
            </div>

@endif 
    </div>
	</div>



    @include('page.banner2')
              
<section id="chot-so">
        <div class="header">Khu vực chốt số của quản trị viên</div>
@if(Auth::check())
    <p style="padding: 15px;padding-bottom: 0; font-size: 18px;font-weight: bold;">
         <?php if(Auth::user()->vip==0) echo "Bạn phải là <A HREF='nap-the'>thành viên Vip</A> mới xem các QTV chốt số</A>"; else echo"<A HREF='chot-so'>Click vào đây</A> để xem QTV chốt số</A>";?>
         @else
        <p style="padding: 15px;padding-bottom: 0;font-size: 18px;font-weight: bold;">Bạn vui lòng
                <a href="dang-ky">Đăng ký</a> hoặc <a href="dang-nhap">Đăng nhập</a> để xem quản trị viên chốt số
            </p>
    
@endif
    @include('page.lochoinhieu')

    <section id="forum">
        <h3 class="header">Diễn đàn chém gió soi cầu dự đoán kết quả xổ số</h3>
@include('page.comment')
@include('page.caothu')
@include('page.banner3')

<?php 
    $date = date("d-m-Y");
    $plus = 1;
    $date = date("d-m-Y",strtotime("$date -$plus day"));
    ?>

<section id="ket-qua">

 {!!$kq!!}

<div id="zone_footer" class="zone" style="position: fixed;bottom: 0px; max-width: 720px; text-align: center; width:100%">


    <div id="hide_float_right">
        <a href="javascript:HOME.hide_float_right()">Tắt [X]</a>
    </div>
    <div id="float_content_right">
        <a href="/" rel="nofollow" target="_blank">
            
        </a>
    </div>

</div>
<!-- Bootstrap JavaScript -->




 

    
    <script>
        jQuery(document).ready(function(){
            if (HOME.getCookie("hide_popup_right_zone1") == "1") {
                var contentright = document.getElementById('float_content_right_zone1');
                var hideright = document.getElementById('hide_float_right_zone1');
                if (contentright.style.display != "none") {
                    contentright.style.display = "none";
                    hideright.innerHTML = '<a href="javascript:HOME.hide_float_right_zone1()">Xem quảng cáo...</a>';
                }
            };
       
        });
    </script>
@endsection