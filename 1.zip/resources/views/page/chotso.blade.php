@extends('master') @section('content')

<?php
$day = date("d-m-Y");
$plus = 1; 
?>
@if(Auth::user()->vip==0)  
<!-- check nếu là user thường -->
<div class="error_alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
           <strong> <big>Thông báo!</big></strong><strong> Bạn đang là thành viên thường không xem được admin chốt số. Hãy nạp thẻ để nâng cấp vip</strong>
        </div>
        
        <div class="text-center" style="margin-bottom: 15px;">
        <a href="/" class="btn btn-danger">Trang Chủ</a>
        <a href="nap-the" class="btn btn-warning">Nâng Cấp Vip</a>
    </div>
        @else
<!-- nếu là vip -->
<section>
        <h3 class="header h3_thongke" style="margin-bottom: 0px;"><span>ADMIN CHỐT SỐ LOTO NGÀY HÔM NAY {{$day}}</span> </h3>
    </section>
         @endif 


  
@endsection