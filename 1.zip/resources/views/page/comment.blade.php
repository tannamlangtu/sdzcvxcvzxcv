<?php 
use App\Comment;
$comments = Comment::latest('created_at')->paginate(15);
 ?>

<script language="javascript" src="http://code.jquery.com/jquery-2.0.0.min.js"></script>
<script>
    $(document).on('click','.pagination a', function(e){
           e.preventDefault();
           var page = $(this).attr('href').split('page=')[1];
           getPosts(page);
       });
  
       function getPosts(page)
       {
           $.ajax({
               type: "GET",
               url: '?page='+ page
           })
           .success(function(data) {
               $('body').html(data);
           });
       }
</script>

@if(Auth::check()) 
<!-- nếu đã đăng nhập -->

@if(Auth::user()->vip==0)
<!-- Nếu vip = 0 -->
<br>
<div class="row chat-form">
                <div class="col-xs-2 col-md-1">
                    <img src="soicau/images/chat.png" alt="chat">
                </div>
                                    <div class="col-xs-10 col-md-11">
                        Bạn cần phải nâng cấp lên VIP để bình luận <a href="/nap-the" class="btn btn-warning">Nâng cấp lên VIP</a>
                    </div>
                            </div>
                            <br>
@else
<!-- nếu là vip -->

        

                    <form id="comment-form" method="post" action="{{ route('comments.store') }}" >
                        {{ csrf_field() }}
                        <input type="hidden" name="user_id" value="{{ Auth::user()->id }}" >

                        <div class="row" style="padding: 10px;">
                            <div class="form-group"> 
                                <textarea class="form-control" name="comment" placeholder="Viết bình luận..! "required maxlength="400"  ></textarea>
                                
                            </div>
                        </div>
                        <div class="row" style="padding: 0 10px 0 10px;">
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary btn-lg" style="width: 100%" name="submit">
                            </div>
                        </div>
                    </form>
          @endif      
<form>
 <div class="panel-body comment-container" >
    @foreach($comments as $comment)
<div class="post row">
        <div class="row user-info">
            <div class="col-xs-2 col-md-1 avt">
                <a href="user/{{ $comment->user->name }}">
                    <img class="img-circle avt_chat" src="public/uploads/avatars/{{$comment -> user ->image}}" alt="{{ $comment->user->name }}">
                </a>
            </div>
            <div class="col-xs-9 col-md-11 name">
                <a class="name-chat" href="user/{{ $comment->user->name }}"><h4>{{ $comment->user->name }}</h4></a>
                <i class="time time-chat"><?php 
                            $date=date_create("$comment->created_at");
                            echo date_format($date,"Y/m/d H:i"); 
                            ?></i>
                <span class="point-loto">{{$comment -> user ->diem}} điểm</span>
            </div>
        </div>
        <div class="post-content row">
            <div class="col-xs-11">
                <p>
                    <?php 
                            echo nl2br($comment->comment);
                             ?>
                </p>
                    @if(Auth::user()->vip==1)
                     <a  cid="{{ $comment->id }}" name_a="{{ Auth::user()->name }}" token="{{ csrf_token() }}" class="reply">Trả lời</a>&nbsp;&nbsp;&nbsp;
                          <a class="delete-comment" token="{{ csrf_token() }}" comment-did="{{ $comment->id }}" >Xóa</a>
                                <div class="reply-form">
                                    
                                    <!-- Dynamic Reply form -->
                                    
                                </div>
                    @endif

        </div>
        </div>
        </div>
        @foreach($comment->replies as $rep)
                                     @if($comment->id === $rep->comment_id)
        <div class="comment ">
                            <div class="post">
                    <div class="row user-info">
                        <div class="col-xs-2 col-md-1 avt">
                            <a href="/user/{{$rep -> user ->name}}">
                                <img class="img-circle avt_chat" src="public/uploads/avatars/{{$rep -> user ->image}}" alt="{{$rep -> user ->name}} Soi cầu">
                            </a>
                        </div>
                        <div class="col-xs-9 col-md-11 name">
                            <a class="name-chat" title="profile {{$rep -> user ->name}}" href="/user/{{$rep -> user ->name}}"><h4>{{$rep -> user ->name}}</h4></a>
                            <i class="time time-chat "><?php 
                            $date=date_create("$rep->created_at");
                            echo date_format($date,"Y/m/d H:i"); 
                            ?></i>
                            <span class="point-loto">{{$rep -> user ->diem}} điểm</span>
                        </div>
                    </div>
                    <div class="post-content row">
                        <div class="col-xs-11">
                            <p title="nội dung soi cầu của {{$rep -> user ->name}}">
                                <?php 
                            echo nl2br($rep->reply);
                             ?>
                            </p>
                        </div>
                    </div>
                </div>
                    </div>
                 @endif 
     @endforeach                
@endforeach
</div>
{{$comments->links()}}
    </form>    
@else 
<!-- nếu chưa đăng nhập -->


<div class="row chat-form">
    <div class="col-xs-2 col-md-1">
      <img src="soicau/images/chat.png" alt="chat">
    </div>
<div class="col-xs-10 col-md-11">
   Mời thành viên ra số và chém gió (Bạn chưa <a href="dang-nhap">đăng nhập</a>)
</div>
</div>
<br>

    <form>
    @foreach($comments as $comment)
<div class="post row">
        <div class="row user-info">
            <div class="col-xs-2 col-md-1 avt">
                <a href="user/{{ $comment->user->name }}">
                    <img class="img-circle avt_chat" src="public/uploads/avatars/{{$comment -> user ->image}}" alt="{{ $comment->user->name }}">
                </a>
            </div>
            <div class="col-xs-9 col-md-11 name">
                <a class="name-chat" href="user/{{ $comment->user->name }}"><h4>{{ $comment->user->name }}</h4></a>
                <i class="time time-chat"><?php 
                            $date=date_create("$comment->created_at");
                            echo date_format($date,"Y/m/d H:i"); 
                            ?></i>
                <span class="point-loto">{{$comment -> user ->diem}} điểm</span>
            </div>
        </div>
        <div class="post-content row">
            <div class="col-xs-11">
                <p>
                    <?php 
                            echo nl2br($comment->comment);
                             ?>
                </p>
            </div>
        </div>
        </div>
        @foreach($comment->replies as $rep)
                                     @if($comment->id === $rep->comment_id)
        <div class="comment ">
                            <div class="post">
                    <div class="row user-info">
                        <div class="col-xs-2 col-md-1 avt">
                            <a href="/user/{{$rep -> user ->name}}">
                                <img class="img-circle avt_chat" src="public/uploads/avatars/{{$rep -> user ->image}}" alt="{{$rep -> user ->name}} Soi cầu">
                            </a>
                        </div>
                        <div class="col-xs-9 col-md-11 name">
                            <a class="name-chat" title="profile {{$rep -> user ->name}}" href="/user/{{$rep -> user ->name}}"><h4>{{$rep -> user ->name}}</h4></a>
                            <i class="time time-chat "><?php 
                            $date=date_create("$rep->created_at");
                            echo date_format($date,"Y/m/d H:i"); 
                            ?></i>
                            <span class="point-loto">{{$rep -> user ->diem}} điểm</span>
                        </div>
                    </div>
                    <div class="post-content row">
                        <div class="col-xs-11">
                            <p title="nội dung soi cầu của {{$rep -> user ->name}}">
                                <?php 
                            echo nl2br($rep->reply);
                             ?>
                            </p>
                        </div>
                    </div>
                </div>
                    </div>
                 @endif 
                                @endforeach   
                    
@endforeach
{{$comments->links()}}
    </form>    
        @endif
      