@extends('master') @section('content')

<?php 
use App\User;
$users = user::latest('created_at')->paginate(1); 
?> 
@foreach ($name as $n)
<ul class="list-group">
        <li class="list-group-item">Hình đại diện: <img style="margin-left: 20px;" src="public/uploads/avatars/{{$n->image}}" class="img-circle" width="70" height="70"></li>
        <li class="list-group-item">Nickname: {{$n->name}} <b></b></li> 
        <?php $lenght = strlen($n->phone);?>
        <li class="list-group-item">Số ĐT: <b>{{substr($n->phone,0,$lenght-5)}}*****</b></li>
        <li class="list-group-item">Điểm: <b>{{$n->diem}}</b></li>
        

    </ul>
@endforeach



 @endsection