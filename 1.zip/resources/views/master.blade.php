<!DOCTYPE html>
<html lang="vi">
<?php 
    $date = date("d-m-Y");
     $day = date('l');
?>

<head>
    <meta charset="utf-8">
    <base href="{{asset('')}}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Soi cau,bach thu lo, xsmb, soi lo de, soi cau lo de mien bac, soi cau mien bac, dien dan soi cau, dien dan chem gio, soi cau mb, soi cau xs, soi cau lo de mien phi, soi cau lo de hang ngay,rong bach kim,gio vang chot so,soi au mien trung,soi cau mien nam">
    <meta name="description" content="Soi cầu,bạch thủ lô, xsmb,soi cầu lô đề miền bắc,soi cầu miền bắc,soi cầu miền nam,soi cầu miền trung,diễn đàn soi cầu, diễn đàn chém gió, soi cầu mb, soi cầu xs, soi cầu lô đề miễn phí, soi cầu lô đề hàng ngày,rồng bạch kim,giờ vàng chốt số ngày {{$date}} ">
    <title>Soi cầu miền Bắc hôm nay {{$date}}|diễn đàn xổ số |bạch thủ lô chuẩn - Go Soi Cầu</title>


    <meta property="og:title" content="Go Soi Cầu ">
    <meta property="og:type" content="article">
    <meta property="og:url" content="/">
    <meta property="og:image" content="images/96b7d0e28be77a0b1f60fbea9a32544d.jpg">

    <meta name="twitter:card" content="Go Soi Cầu ">
    <meta name="twitter:site" content="gosoicau.com">
    <meta name="twitter:title" content="Go Soi Cầu ">
    <meta name="twitter:description" content=" Soi cầu,bạch thủ lô, xsmb,soi cầu lô đề miền bắc,soi cầu miền bắc,soi cầu miền nam,soi cầu miền trung,diễn đàn soi cầu, diễn đàn chém gió, soi cầu mb, soi cầu xs, soi cầu lô đề miễn phí, soi cầu lô đề hàng ngày,rồng bạch kim,giờ vàng chốt số ngày {{$date}} ">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="shortcut icon" href="soicau/img/favicon.ico" />
    <link href="soicau/bootstrap3/css/bootstrap.min.css" rel="stylesheet">
    <link href="soicau/misc/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <link href="soicau/css/animate.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="soicau/css/maps/jquery-jvectormap-2.0.3.min.css" />
    <link href="soicau/css/icheck/flat/green.css" rel="stylesheet" />
    <link rel="stylesheet" href="soicau/css/site.css">
    <link rel="stylesheet" href="soicau/frontend/css/home4.css">
  

<!-- phân trang ajax -->

</head>

<body>
    <noscript id="deferred-styles">
    </noscript>
    <script>
        var loadDeferredStyles = function () {
            var addStylesNode = document.getElementById("deferred-styles");
            var replacement = document.createElement("div");
            replacement.innerHTML = addStylesNode.textContent;
            document.body.appendChild(replacement)
            addStylesNode.parentElement.removeChild(addStylesNode);
        };
        var raf = requestAnimationFrame || mozRequestAnimationFrame ||
            webkitRequestAnimationFrame || msRequestAnimationFrame;
        if (raf) raf(function () {
            window.setTimeout(loadDeferredStyles, 0);
        });
        else window.addEventListener('load', loadDeferredStyles);
    </script>
    <div class="container">
        <div id="site">
        @include('header')
        @yield('content')
        @include('footer')
     
        </div>
    </div>
    <!-- Bootstrap JavaScript -->
   
<script src="soicau/bootstrap3/js/bootstrap.min.js"></script>
<script src="soicau/js/nprogress.js"></script>
<script src="soicau/frontend/js/home5.js"></script>

<script>
    jQuery(document).ready(function () {
        if (HOME.getCookie("hide_popup_right_zone1") == "1") {
            var contentright = document.getElementById('float_content_right_zone1');
            var hideright = document.getElementById('hide_float_right_zone1');
            if (contentright.style.display != "none") {
                contentright.style.display = "none";
                hideright.innerHTML =
                    '<a href="javascript:HOME.hide_float_right_zone1()">Xem quảng cáo...</a>';
            }
        };
        if (HOME.getCookie("hide_popup_right_zone2") == "1") {
            var contentright = document.getElementById('float_content_right_zone2');
            var hideright = document.getElementById('hide_float_right_zone2');
            if (contentright.style.display != "none") {
                contentright.style.display = "none";
                hideright.innerHTML =
                    '<a href="javascript:HOME.hide_float_right_zone2()">Xem quảng cáo...</a>';
            }
        };
    });
</script>

  
<script type="text/javascript">
    var recaptcha1;
    var onloadCallback = function () {
        recaptcha1 = grecaptcha.render(
            'Recaptcha_subscribe', {
                'sitekey': '6LeWKS4UAAAAAPfippSGh47kqNgMPX7e3w7WoeW2',
                'callback': function (a) {
                    USER.register_submit();

                }
            }
        );

    };
</script>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <link href='http://fonts.googleapis.com/css?family=Dosis:300,400' rel='stylesheet' type='text/css'>
     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
    <script src="http://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <script src="http://code.jquery.com/jquery-3.2.1.js" integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE=" crossorigin="anonymous"></script>
  <script language="javascript" src="http://code.jquery.com/jquery-2.0.0.min.js"></script>
</body>

</html>
