<?php

use Illuminate\Database\Seeder;

class ketquaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $ketqua = new App\ketqua([
            'ketqua' => '36829',
            'idgiaikqxs'=>'1'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '46404',
            'idgiaikqxs'=>'2'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '47407',
            'idgiaikqxs'=>'3'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '99156',
            'idgiaikqxs'=>'3'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '41804',
            'idgiaikqxs'=>'4'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '74553',
            'idgiaikqxs'=>'4'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '36631',
            'idgiaikqxs'=>'4'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '05391',
            'idgiaikqxs'=>'4'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '50900',
            'idgiaikqxs'=>'4'
        ]);
        $ketqua -> save();

        $ketqua = new App\ketqua([
            'ketqua' => '26450',
            'idgiaikqxs'=>'4'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '2085',
            'idgiaikqxs'=>'5'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '3669',
            'idgiaikqxs'=>'5'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '8686',
            'idgiaikqxs'=>'5'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '8555',
            'idgiaikqxs'=>'5'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '2512',
            'idgiaikqxs'=>'6'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '3194',
            'idgiaikqxs'=>'6'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '2197',
            'idgiaikqxs'=>'6'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '1478',
            'idgiaikqxs'=>'6'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '9032',
            'idgiaikqxs'=>'6'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '1767',
            'idgiaikqxs'=>'6'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '464',
            'idgiaikqxs'=>'7'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '471',
            'idgiaikqxs'=>'7'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '484',
            'idgiaikqxs'=>'7'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '73',
            'idgiaikqxs'=>'8'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '41',
            'idgiaikqxs'=>'8'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '24',
            'idgiaikqxs'=>'8'
        ]);
        $ketqua -> save();
        $ketqua = new App\ketqua([
            'ketqua' => '77',
            'idgiaikqxs'=>'8'
        ]);
        $ketqua -> save();

    }
}
