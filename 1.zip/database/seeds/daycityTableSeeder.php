<?php

use Illuminate\Database\Seeder;

class daycityTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $day = new App\daycity([
            'idcity' => '1',
            'idday'=>'1'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '1',
            'idday'=>'2'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '1',
            'idday'=>'3'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '1',
            'idday'=>'4'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '1',
            'idday'=>'5'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '1',
            'idday'=>'6'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '1',
            'idday'=>'7'
        ]);
        $day -> save();

        $day = new App\daycity([
            'idcity' => '2',
            'idday'=>'1'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '2',
            'idday'=>'4'
        ]);
        $day -> save();

        $day = new App\daycity([
            'idcity' => '3',
            'idday'=>'1'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '4',
            'idday'=>'2'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '5',
            'idday'=>'2'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '6',
            'idday'=>'3'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '7',
            'idday'=>'3'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '8',
            'idday'=>'4'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '9',
            'idday'=>'5'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '10',
            'idday'=>'5'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '11',
            'idday'=>'5'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '12',
            'idday'=>'6'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '13',
            'idday'=>'6'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '8',
            'idday'=>'7'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '14',
            'idday'=>'7'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '15',
            'idday'=>'7'
        ]);
        $day -> save();

        $day = new App\daycity([
            'idcity' => '16',
            'idday'=>'1'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '17',
            'idday'=>'1'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '18',
            'idday'=>'1'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '19',
            'idday'=>'2'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '20',
            'idday'=>'2'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '21',
            'idday'=>'2'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '22',
            'idday'=>'3'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '23',
            'idday'=>'3'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '24',
            'idday'=>'3'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '25',
            'idday'=>'4'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '26',
            'idday'=>'4'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '27',
            'idday'=>'4'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '28',
            'idday'=>'5'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '29',
            'idday'=>'5'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '30',
            'idday'=>'5'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '31',
            'idday'=>'6'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '32',
            'idday'=>'6'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '33',
            'idday'=>'6'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '34',
            'idday'=>'7'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '35',
            'idday'=>'7'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '21',
            'idday'=>'7'
        ]);
        $day -> save();
        $day = new App\daycity([
            'idcity' => '36',
            'idday'=>'7'
        ]);
        $day -> save();
    }
}
