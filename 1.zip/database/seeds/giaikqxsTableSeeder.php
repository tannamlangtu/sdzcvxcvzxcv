<?php

use Illuminate\Database\Seeder;

class giaikqxsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '1',
            'idgiai' => '1'
        ]);
        $giaikqxs -> save();
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '1',
            'idgiai' => '2'
        ]);
        $giaikqxs -> save();
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '1',
            'idgiai' => '3'
        ]);
        $giaikqxs -> save();
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '1',
            'idgiai' => '4'
        ]);
        $giaikqxs -> save();
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '1',
            'idgiai' => '5'
        ]);
        $giaikqxs -> save();
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '1',
            'idgiai' => '6'
        ]);
        $giaikqxs -> save();
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '1',
            'idgiai' => '7'
        ]);
        $giaikqxs -> save();
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '1',
            'idgiai' => '1'
        ]);
        $giaikqxs -> save();
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '1',
            'idgiai' => '9'
        ]);
        $giaikqxs -> save();
        $giaikqxs = new App\giaikqxs([
            'idkqxs' => '2',
            'idgiai' => '1'
        ]);
        $giaikqxs -> save();
    }
}
